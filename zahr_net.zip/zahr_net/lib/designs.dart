import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'store.dart';
import 'ui.dart';

/// يختار صورة من المعرض وينسخها لمجلد التطبيق.
Future<String?> pickImage() async {
  final x = await ImagePicker()
      .pickImage(source: ImageSource.gallery, maxWidth: 1800, imageQuality: 90);
  if (x == null) return null;
  final ext = x.path.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
  final dest = '${Store.dir}/img_${DateTime.now().millisecondsSinceEpoch}.$ext';
  await File(x.path).copy(dest);
  return dest;
}

List<(String, String)> designOptions() => [
      ('default', 'التصميم الافتراضي (شعار + اسم)'),
      ('pkg', 'صورة الباقة كخلفية'),
      for (final d in Store.designs) (d.id, d.name),
    ];

CardDesign? resolveDesign(String id, String profile) {
  if (id == 'default') return null;
  if (id == 'pkg') {
    return CardDesign(id: 'pkg', name: 'pkg', bg: Store.pkgs[profile]?.image);
  }
  for (final d in Store.designs) {
    if (d.id == id) return d;
  }
  return null;
}

Widget designDropdown(String value, ValueChanged<String> onChanged) {
  final opts = designOptions();
  return DropdownButtonFormField<String>(
    value: opts.any((o) => o.$1 == value) ? value : 'default',
    decoration: const InputDecoration(labelText: 'تصميم الكرت'),
    items: [
      for (final o in opts) DropdownMenuItem(value: o.$1, child: Text(o.$2))
    ],
    onChanged: (v) => onChanged(v ?? 'default'),
  );
}

class DesignsScreen extends StatefulWidget {
  const DesignsScreen({super.key});
  @override
  State<DesignsScreen> createState() => _DesignsScreenState();
}

class _DesignsScreenState extends State<DesignsScreen> {
  Future<void> _open(CardDesign? d) async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => DesignEditor(design: d)));
    if (mounted) setState(() {});
  }

  Future<void> _delete(CardDesign d) async {
    if (!await confirm(context, 'حذف التصميم "${d.name}"؟')) return;
    final l = Store.designs..removeWhere((e) => e.id == d.id);
    await Store.saveDesigns(l);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final list = Store.designs;
    return Scaffold(
      appBar: AppBar(title: const Text('قوالب الكروت')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: turqBtn,
        foregroundColor: Colors.white,
        onPressed: () => _open(null),
        child: const Icon(Icons.add),
      ),
      body: list.isEmpty
          ? const Center(
              child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                  'لا توجد تصاميم. اضغط + لإنشاء تصميم كرت بخلفية من صورتك وتحديد مكان اسم المستخدم وكلمة المرور.',
                  textAlign: TextAlign.center),
            ))
          : ListView(padding: const EdgeInsets.all(12), children: [
              for (final d in list)
                Card(
                  child: ListTile(
                    leading: (d.bg != null && File(d.bg!).existsSync())
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: Image.file(File(d.bg!),
                                width: 56, height: 40, fit: BoxFit.cover))
                        : const Icon(Icons.credit_card, color: turq),
                    title: Text(d.name),
                    subtitle: Text('${fmtMoney(d.w)} × ${fmtMoney(d.h)} مم'),
                    trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _delete(d)),
                    onTap: () => _open(d),
                  ),
                ),
            ]),
    );
  }
}

class DesignEditor extends StatefulWidget {
  const DesignEditor({super.key, this.design});
  final CardDesign? design;
  @override
  State<DesignEditor> createState() => _DesignEditorState();
}

class _DesignEditorState extends State<DesignEditor> {
  late CardDesign d;
  final name = TextEditingController();
  final wc = TextEditingController();
  final hc = TextEditingController();

  @override
  void initState() {
    super.initState();
    d = widget.design != null
        ? CardDesign.fromJson(widget.design!.toJson())
        : CardDesign(
            id: DateTime.now().millisecondsSinceEpoch.toString(), name: '');
    name.text = d.name;
    wc.text = fmtMoney(d.w);
    hc.text = fmtMoney(d.h);
  }

  Widget _t(String t, double x, double y, double size, double s, double cw,
          double ch) =>
      Positioned(
        left: x * cw - 100,
        top: y * ch - size * s * 0.6,
        width: 200,
        child: Center(
            child: Text(t,
                style: TextStyle(
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.bold,
                    fontSize: size * s,
                    color: Color(d.color)))),
      );

  Widget _preview() => AspectRatio(
        aspectRatio: d.w / d.h,
        child: ClipRect(
          child: LayoutBuilder(builder: (_, c) {
            final cw = c.maxWidth, ch = c.maxHeight;
            final s = cw / (d.w * 2.8346);
            return Stack(children: [
              Positioned.fill(
                  child: (d.bg != null && File(d.bg!).existsSync())
                      ? Image.file(File(d.bg!), fit: BoxFit.fill)
                      : Container(color: Colors.white)),
              _t('1234567', d.ux, d.uy, d.usz, s, cw, ch),
              if (d.showPass) _t('7654321', d.px, d.py, d.psz, s, cw, ch),
            ]);
          }),
        ),
      );

  Widget _slider(String label, double v, double min, double max,
          ValueChanged<double> on) =>
      Row(children: [
        SizedBox(width: 110, child: Text(label)),
        Expanded(
            child: Slider(
                value: v.clamp(min, max),
                min: min,
                max: max,
                activeColor: turq,
                onChanged: (x) => setState(() => on(x)))),
      ]);

  Future<void> _save() async {
    if (name.text.trim().isEmpty) {
      toast(context, 'أدخل اسم التصميم');
      return;
    }
    d.name = name.text.trim();
    final l = Store.designs;
    final i = l.indexWhere((e) => e.id == d.id);
    if (i >= 0) {
      l[i] = d;
    } else {
      l.add(d);
    }
    await Store.saveDesigns(l);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تصميم كرت')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _preview(),
          const SizedBox(height: 14),
          field(name, 'اسم التصميم'),
          Row(children: [
            Expanded(
                child: TextField(
              controller: wc,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'العرض (مم)'),
              onChanged: (v) =>
                  setState(() => d.w = (double.tryParse(v) ?? 85).clamp(30, 200)),
            )),
            const SizedBox(width: 12),
            Expanded(
                child: TextField(
              controller: hc,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'الارتفاع (مم)'),
              onChanged: (v) =>
                  setState(() => d.h = (double.tryParse(v) ?? 54).clamp(20, 200)),
            )),
          ]),
          const SizedBox(height: 12),
          OutlinedButton.icon(
              onPressed: () async {
                final f = await pickImage();
                if (f != null) setState(() => d.bg = f);
              },
              icon: const Icon(Icons.image),
              label: const Text('اختيار صورة خلفية الكرت')),
          if (d.bg != null)
            TextButton(
                onPressed: () => setState(() => d.bg = null),
                child: const Text('إزالة الخلفية')),
          const Divider(height: 28),
          _slider('اسم المستخدم ↔', d.ux, 0, 1, (v) => d.ux = v),
          _slider('اسم المستخدم ↕', d.uy, 0, 1, (v) => d.uy = v),
          _slider('حجم الاسم', d.usz, 6, 40, (v) => d.usz = v),
          SwitchListTile(
              value: d.showPass,
              onChanged: (v) => setState(() => d.showPass = v),
              title: const Text('إظهار كلمة المرور')),
          if (d.showPass) ...[
            _slider('كلمة المرور ↔', d.px, 0, 1, (v) => d.px = v),
            _slider('كلمة المرور ↕', d.py, 0, 1, (v) => d.py = v),
            _slider('حجم كلمة المرور', d.psz, 6, 40, (v) => d.psz = v),
          ],
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            for (final c in [
              ('أسود', 0xFF000000),
              ('أبيض', 0xFFFFFFFF),
              ('بترولي', 0xFF0A3F52)
            ])
              ChoiceChip(
                  label: Text(c.$1),
                  selected: d.color == c.$2,
                  onSelected: (_) => setState(() => d.color = c.$2)),
          ]),
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('حفظ التصميم')),
        ]),
      );
}
