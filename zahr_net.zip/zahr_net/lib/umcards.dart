import 'package:flutter/material.dart';
import 'designs.dart';
import 'pdf_cards.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

/// كروت User Manager الموجودة على الراوتر (مزامنة مباشرة): فلترة، طباعة، حذف.
class UmCardsScreen extends StatefulWidget {
  const UmCardsScreen({super.key});
  @override
  State<UmCardsScreen> createState() => _UmCardsScreenState();
}

class _UmCardsScreenState extends State<UmCardsScreen> {
  List<UmUser> all = [];
  String profile = '*';
  String status = 'all';
  String q = '';
  String design = 'default';
  int cols = 4;
  final Set<String> sel = {};
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(context, () => Ros.run((c) => UM.users(c)));
    if (!mounted) return;
    setState(() {
      if (r != null) {
        all = r;
        sel.clear();
      }
      loaded = true;
    });
  }

  String _profOf(UmUser u) {
    if (u.profile.isNotEmpty) return u.profile;
    for (final b in Store.batches) {
      if (b.cards.any((c) => c.user == u.username)) return b.profile;
    }
    return '';
  }

  List<UmUser> get filtered => all.where((u) {
        if (profile != '*' && _profOf(u) != profile) return false;
        if (status == 'unused' && (u.usedOnce || u.disabled)) return false;
        if (status == 'used' && !u.usedOnce) return false;
        if (status == 'disabled' && !u.disabled) return false;
        if (q.isNotEmpty && !u.username.toLowerCase().contains(q.toLowerCase())) {
          return false;
        }
        return true;
      }).toList();

  List<UmUser> get _target {
    if (sel.isNotEmpty) return all.where((u) => sel.contains(u.id)).toList();
    return filtered;
  }

  Batch? _batch() {
    final t = _target;
    if (t.isEmpty) {
      toast(context, 'لا توجد كروت');
      return null;
    }
    final profs = t.map(_profOf).toSet();
    final p = profs.length == 1 ? profs.first : 'MIX';
    return Batch(
        id: 'tmp${DateTime.now().millisecondsSinceEpoch}',
        date: DateTime.now(),
        profile: p,
        price: profs.length == 1 ? Store.priceFor(p) : 0,
        cards: [for (final u in t) Voucher(u.username, u.password)]);
  }

  Future<void> _print(bool pdf) async {
    final b = _batch();
    if (b == null) return;
    final d = resolveDesign(design, b.profile);
    await busy(context,
        () => pdf ? shareBatchPdf(b, cols: cols, design: d) : printBatch(b, cols: cols, design: d));
  }

  Future<void> _delete() async {
    final t = _target;
    if (t.isEmpty) return;
    if (!await confirm(context, 'حذف ${t.length} كرت من الراوتر نهائياً؟')) return;
    final ok = await busy(context, () async {
      await Ros.run((c) => UM.remove(c, t.map((e) => e.id).toList()));
      return true;
    });
    if (ok == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = filtered;
    final profs = all.map(_profOf).where((e) => e.isNotEmpty).toSet().toList()..sort();
    final unused = all.where((u) => !u.usedOnce && !u.disabled).length;
    return Scaffold(
      appBar: AppBar(
          title: Text('كروت اليوزر مانجر (${all.length})'),
          actions: [IconButton(onPressed: _load, icon: const Icon(Icons.sync))]),
      body: !loaded
          ? const SizedBox()
          : Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Column(children: [
                  Text('غير مستخدمة: $unused • مستخدمة: ${all.where((u) => u.usedOnce).length}',
                      style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: profs.contains(profile) ? profile : '*',
                        decoration: const InputDecoration(labelText: 'الباقة'),
                        items: [
                          const DropdownMenuItem(value: '*', child: Text('الكل')),
                          for (final p in profs)
                            DropdownMenuItem(value: p, child: Text(p))
                        ],
                        onChanged: (v) => setState(() => profile = v ?? '*'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: status,
                        decoration: const InputDecoration(labelText: 'الحالة'),
                        items: const [
                          DropdownMenuItem(value: 'all', child: Text('الكل')),
                          DropdownMenuItem(value: 'unused', child: Text('غير مستخدم')),
                          DropdownMenuItem(value: 'used', child: Text('مستخدم')),
                          DropdownMenuItem(value: 'disabled', child: Text('معطّل')),
                        ],
                        onChanged: (v) => setState(() => status = v ?? 'all'),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  TextField(
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search), labelText: 'بحث'),
                    onChanged: (v) => setState(() => q = v),
                  ),
                  Row(children: [
                    Text('المعروض: ${list.length}'),
                    const Spacer(),
                    TextButton(
                        onPressed: () => setState(() {
                              if (sel.length == list.length) {
                                sel.clear();
                              } else {
                                sel
                                  ..clear()
                                  ..addAll(list.map((e) => e.id));
                              }
                            }),
                        child: Text(sel.length == list.length && list.isNotEmpty
                            ? 'إلغاء التحديد'
                            : 'تحديد الكل')),
                  ]),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final u = list[i];
                    return CheckboxListTile(
                      dense: true,
                      activeColor: turqBtn,
                      value: sel.contains(u.id),
                      onChanged: (v) => setState(
                          () => v == true ? sel.add(u.id) : sel.remove(u.id)),
                      title: Text(
                          u.password.isEmpty || u.password == u.username
                              ? u.username
                              : '${u.username}  /  ${u.password}',
                          style: const TextStyle(fontFamily: 'monospace')),
                      subtitle: Text(
                          '${_profOf(u).isEmpty ? '—' : _profOf(u)} • ${u.disabled ? 'معطّل' : (u.usedOnce ? 'مستخدم ${fmtBytes(u.used)}' : 'غير مستخدم')}'),
                    );
                  },
                ),
              ),
              Container(
                color: petrolLight,
                padding: const EdgeInsets.all(10),
                child: SafeArea(
                  top: false,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Row(children: [
                      Expanded(child: designDropdown(design, (v) => setState(() => design = v))),
                      const SizedBox(width: 8),
                      DropdownButton<int>(
                          value: cols,
                          items: [3, 4, 5, 6]
                              .map((e) => DropdownMenuItem(value: e, child: Text('$e')))
                              .toList(),
                          onChanged: (v) => setState(() => cols = v ?? 4)),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      Expanded(
                          child: FilledButton.icon(
                              onPressed: () => _print(false),
                              icon: const Icon(Icons.print),
                              label: Text('طباعة (${sel.isEmpty ? list.length : sel.length})'))),
                      const SizedBox(width: 8),
                      Expanded(
                          child: OutlinedButton.icon(
                              onPressed: () => _print(true),
                              icon: const Icon(Icons.picture_as_pdf),
                              label: const Text('PDF'))),
                      const SizedBox(width: 8),
                      IconButton(
                          onPressed: _delete,
                          icon: const Icon(Icons.delete_forever, color: Colors.redAccent)),
                    ]),
                  ]),
                ),
              ),
            ]),
    );
  }
}
