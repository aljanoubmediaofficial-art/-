import 'package:flutter/material.dart';
import 'home.dart';
import 'settings.dart';
import 'store.dart';
import 'ui.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    });
  }

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(
            child: Padding(
                padding: EdgeInsets.all(32), child: Logo(height: 140))),
      );
}

/// أول تشغيل: إنشاء حساب المالك (مدير عام بصلاحيات كاملة). بعدها: تسجيل دخول.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final name = TextEditingController();
  final pw = TextEditingController();
  final pw2 = TextEditingController();
  final bool first = !Store.hasOwner;

  Future<void> _go() async {
    if (first) {
      if (name.text.trim().isEmpty || pw.text.length < 4) {
        toast(context, 'أدخل الاسم وكلمة مرور لا تقل عن 4 أحرف');
        return;
      }
      if (pw.text != pw2.text) {
        toast(context, 'كلمتا المرور غير متطابقتين');
        return;
      }
      await Store.createOwner(name.text.trim(), pw.text);
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const HomeScreen(openSettings: true)));
    } else {
      if (!Store.checkPassword(pw.text)) {
        toast(context, 'كلمة المرور غير صحيحة');
        return;
      }
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(height: 110),
                const SizedBox(height: 24),
                Text(first ? 'إنشاء حساب المالك' : 'مرحباً ${Store.ownerName}',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                if (first) field(name, 'اسم المالك'),
                field(pw, 'كلمة المرور', obscure: true),
                if (first) field(pw2, 'تأكيد كلمة المرور', obscure: true),
                const SizedBox(height: 8),
                FilledButton(
                    onPressed: _go,
                    child: Text(first ? 'إنشاء الحساب' : 'تسجيل الدخول')),
              ]),
            ),
          ),
        ),
      );
}
