import 'package:flutter/material.dart';
import 'ui.dart';
import 'um.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});
  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  List<UmUser> all = [];
  String q = '';
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(context, () => Ros.run((c) => UM.users(c)));
    if (!mounted) return;
    setState(() {
      all = r ?? all;
      loaded = true;
    });
  }

  Future<void> _act(UmUser u) async {
    final choice = await showModalBottomSheet<String>(
        context: context,
        builder: (_) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                    title: Text(u.username),
                    subtitle: Text(
                        '${u.profile} • ${fmtBytes(u.used)} • ${u.uptime}')),
                ListTile(
                    leading: Icon(u.disabled ? Icons.check_circle : Icons.block),
                    title: Text(u.disabled ? 'تفعيل' : 'تعطيل'),
                    onTap: () => Navigator.pop(context, 'toggle')),
                ListTile(
                    leading: const Icon(Icons.delete),
                    title: const Text('حذف'),
                    onTap: () => Navigator.pop(context, 'delete')),
              ]),
            ));
    if (choice == null || !mounted) return;
    if (choice == 'delete' && !await confirm(context, 'حذف ${u.username}؟')) return;
    if (!mounted) return;
    final ok = await busy(
        context,
        () => Ros.run((c) async {
              if (choice == 'delete') {
                await UM.remove(c, [u.id]);
              } else {
                await UM.setDisabled(c, [u.id], !u.disabled);
              }
              return true;
            }));
    if (ok == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = all
        .where((u) => q.isEmpty || u.username.toLowerCase().contains(q.toLowerCase()))
        .toList();
    return Scaffold(
      appBar: AppBar(title: Text('المستخدمون (${all.length})'), actions: [
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh))
      ]),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search), labelText: 'بحث'),
            onChanged: (v) => setState(() => q = v),
          ),
        ),
        Expanded(
          child: !loaded
              ? const SizedBox()
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final u = list[i];
                    return ListTile(
                      leading: Icon(u.disabled ? Icons.block : Icons.person,
                          color: u.disabled ? Colors.redAccent : turq),
                      title: Text(u.username),
                      subtitle: Text(
                          '${u.profile.isEmpty ? '—' : u.profile} • ${fmtBytes(u.used)}'),
                      onTap: () => _act(u),
                    );
                  }),
        ),
      ]),
    );
  }
}

class SessionsScreen extends StatefulWidget {
  const SessionsScreen({super.key});
  @override
  State<SessionsScreen> createState() => _SessionsScreenState();
}

class _SessionsScreenState extends State<SessionsScreen> {
  List<Map<String, String>> rows = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(context, () => Ros.run((c) => UM.activeSessions(c)));
    if (mounted) setState(() => rows = r ?? rows);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('الجلسات النشطة (${rows.length})'), actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh))
        ]),
        body: rows.isEmpty
            ? const Center(child: Text('لا توجد جلسات نشطة'))
            : ListView(children: [
                for (final s in rows)
                  ListTile(
                    leading: const Icon(Icons.wifi, color: turq),
                    title: Text(s['user'] ?? '—'),
                    subtitle: Text([
                      s['user-ip'],
                      s['calling-station-id'],
                      s['uptime']
                    ].where((e) => e != null && e.isNotEmpty).join(' • ')),
                  ),
              ]),
      );
}

class ProfilesScreen extends StatefulWidget {
  const ProfilesScreen({super.key});
  @override
  State<ProfilesScreen> createState() => _ProfilesScreenState();
}

class _ProfilesScreenState extends State<ProfilesScreen> {
  List<UmProfile> list = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final r = await busy(context, () => Ros.run((c) => UM.profiles(c)));
      if (mounted) setState(() => list = r ?? []);
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('الباقات')),
        body: list.isEmpty
            ? const Center(child: Text('لا توجد باقات'))
            : ListView(children: [
                for (final p in list)
                  ListTile(
                    leading: const Icon(Icons.layers, color: turq),
                    title: Text(p.name),
                    subtitle: Text(
                        'الصلاحية: ${p.validity.isEmpty ? 'غير محدودة' : p.validity}'),
                  ),
              ]),
      );
}
