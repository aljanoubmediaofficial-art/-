import 'dart:io';
import 'package:flutter/material.dart';
import 'designs.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});
  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  List<UmUser> all = [];
  String q = '';
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(context, () => Ros.run((c) => UM.users(c)));
    if (!mounted) return;
    setState(() {
      all = r ?? all;
      loaded = true;
    });
  }

  Future<void> _act(UmUser u) async {
    final choice = await showModalBottomSheet<String>(
        context: context,
        builder: (_) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                    title: Text(u.username),
                    subtitle: Text(
                        '${u.profile} • ${fmtBytes(u.used)} • ${u.uptime}')),
                ListTile(
                    leading: Icon(u.disabled ? Icons.check_circle : Icons.block),
                    title: Text(u.disabled ? 'تفعيل' : 'تعطيل'),
                    onTap: () => Navigator.pop(context, 'toggle')),
                ListTile(
                    leading: const Icon(Icons.delete),
                    title: const Text('حذف'),
                    onTap: () => Navigator.pop(context, 'delete')),
              ]),
            ));
    if (choice == null || !mounted) return;
    if (choice == 'delete' && !await confirm(context, 'حذف ${u.username}؟')) return;
    if (!mounted) return;
    final ok = await busy(
        context,
        () => Ros.run((c) async {
              if (choice == 'delete') {
                await UM.remove(c, [u.id]);
              } else {
                await UM.setDisabled(c, [u.id], !u.disabled);
              }
              return true;
            }));
    if (ok == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = all
        .where((u) => q.isEmpty || u.username.toLowerCase().contains(q.toLowerCase()))
        .toList();
    return Scaffold(
      appBar: AppBar(title: Text('المستخدمون (${all.length})'), actions: [
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh))
      ]),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search), labelText: 'بحث'),
            onChanged: (v) => setState(() => q = v),
          ),
        ),
        Expanded(
          child: !loaded
              ? const SizedBox()
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final u = list[i];
                    return ListTile(
                      leading: Icon(u.disabled ? Icons.block : Icons.person,
                          color: u.disabled ? Colors.redAccent : turq),
                      title: Text(u.username),
                      subtitle: Text(
                          '${u.profile.isEmpty ? '—' : u.profile} • ${fmtBytes(u.used)}'),
                      onTap: () => _act(u),
                    );
                  }),
        ),
      ]),
    );
  }
}

class SessionsScreen extends StatefulWidget {
  const SessionsScreen({super.key});
  @override
  State<SessionsScreen> createState() => _SessionsScreenState();
}

class _SessionsScreenState extends State<SessionsScreen> {
  List<Map<String, String>> rows = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(context, () => Ros.run((c) => UM.activeSessions(c)));
    if (mounted) setState(() => rows = r ?? rows);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('الجلسات النشطة (${rows.length})'), actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh))
        ]),
        body: rows.isEmpty
            ? const Center(child: Text('لا توجد جلسات نشطة'))
            : ListView(children: [
                for (final s in rows)
                  ListTile(
                    leading: const Icon(Icons.wifi, color: turq),
                    title: Text(s['user'] ?? '—'),
                    subtitle: Text([
                      s['user-ip'],
                      s['calling-station-id'],
                      s['uptime']
                    ].where((e) => e != null && e.isNotEmpty).join(' • ')),
                  ),
              ]),
      );
}

class ProfilesScreen extends StatefulWidget {
  const ProfilesScreen({super.key});
  @override
  State<ProfilesScreen> createState() => _ProfilesScreenState();
}

class _ProfilesScreenState extends State<ProfilesScreen> {
  List<UmProfile> list = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final r = await busy(context, () => Ros.run((c) => UM.profiles(c)));
      if (mounted) setState(() => list = r ?? []);
    });
  }

  Future<void> _edit(UmProfile p) async {
    final all = Store.pkgs;
    final info = all[p.name] ?? PkgInfo();
    final price = TextEditingController(text: info.price > 0 ? fmtMoney(info.price) : '');
    String? image = info.image;
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => StatefulBuilder(
            builder: (ctx, setD) => AlertDialog(
                  title: Text(p.name),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    if (image != null && File(image!).existsSync())
                      Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Image.file(File(image!), height: 120)),
                    field(price, 'سعر الباقة', number: true),
                    OutlinedButton.icon(
                        onPressed: () async {
                          final f = await pickImage();
                          if (f != null) setD(() => image = f);
                        },
                        icon: const Icon(Icons.image),
                        label: const Text('اختيار صورة الباقة')),
                    if (image != null)
                      TextButton(
                          onPressed: () => setD(() => image = null),
                          child: const Text('إزالة الصورة')),
                  ]),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('إلغاء')),
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('حفظ')),
                  ],
                )));
    if (ok != true) return;
    all[p.name] = PkgInfo(price: double.tryParse(price.text) ?? 0, image: image);
    await Store.savePkgs(all);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final pk = Store.pkgs;
    return Scaffold(
      appBar: AppBar(title: const Text('الباقات')),
      body: list.isEmpty
          ? const Center(child: Text('لا توجد باقات'))
          : ListView(children: [
              for (final p in list)
                ListTile(
                  leading: (pk[p.name]?.image != null &&
                          File(pk[p.name]!.image!).existsSync())
                      ? CircleAvatar(backgroundImage: FileImage(File(pk[p.name]!.image!)))
                      : const CircleAvatar(
                          backgroundColor: petrolLight,
                          child: Icon(Icons.layers, color: turq)),
                  title: Text(p.name),
                  subtitle: Text(
                      'السعر: ${fmtMoney(pk[p.name]?.price ?? 0)} • الصلاحية: ${p.validity.isEmpty ? 'غير محدودة' : p.validity}'),
                  trailing: const Icon(Icons.edit),
                  onTap: () => _edit(p),
                ),
            ]),
    );
  }
}
