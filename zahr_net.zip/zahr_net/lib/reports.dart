import 'package:flutter/material.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

class _Sold {
  final String user, profile;
  final double price;
  final DateTime? date;
  _Sold(this.user, this.profile, this.price, this.date);
}

/// المبيعات الفعلية: كل كرت استُخدم لأول مرة يُحتسب مبيعاً بسعر باقته.
class SalesReportScreen extends StatefulWidget {
  const SalesReportScreen({super.key});
  @override
  State<SalesReportScreen> createState() => _SalesReportScreenState();
}

class _SalesReportScreenState extends State<SalesReportScreen> {
  List<_Sold> sold = [];
  int unused = 0, total = 0;
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await busy(
        context,
        () => Ros.run((c) async {
              final users = await UM.users(c);
              final first = await UM.firstUse(c);
              return (users, first);
            }));
    if (r == null || !mounted) return;
    final prof = <String, String>{
      for (final b in Store.batches)
        for (final c in b.cards) c.user: b.profile
    };
    final out = <_Sold>[];
    var un = 0;
    for (final u in r.$1) {
      if (!u.usedOnce) {
        un++;
        continue;
      }
      final p = prof[u.username] ?? u.profile;
      out.add(_Sold(u.username, p, Store.priceFor(p), r.$2[u.username]));
    }
    setState(() {
      sold = out;
      unused = un;
      total = r.$1.length;
      loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    bool isDay(DateTime? d) =>
        d != null && d.year == now.year && d.month == now.month && d.day == now.day;
    bool isMonth(DateTime? d) =>
        d != null && d.year == now.year && d.month == now.month;
    double sum(Iterable<_Sold> l) => l.fold(0.0, (a, s) => a + s.price);

    final today = sold.where((s) => isDay(s.date));
    final month = sold.where((s) => isMonth(s.date));
    final byProfile = <String, List<_Sold>>{};
    final byDay = <String, List<_Sold>>{};
    for (final s in sold) {
      byProfile.putIfAbsent(s.profile.isEmpty ? '—' : s.profile, () => []).add(s);
      if (s.date != null) byDay.putIfAbsent(fmtDate(s.date!), () => []).add(s);
    }
    final days = byDay.keys.toList()..sort((a, b) => b.compareTo(a));

    Widget stat(String t, Iterable<_Sold> l) => Expanded(
          child: Card(
              child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Column(children: [
              Text(t, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 6),
              Text(fmtMoney(sum(l)),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: turq)),
              Text('${l.length} كرت',
                  style: const TextStyle(fontSize: 12, color: Colors.white70)),
            ]),
          )),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('تقارير المبيعات'), actions: [
        IconButton(onPressed: _load, icon: const Icon(Icons.sync))
      ]),
      body: !loaded
          ? const SizedBox()
          : ListView(padding: const EdgeInsets.all(12), children: [
              Row(children: [
                stat('اليوم', today),
                stat('الشهر', month),
                stat('الكل', sold)
              ]),
              Card(
                  child: ListTile(
                title: Text('كروت غير مستخدمة: $unused من $total'),
                subtitle: const Text(
                    'المبيعات تُحسب من الكروت التي استُخدمت فعلاً على الراوتر × سعر الباقة (حدّد السعر من شاشة الباقات).'),
              )),
              const Padding(
                  padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
                  child: Text('حسب الباقة',
                      style: TextStyle(fontWeight: FontWeight.bold))),
              for (final e in byProfile.entries)
                Card(
                    child: ListTile(
                        title: Text(e.key),
                        subtitle: Text('${e.value.length} كرت'),
                        trailing: Text(fmtMoney(sum(e.value))))),
              const Padding(
                  padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
                  child: Text('حسب اليوم',
                      style: TextStyle(fontWeight: FontWeight.bold))),
              for (final d in days)
                Card(
                    child: ListTile(
                        title: Text(d),
                        subtitle: Text('${byDay[d]!.length} كرت'),
                        trailing: Text(fmtMoney(sum(byDay[d]!))))),
            ]),
    );
  }
}

class UsageReportScreen extends StatefulWidget {
  const UsageReportScreen({super.key});
  @override
  State<UsageReportScreen> createState() => _UsageReportScreenState();
}

class _UsageReportScreenState extends State<UsageReportScreen> {
  List<UmUser> users = [];
  int active = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final r = await busy(
          context,
          () => Ros.run((c) async =>
              (await UM.users(c), (await UM.activeSessions(c)).length)));
      if (r != null && mounted) {
        setState(() {
          users = r.$1;
          active = r.$2;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalDown = users.fold(0, (a, u) => a + u.down);
    final totalUp = users.fold(0, (a, u) => a + u.up);
    final top = [...users]..sort((a, b) => b.used.compareTo(a.used));
    return Scaffold(
      appBar: AppBar(title: const Text('تقارير الاستخدام')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('عدد المستخدمين: ${users.length}'),
              Text('المتصلون الآن: $active'),
              Text('إجمالي التحميل: ${fmtBytes(totalDown)}'),
              Text('إجمالي الرفع: ${fmtBytes(totalUp)}'),
            ]),
          ),
        ),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
            child: Text('الأكثر استهلاكاً', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final u in top.take(30))
          Card(
              child: ListTile(
                  title: Text(u.username),
                  subtitle: Text(u.profile),
                  trailing: Text(fmtBytes(u.used)))),
      ]),
    );
  }
}
