import 'package:flutter/material.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

class SalesReportScreen extends StatelessWidget {
  const SalesReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final bs = Store.batches.where((b) => b.counted).toList();
    double sum(Iterable<Batch> l) => l.fold(0.0, (a, b) => a + b.total);
    int cnt(Iterable<Batch> l) => l.fold(0, (a, b) => a + b.cards.length);
    final today = bs.where((b) =>
        b.date.year == now.year && b.date.month == now.month && b.date.day == now.day);
    final month =
        bs.where((b) => b.date.year == now.year && b.date.month == now.month);

    final byProfile = <String, List<Batch>>{};
    for (final b in bs) {
      byProfile.putIfAbsent(b.profile, () => []).add(b);
    }
    final byDay = <String, List<Batch>>{};
    for (final b in bs) {
      byDay.putIfAbsent(fmtDate(b.date), () => []).add(b);
    }
    final days = byDay.keys.toList()..sort((a, b) => b.compareTo(a));

    Widget stat(String t, Iterable<Batch> l) => Expanded(
          child: Card(
              child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Column(children: [
              Text(t, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 6),
              Text(fmtMoney(sum(l)),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: turq)),
              Text('${cnt(l)} كرت',
                  style: const TextStyle(fontSize: 12, color: Colors.white70)),
            ]),
          )),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('تقارير المبيعات')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Row(children: [stat('اليوم', today), stat('الشهر', month), stat('الكل', bs)]),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
            child: Text('حسب الباقة', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final e in byProfile.entries)
          Card(
              child: ListTile(
                  title: Text(e.key),
                  subtitle: Text('${cnt(e.value)} كرت'),
                  trailing: Text(fmtMoney(sum(e.value))))),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
            child: Text('حسب اليوم', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final d in days)
          Card(
              child: ListTile(
                  title: Text(d),
                  subtitle: Text('${cnt(byDay[d]!)} كرت'),
                  trailing: Text(fmtMoney(sum(byDay[d]!))))),
      ]),
    );
  }
}

class UsageReportScreen extends StatefulWidget {
  const UsageReportScreen({super.key});
  @override
  State<UsageReportScreen> createState() => _UsageReportScreenState();
}

class _UsageReportScreenState extends State<UsageReportScreen> {
  List<UmUser> users = [];
  int active = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final r = await busy(
          context,
          () => Ros.run((c) async =>
              (await UM.users(c), (await UM.activeSessions(c)).length)));
      if (r != null && mounted) {
        setState(() {
          users = r.$1;
          active = r.$2;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalDown = users.fold(0, (a, u) => a + u.down);
    final totalUp = users.fold(0, (a, u) => a + u.up);
    final top = [...users]..sort((a, b) => b.used.compareTo(a.used));
    return Scaffold(
      appBar: AppBar(title: const Text('تقارير الاستخدام')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('عدد المستخدمين: ${users.length}'),
              Text('المتصلون الآن: $active'),
              Text('إجمالي التحميل: ${fmtBytes(totalDown)}'),
              Text('إجمالي الرفع: ${fmtBytes(totalUp)}'),
            ]),
          ),
        ),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
            child: Text('الأكثر استهلاكاً', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final u in top.take(30))
          Card(
              child: ListTile(
                  title: Text(u.username),
                  subtitle: Text(u.profile),
                  trailing: Text(fmtBytes(u.used)))),
      ]),
    );
  }
}
