import 'package:flutter/material.dart';
import 'auth.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final cfg = Store.router;
  late final host = TextEditingController(text: cfg.host);
  late final port = TextEditingController(text: '${cfg.port}');
  late final user = TextEditingController(text: cfg.user);
  late final pass = TextEditingController(text: cfg.pass);
  late final customer = TextEditingController(text: cfg.customer);

  RouterCfg _read() => RouterCfg(
      host: host.text.trim(),
      port: int.tryParse(port.text) ?? 8728,
      user: user.text.trim(),
      pass: pass.text,
      customer: customer.text.trim().isEmpty ? 'admin' : customer.text.trim());

  Future<void> _save() async {
    await Store.saveRouter(_read());
    if (mounted) toast(context, 'تم الحفظ');
  }

  Future<void> _test() async {
    await Store.saveRouter(_read());
    final n = await busy(context, () => Ros.run((c) async {
          final p = await UM.profiles(c);
          return p.length;
        }));
    if (n != null && mounted) {
      toast(context, 'تم الاتصال بنجاح ✓ — عدد الباقات في User Manager: $n');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('الإعدادات')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('بيانات الراوتر (MikroTik RouterOS 6)',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          field(host, 'عنوان الراوتر (IP)'),
          field(port, 'منفذ API (الافتراضي 8728)', number: true),
          field(user, 'اسم مستخدم الراوتر'),
          field(pass, 'كلمة مرور الراوتر', obscure: true),
          field(customer, 'عميل User Manager (الافتراضي admin)'),
          FilledButton(onPressed: _test, child: const Text('حفظ واختبار الاتصال')),
          const SizedBox(height: 10),
          OutlinedButton(onPressed: _save, child: const Text('حفظ فقط')),
          const SizedBox(height: 28),
          Text('الحساب: ${Store.ownerName} (مالك / مدير عام)'),
          const SizedBox(height: 10),
          OutlinedButton(
              onPressed: () => Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (_) => false),
              child: const Text('تسجيل الخروج')),
        ]),
      );
}
