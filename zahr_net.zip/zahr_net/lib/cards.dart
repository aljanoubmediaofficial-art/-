import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'designs.dart';
import 'pdf_cards.dart';
import 'store.dart';
import 'ui.dart';
import 'um.dart';

/// إضافة كروت User Manager بالجملة وربطها بالباقة.
class AddCardsScreen extends StatefulWidget {
  const AddCardsScreen({super.key, this.template});
  final Template? template;
  @override
  State<AddCardsScreen> createState() => _AddCardsScreenState();
}

class _AddCardsScreenState extends State<AddCardsScreen> {
  final count = TextEditingController(text: '100');
  final prefix = TextEditingController();
  final userLen = TextEditingController(text: '6');
  final passLen = TextEditingController(text: '6');
  final price = TextEditingController(text: '0');
  bool same = true, alnum = false, noPass = false;
  String? profile;
  List<String> profiles = [];
  String? loadError;

  @override
  void initState() {
    super.initState();
    final t = widget.template;
    if (t != null) _apply(t);
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadProfiles());
  }

  void _apply(Template t) {
    count.text = '${t.count}';
    prefix.text = t.prefix;
    userLen.text = '${t.userLen}';
    passLen.text = '${t.passLen}';
    price.text = fmtMoney(t.price);
    same = t.same;
    alnum = t.alnum;
    noPass = t.noPass;
    profile = t.profile;
  }

  Future<void> _loadProfiles() async {
    final p = await busy(context, () => Ros.run((c) => UM.profiles(c)));
    if (!mounted) return;
    setState(() {
      if (p == null) {
        loadError = 'تعذر تحميل الباقات';
      } else {
        profiles = p.map((e) => e.name).toList();
        if (profile != null && !profiles.contains(profile)) profile = null;
        profile ??= profiles.isNotEmpty ? profiles.first : null;
      }
    });
  }

  Template? _template(String name) {
    final n = int.tryParse(count.text);
    if (profile == null || n == null) return null;
    return Template(
        name: name,
        profile: profile!,
        prefix: prefix.text.trim(),
        count: n,
        userLen: int.tryParse(userLen.text) ?? 6,
        passLen: int.tryParse(passLen.text) ?? 6,
        same: same,
        alnum: alnum,
        noPass: noPass,
        price: double.tryParse(price.text) ?? 0);
  }

  Future<void> _saveTemplate() async {
    final ctl = TextEditingController();
    final name = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('اسم القالب'),
              content: TextField(controller: ctl, autofocus: true),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('إلغاء')),
                TextButton(
                    onPressed: () => Navigator.pop(context, ctl.text.trim()),
                    child: const Text('حفظ')),
              ],
            ));
    if (name == null || name.isEmpty) return;
    final t = _template(name);
    if (t == null) {
      if (mounted) toast(context, 'اختر الباقة وأدخل العدد');
      return;
    }
    final all = Store.templates..removeWhere((e) => e.name == name);
    all.add(t);
    await Store.saveTemplates(all);
    if (mounted) toast(context, 'تم حفظ القالب');
  }

  Future<void> _presets() async {
    final list = Store.templates;
    if (list.isEmpty) {
      toast(context, 'لا توجد إعدادات محفوظة. استخدم "حفظ كقالب".');
      return;
    }
    final t = await showModalBottomSheet<Template>(
        context: context,
        builder: (_) => SafeArea(
                child: ListView(shrinkWrap: true, children: [
              for (final t in list)
                ListTile(
                    title: Text(t.name),
                    subtitle: Text('${t.profile} • ${t.count} كرت'),
                    onTap: () => Navigator.pop(context, t)),
            ])));
    if (t != null) setState(() => _apply(t));
  }

  Future<void> _generate() async {
    final t = _template('');
    if (t == null) {
      toast(context, 'اختر الباقة وأدخل العدد');
      return;
    }
    if (t.count < 1 || t.count > 5000) {
      toast(context, 'العدد يجب أن يكون بين 1 و 5000 في الدفعة الواحدة');
      return;
    }
    if (t.userLen < 3 || t.passLen < 3) {
      toast(context, 'طول الاسم وكلمة المرور 3 على الأقل');
      return;
    }
    final space = pow(alnum ? 31 : 10, t.userLen);
    if (t.count > space * 0.5) {
      toast(context, 'زِد طول اسم المستخدم، فالعدد المطلوب كبير جداً');
      return;
    }
    final prog = ValueNotifier<double>(0);
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
              title: const Text('جاري توليد الكروت...'),
              content: ValueListenableBuilder<double>(
                valueListenable: prog,
                builder: (_, v, __) => Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      LinearProgressIndicator(value: v, color: turq),
                      const SizedBox(height: 8),
                      Text('${(v * 100).round()}%'),
                    ]),
              ),
            ));
    final nav = Navigator.of(context);
    try {
      final cards = await Ros.run((c) => UM.generate(
          c,
          GenSpec(
              count: t.count,
              profile: t.profile,
              prefix: t.prefix,
              userLen: t.userLen,
              passLen: t.passLen,
              same: t.same,
              alnum: t.alnum,
              noPass: t.noPass),
          (f) => prog.value = f.clamp(0, 1)));
      final b = Batch(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          date: DateTime.now(),
          profile: t.profile,
          price: t.price,
          cards: cards);
      await Store.addBatch(b);
      nav.pop();
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => BatchDetailScreen(batch: b)));
    } catch (e) {
      nav.pop();
      if (mounted) toast(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('إضافة كروت'), actions: [
          IconButton(
              tooltip: 'إعدادات محفوظة',
              icon: const Icon(Icons.bookmarks),
              onPressed: _presets)
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          DropdownButtonFormField<String>(
            value: profile,
            decoration: InputDecoration(
                labelText: 'الباقة', errorText: loadError),
            items: [
              for (final p in profiles) DropdownMenuItem(value: p, child: Text(p))
            ],
            onChanged: (v) => setState(() {
              profile = v;
              final pr = Store.priceFor(v ?? '');
              if (pr > 0) price.text = fmtMoney(pr);
            }),
          ),
          const SizedBox(height: 12),
          field(count, 'عدد الكروت', number: true),
          field(prefix, 'بادئة اسم المستخدم (اختياري)'),
          Row(children: [
            Expanded(child: field(userLen, 'طول اسم المستخدم', number: true)),
            if (!noPass && !same) ...[
              const SizedBox(width: 12),
              Expanded(child: field(passLen, 'طول كلمة المرور', number: true)),
            ],
          ]),
          field(price, 'سعر الكرت', number: true),
          SwitchListTile(
              value: noPass,
              onChanged: (v) => setState(() => noPass = v),
              title: const Text('بدون كلمة مرور (اسم مستخدم فقط)')),
          if (!noPass)
            SwitchListTile(
                value: same,
                onChanged: (v) => setState(() => same = v),
                title: const Text('كلمة المرور = اسم المستخدم')),
          SwitchListTile(
              value: alnum,
              onChanged: (v) => setState(() => alnum = v),
              title: Text(alnum ? 'أرقام وحروف' : 'أرقام فقط')),
          const SizedBox(height: 12),
          FilledButton.icon(
              onPressed: _generate,
              icon: const Icon(Icons.bolt),
              label: const Text('توليد الكروت')),
          const SizedBox(height: 10),
          OutlinedButton.icon(
              onPressed: _saveTemplate,
              icon: const Icon(Icons.save),
              label: const Text('حفظ كقالب')),
        ]),
      );
}

class BatchesScreen extends StatefulWidget {
  const BatchesScreen({super.key});
  @override
  State<BatchesScreen> createState() => _BatchesScreenState();
}

class _BatchesScreenState extends State<BatchesScreen> {
  @override
  Widget build(BuildContext context) {
    final list = Store.batches;
    return Scaffold(
      appBar: AppBar(title: const Text('سجل الكروت')),
      body: list.isEmpty
          ? const Center(child: Text('لا توجد دفعات كروت بعد'))
          : ListView(padding: const EdgeInsets.all(12), children: [
              for (final b in list)
                Card(
                  child: ListTile(
                    leading: Icon(Icons.receipt_long,
                        color: b.counted ? turq : Colors.white38),
                    title: Text('${b.profile} • ${b.cards.length} كرت'),
                    subtitle: Text(
                        '${fmtDate(b.date)} • الإجمالي ${fmtMoney(b.price * b.cards.length)}'),
                    onTap: () async {
                      await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => BatchDetailScreen(batch: b)));
                      if (mounted) setState(() {});
                    },
                  ),
                ),
            ]),
    );
  }
}

class BatchDetailScreen extends StatefulWidget {
  const BatchDetailScreen({super.key, required this.batch});
  final Batch batch;
  @override
  State<BatchDetailScreen> createState() => _BatchDetailScreenState();
}

class _BatchDetailScreenState extends State<BatchDetailScreen> {
  int cols = 4;
  String design = 'default';

  Batch get b => widget.batch;

  String get _text => b.cards
      .map((c) => c.pass.isEmpty || c.user == c.pass ? c.user : '${c.user}  ${c.pass}')
      .join('\n');

  Future<void> _deleteAll() async {
    if (!await confirm(context,
        'سيتم حذف هذه الكروت من الراوتر ومن السجل نهائياً. متابعة؟')) {
      return;
    }
    final ok = await busy(context, () async {
      await Ros.run((c) => UM.removeByNames(c, b.cards.map((e) => e.user).toList()));
      await Store.removeBatch(b);
      return true;
    });
    if (ok == true && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('دفعة ${fmtDate(b.date)}')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text('${b.profile} • ${b.cards.length} كرت • سعر الكرت ${fmtMoney(b.price)}',
                  style: const TextStyle(fontSize: 16)),
              SwitchListTile(
                  value: b.counted,
                  onChanged: (v) async {
                    setState(() => b.counted = v);
                    await Store.updateBatches();
                  },
                  title: const Text('احتساب ضمن المبيعات')),
              Row(children: [
                const Text('عدد الكروت في الصف: '),
                const SizedBox(width: 8),
                DropdownButton<int>(
                    value: cols,
                    items: [3, 4, 5, 6]
                        .map((e) => DropdownMenuItem(value: e, child: Text('$e')))
                        .toList(),
                    onChanged: (v) => setState(() => cols = v ?? 4)),
              ]),
              designDropdown(design, (v) => setState(() => design = v)),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                    child: FilledButton.icon(
                        onPressed: () =>
                            busy(context, () => printBatch(b, cols: cols, design: resolveDesign(design, b.profile))),
                        icon: const Icon(Icons.print),
                        label: const Text('طباعة'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: () =>
                            busy(context, () => shareBatchPdf(b, cols: cols, design: resolveDesign(design, b.profile))),
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text('PDF'))),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: _text));
                          if (mounted) toast(context, 'تم نسخ الكروت');
                        },
                        icon: const Icon(Icons.copy),
                        label: const Text('نسخ'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: _deleteAll,
                        icon: const Icon(Icons.delete_forever),
                        label: const Text('حذف الدفعة'))),
              ]),
            ]),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              itemCount: b.cards.length,
              itemBuilder: (_, i) {
                final c = b.cards[i];
                return ListTile(
                  dense: true,
                  leading: Text('${i + 1}'),
                  title: Text(c.user,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 16)),
                  trailing: Text(c.pass.isEmpty || c.user == c.pass ? '' : c.pass,
                      style: const TextStyle(fontFamily: 'monospace')),
                );
              },
            ),
          ),
        ]),
      );
}
