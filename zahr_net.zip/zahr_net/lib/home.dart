import 'package:flutter/material.dart';
import 'cards.dart';
import 'manage.dart';
import 'reports.dart';
import 'settings.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.openSettings = false});
  final bool openSettings;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.openSettings) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _open(const SettingsScreen()));
    }
  }

  void _open(Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final items = <(IconData, String, Widget)>[
      (Icons.add_card, 'إضافة كروت', const AddCardsScreen()),
      (Icons.dashboard_customize, 'قوالب الكروت', const TemplatesScreen()),
      (Icons.inventory_2, 'سجل الكروت', const BatchesScreen()),
      (Icons.people, 'المستخدمون', const UsersScreen()),
      (Icons.wifi_tethering, 'الجلسات النشطة', const SessionsScreen()),
      (Icons.layers, 'الباقات', const ProfilesScreen()),
      (Icons.payments, 'تقارير المبيعات', const SalesReportScreen()),
      (Icons.bar_chart, 'تقارير الاستخدام', const UsageReportScreen()),
      (Icons.settings, 'الإعدادات', const SettingsScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('الزهر نت'), automaticallyImplyLeading: false),
      body: Column(children: [
        const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Logo(height: 70)),
        Expanded(
          child: GridView.count(
            crossAxisCount: 2,
            padding: const EdgeInsets.all(16),
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: 1.25,
            children: [
              for (final it in items)
                InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _open(it.$3),
                  child: Card(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(it.$1, size: 40, color: turq),
                        const SizedBox(height: 8),
                        Text(it.$2,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}
