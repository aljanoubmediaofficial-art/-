import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

class RosError implements Exception {
  final String message;
  RosError(this.message);
  @override
  String toString() => message;
}

class RosReply {
  final List<Map<String, String>> rows;
  final Map<String, String> done;
  final String? error;
  RosReply(this.rows, this.done, {this.error});
}

/// عميل بروتوكول RouterOS API (المنفذ 8728) مع دعم الإرسال المتوازي (tags)
/// لتوليد آلاف الكروت بسرعة.
class RosClient {
  Socket? _sock;
  final Queue<int> _buf = Queue<int>();
  Completer<void>? _wake;
  bool _closed = false;

  Future<void> connect(String host, int port, String user, String pass) async {
    try {
      _sock = await Socket.connect(host, port,
          timeout: const Duration(seconds: 8));
    } catch (_) {
      throw RosError(
          'تعذر الاتصال بالراوتر ($host:$port). تأكد من العنوان وتفعيل خدمة API (IP > Services > api).');
    }
    _sock!.setOption(SocketOption.tcpNoDelay, true);
    _sock!.listen((d) {
      _buf.addAll(d);
      _poke();
    }, onError: (_) {
      _closed = true;
      _poke();
    }, onDone: () {
      _closed = true;
      _poke();
    });
    final r = await command(['/login', '=name=$user', '=password=$pass']);
    final ret = r.done['ret'];
    if (ret != null) {
      // الإصدارات القديمة (قبل 6.43): تحدّي MD5
      final chal = <int>[];
      for (var i = 0; i + 1 < ret.length; i += 2) {
        chal.add(int.parse(ret.substring(i, i + 2), radix: 16));
      }
      final h = md5.convert([0, ...utf8.encode(pass), ...chal]).toString();
      await command(['/login', '=name=$user', '=response=00$h']);
    }
  }

  void close() {
    _sock?.destroy();
    _sock = null;
  }

  void _poke() {
    final w = _wake;
    _wake = null;
    if (w != null && !w.isCompleted) w.complete();
  }

  Future<void> _need(int n) async {
    while (_buf.length < n) {
      if (_closed) throw RosError('انقطع الاتصال بالراوتر');
      _wake = Completer<void>();
      await _wake!.future.timeout(const Duration(seconds: 25),
          onTimeout: () => throw RosError('انتهت مهلة انتظار رد الراوتر'));
    }
  }

  List<int> _encLen(int l) {
    if (l < 0x80) return [l];
    if (l < 0x4000) {
      l |= 0x8000;
      return [(l >> 8) & 0xFF, l & 0xFF];
    }
    if (l < 0x200000) {
      l |= 0xC00000;
      return [(l >> 16) & 0xFF, (l >> 8) & 0xFF, l & 0xFF];
    }
    if (l < 0x10000000) {
      l |= 0xE0000000;
      return [(l >> 24) & 0xFF, (l >> 16) & 0xFF, (l >> 8) & 0xFF, l & 0xFF];
    }
    return [0xF0, (l >> 24) & 0xFF, (l >> 16) & 0xFF, (l >> 8) & 0xFF, l & 0xFF];
  }

  Future<int> _readLen() async {
    await _need(1);
    var c = _buf.removeFirst();
    if ((c & 0x80) == 0) return c;
    if ((c & 0xC0) == 0x80) {
      await _need(1);
      return ((c & 0x3F) << 8) + _buf.removeFirst();
    }
    if ((c & 0xE0) == 0xC0) {
      await _need(2);
      c &= 0x1F;
      for (var i = 0; i < 2; i++) {
        c = (c << 8) + _buf.removeFirst();
      }
      return c;
    }
    if ((c & 0xF0) == 0xE0) {
      await _need(3);
      c &= 0x0F;
      for (var i = 0; i < 3; i++) {
        c = (c << 8) + _buf.removeFirst();
      }
      return c;
    }
    await _need(4);
    var r = 0;
    for (var i = 0; i < 4; i++) {
      r = (r << 8) + _buf.removeFirst();
    }
    return r;
  }

  Future<List<String>> _readSentence() async {
    final words = <String>[];
    while (true) {
      final len = await _readLen();
      if (len == 0) return words;
      await _need(len);
      final bytes = Uint8List(len);
      for (var i = 0; i < len; i++) {
        bytes[i] = _buf.removeFirst();
      }
      words.add(utf8.decode(bytes, allowMalformed: true));
    }
  }

  void _send(List<String> words) {
    final b = BytesBuilder();
    for (final w in words) {
      final d = utf8.encode(w);
      b.add(_encLen(d.length));
      b.add(d);
    }
    b.addByte(0);
    _sock!.add(b.takeBytes());
  }

  Map<String, String> _attrs(List<String> s) {
    final m = <String, String>{};
    for (final w in s.skip(1)) {
      if (w.startsWith('.tag=')) {
        m['.tag'] = w.substring(5);
      } else if (w.startsWith('=')) {
        final i = w.indexOf('=', 1);
        if (i > 0) m[w.substring(1, i)] = w.substring(i + 1);
      }
    }
    return m;
  }

  /// أمر واحد ينتظر النتيجة.
  Future<RosReply> command(List<String> words) async {
    _send(words);
    final rows = <Map<String, String>>[];
    String? trap;
    while (true) {
      final s = await _readSentence();
      if (s.isEmpty) continue;
      switch (s.first) {
        case '!re':
          rows.add(_attrs(s));
          break;
        case '!trap':
          trap = _attrs(s)['message'] ?? 'خطأ من الراوتر';
          break;
        case '!fatal':
          throw RosError(s.length > 1 ? s[1] : 'خطأ فادح من الراوتر');
        case '!done':
          if (trap != null) throw RosError(trap);
          return RosReply(rows, _attrs(s));
      }
    }
  }

  /// إرسال عدد كبير من الأوامر دفعة واحدة (متوازي) – أسرع بعشرات المرات.
  Future<List<RosReply>> bulk(List<List<String>> cmds,
      {void Function(int done)? onProgress, int chunk = 150}) async {
    final out = List<RosReply>.filled(cmds.length, RosReply([], {}));
    for (var start = 0; start < cmds.length; start += chunk) {
      final end = min(start + chunk, cmds.length);
      for (var i = start; i < end; i++) {
        _send([...cmds[i], '.tag=$i']);
      }
      final rows = <int, List<Map<String, String>>>{};
      final traps = <int, String>{};
      var pending = end - start;
      while (pending > 0) {
        final s = await _readSentence();
        if (s.isEmpty) continue;
        if (s.first == '!fatal') {
          throw RosError(s.length > 1 ? s[1] : 'خطأ فادح من الراوتر');
        }
        final a = _attrs(s);
        final tag = int.tryParse(a['.tag'] ?? '');
        if (tag == null) continue;
        switch (s.first) {
          case '!re':
            rows.putIfAbsent(tag, () => []).add(a);
            break;
          case '!trap':
            traps[tag] = a['message'] ?? 'خطأ';
            break;
          case '!done':
            out[tag] = RosReply(rows[tag] ?? [], a, error: traps[tag]);
            pending--;
            break;
        }
      }
      onProgress?.call(end);
    }
    return out;
  }
}
