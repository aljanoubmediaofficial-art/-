import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'store.dart';

final _ascii = RegExp(r'^[\x20-\x7E]+$');

/// يبني ملف PDF بصفحات A4 مليئة بالكروت (الشعار + اسم المستخدم + كلمة المرور).
Future<Uint8List> _designPdf(Batch b, CardDesign d) async {
  pw.MemoryImage? bg;
  if (d.bg != null && await File(d.bg!).exists()) {
    try {
      bg = pw.MemoryImage(await File(d.bg!).readAsBytes());
    } catch (_) {}
  }
  final font = pw.Font.courierBold();
  const margin = 14.0;
  final cw = d.w * PdfPageFormat.mm;
  final ch = d.h * PdfPageFormat.mm;
  final per = ((PdfPageFormat.a4.width - margin * 2) / cw).floor().clamp(1, 20);
  final color = PdfColor.fromInt(d.color);
  pw.Widget txt(String t, double x, double y, double size) => pw.Positioned(
      left: x * cw - 100,
      top: y * ch - size * 0.6,
      child: pw.SizedBox(
          width: 200,
          child: pw.Center(
              child: pw.Text(t,
                  style: pw.TextStyle(font: font, fontSize: size, color: color)))));
  pw.Widget one(Voucher v) => pw.Container(
        width: cw,
        height: ch,
        child: pw.Stack(overflow: pw.Overflow.clip, children: [
          if (bg != null)
            pw.Positioned.fill(child: pw.Image(bg, fit: pw.BoxFit.fill))
          else
            pw.Positioned.fill(
                child: pw.Container(
                    decoration: pw.BoxDecoration(
                        border:
                            pw.Border.all(color: PdfColors.grey600, width: 0.5)))),
          txt(v.user, d.ux, d.uy, d.usz),
          if (d.showPass && v.pass.isNotEmpty && v.pass != v.user)
            txt(v.pass, d.px, d.py, d.psz),
        ]),
      );
  final doc = pw.Document();
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(margin),
    build: (_) => [
      pw.Wrap(spacing: 0, runSpacing: 0, children: b.cards.map(one).toList())
    ],
  ));
  return doc.save();
}

Future<Uint8List> buildCardsPdf(Batch b,
    {int cols = 4, CardDesign? design}) async {
  if (design != null) return _designPdf(b, design);
  final logo = pw.MemoryImage(
      (await rootBundle.load('assets/logo.png')).buffer.asUint8List());
  final mono = pw.Font.courier();
  final monoBold = pw.Font.courierBold();
  const margin = 18.0;
  final pageW = PdfPageFormat.a4.width - margin * 2;
  final cw = pageW / cols - 0.2;
  final ch = cw * 0.64;
  final big = cw / 9.5;
  final small = cw / 17;
  final petrol = PdfColor.fromInt(0xFF0A3F52);
  final profileTxt = _ascii.hasMatch(b.profile) ? b.profile : '';
  final footer = [
    if (profileTxt.isNotEmpty) profileTxt,
    if (b.price > 0) b.price.toStringAsFixed(b.price % 1 == 0 ? 0 : 2),
  ].join('  |  ');

  pw.Widget one(Voucher v) {
    final noPw = v.pass.isEmpty;
    final samePw = noPw || v.user == v.pass;
    return pw.Container(
      width: cw,
      height: ch,
      padding: const pw.EdgeInsets.all(4),
      decoration: pw.BoxDecoration(
          border: pw.Border.all(color: petrol, width: 0.8)),
      child: pw.Column(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.SizedBox(
              height: ch * 0.27, child: pw.Image(logo, fit: pw.BoxFit.contain)),
          pw.Column(children: [
            pw.Text(noPw ? 'USER' : (samePw ? 'USER / PASS' : 'USER'),
                style: pw.TextStyle(font: mono, fontSize: small, color: petrol)),
            pw.Text(v.user,
                style: pw.TextStyle(font: monoBold, fontSize: big)),
            if (!samePw) ...[
              pw.Text('PASS',
                  style:
                      pw.TextStyle(font: mono, fontSize: small, color: petrol)),
              pw.Text(v.pass,
                  style: pw.TextStyle(font: monoBold, fontSize: big)),
            ],
          ]),
          pw.Text(footer.isEmpty ? ' ' : footer,
              style: pw.TextStyle(font: mono, fontSize: small)),
        ],
      ),
    );
  }

  final doc = pw.Document();
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(margin),
    build: (_) => [
      pw.Wrap(spacing: 0, runSpacing: 0, children: b.cards.map(one).toList())
    ],
  ));
  return doc.save();
}

Future<void> printBatch(Batch b, {int cols = 4, CardDesign? design}) async {
  final bytes = await buildCardsPdf(b, cols: cols, design: design);
  await Printing.layoutPdf(onLayout: (_) async => bytes, name: 'ALZHER-NET');
}

Future<void> shareBatchPdf(Batch b, {int cols = 4, CardDesign? design}) async {
  final bytes = await buildCardsPdf(b, cols: cols, design: design);
  await Printing.sharePdf(bytes: bytes, filename: 'ALZHER-NET-${b.id}.pdf');
}
