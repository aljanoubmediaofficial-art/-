import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'store.dart';

final _ascii = RegExp(r'^[\x20-\x7E]+$');

/// يبني ملف PDF بصفحات A4 مليئة بالكروت (الشعار + اسم المستخدم + كلمة المرور).
Future<Uint8List> buildCardsPdf(Batch b, {int cols = 4}) async {
  final logo = pw.MemoryImage(
      (await rootBundle.load('assets/logo.png')).buffer.asUint8List());
  final mono = pw.Font.courier();
  final monoBold = pw.Font.courierBold();
  const margin = 18.0;
  final pageW = PdfPageFormat.a4.width - margin * 2;
  final cw = pageW / cols - 0.2;
  final ch = cw * 0.64;
  final big = cw / 9.5;
  final small = cw / 17;
  final petrol = PdfColor.fromInt(0xFF0A3F52);
  final profileTxt = _ascii.hasMatch(b.profile) ? b.profile : '';
  final footer = [
    if (profileTxt.isNotEmpty) profileTxt,
    if (b.price > 0) b.price.toStringAsFixed(b.price % 1 == 0 ? 0 : 2),
  ].join('  |  ');

  pw.Widget one(Voucher v) {
    final samePw = v.user == v.pass;
    return pw.Container(
      width: cw,
      height: ch,
      padding: const pw.EdgeInsets.all(4),
      decoration: pw.BoxDecoration(
          border: pw.Border.all(color: petrol, width: 0.8)),
      child: pw.Column(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.SizedBox(
              height: ch * 0.27, child: pw.Image(logo, fit: pw.BoxFit.contain)),
          pw.Column(children: [
            pw.Text(samePw ? 'USER / PASS' : 'USER',
                style: pw.TextStyle(font: mono, fontSize: small, color: petrol)),
            pw.Text(v.user,
                style: pw.TextStyle(font: monoBold, fontSize: big)),
            if (!samePw) ...[
              pw.Text('PASS',
                  style:
                      pw.TextStyle(font: mono, fontSize: small, color: petrol)),
              pw.Text(v.pass,
                  style: pw.TextStyle(font: monoBold, fontSize: big)),
            ],
          ]),
          pw.Text(footer.isEmpty ? ' ' : footer,
              style: pw.TextStyle(font: mono, fontSize: small)),
        ],
      ),
    );
  }

  final doc = pw.Document();
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(margin),
    build: (_) => [
      pw.Wrap(spacing: 0, runSpacing: 0, children: b.cards.map(one).toList())
    ],
  ));
  return doc.save();
}

Future<void> printBatch(Batch b, {int cols = 4}) async {
  final bytes = await buildCardsPdf(b, cols: cols);
  await Printing.layoutPdf(onLayout: (_) async => bytes, name: 'ALZHER-NET');
}

Future<void> shareBatchPdf(Batch b, {int cols = 4}) async {
  final bytes = await buildCardsPdf(b, cols: cols);
  await Printing.sharePdf(bytes: bytes, filename: 'ALZHER-NET-${b.id}.pdf');
}
