import 'dart:math';
import 'ros.dart';
import 'store.dart';

class Ros {
  static Future<T> run<T>(Future<T> Function(RosClient) fn) async {
    final c = Store.router;
    if (c.host.isEmpty) {
      throw RosError('أدخل بيانات الراوتر من الإعدادات أولاً');
    }
    final cl = RosClient();
    try {
      await cl.connect(c.host, c.port, c.user, c.pass);
      return await fn(cl);
    } finally {
      cl.close();
    }
  }
}

class GenSpec {
  final int count, userLen, passLen;
  final String profile, prefix;
  final bool same, alnum;
  GenSpec(
      {required this.count,
      required this.profile,
      this.prefix = '',
      this.userLen = 6,
      this.passLen = 6,
      this.same = true,
      this.alnum = false});
}

class UmUser {
  final String id, username, profile;
  final bool disabled;
  final int down, up;
  final String uptime;
  UmUser(this.id, this.username, this.profile, this.disabled, this.down,
      this.up, this.uptime);
  int get used => down + up;
}

class UmProfile {
  final String name, validity, owner;
  UmProfile(this.name, this.validity, this.owner);
}

/// أوامر User Manager لـ RouterOS 6 (الإصدار 5 من UM): /tool/user-manager
class UM {
  static const _base = '/tool/user-manager';
  static final _rnd = Random.secure();
  static const _digits = '0123456789';
  static const _alnum = 'abcdefghjkmnpqrstuvwxyz23456789';

  static String rand(int len, bool alnum) {
    final cs = alnum ? _alnum : _digits;
    return List.generate(len, (_) => cs[_rnd.nextInt(cs.length)]).join();
  }

  static int _int(String? s) => int.tryParse(s ?? '') ?? 0;

  static Future<List<UmProfile>> profiles(RosClient c) async {
    final r = await c.command(['$_base/profile/print']);
    return r.rows
        .map((m) => UmProfile(
            m['name'] ?? '', m['validity'] ?? '', m['owner'] ?? ''))
        .where((p) => p.name.isNotEmpty)
        .toList();
  }

  static Future<List<UmUser>> users(RosClient c) async {
    final r = await c.command(['$_base/user/print']);
    return r.rows
        .map((m) => UmUser(
              m['.id'] ?? '',
              m['username'] ?? '',
              m['actual-profile'] ?? '',
              m['disabled'] == 'true',
              _int(m['download-used']),
              _int(m['upload-used']),
              m['uptime-used'] ?? '',
            ))
        .toList();
  }

  static Future<List<Map<String, String>>> activeSessions(RosClient c) async {
    final r = await c.command(['$_base/session/print', '?active=yes']);
    return r.rows;
  }

  static Future<void> setDisabled(
      RosClient c, List<String> ids, bool disabled) async {
    for (var i = 0; i < ids.length; i += 100) {
      final part = ids.sublist(i, min(i + 100, ids.length)).join(',');
      await c.command(
          ['$_base/user/${disabled ? 'disable' : 'enable'}', '=numbers=$part']);
    }
  }

  static Future<void> remove(RosClient c, List<String> ids) async {
    for (var i = 0; i < ids.length; i += 100) {
      final part = ids.sublist(i, min(i + 100, ids.length)).join(',');
      await c.command(['$_base/user/remove', '=numbers=$part']);
    }
  }

  static Future<void> removeByNames(RosClient c, List<String> names) async {
    final all = await users(c);
    final set = names.toSet();
    final ids = all.where((u) => set.contains(u.username)).map((u) => u.id);
    if (ids.isNotEmpty) await remove(c, ids.toList());
  }

  /// توليد كروت بالجملة: إنشاء المستخدم ثم ربطه بالباقة، بشكل متوازي.
  /// يعيد عدد الكروت المطلوب بالضبط (يعوّض أي تكرار تلقائياً).
  static Future<List<Voucher>> generate(
      RosClient c, GenSpec s, void Function(double f) progress) async {
    final cust = Store.router.customer;
    final made = <Voucher>[];
    final used = <String>{};
    String? lastError;
    for (var attempt = 0; attempt < 6 && made.length < s.count; attempt++) {
      final need = s.count - made.length;
      final cands = <Voucher>[];
      var guard = 0;
      while (cands.length < need && guard++ < need * 50) {
        final u = s.prefix + rand(s.userLen, s.alnum);
        if (used.add(u)) {
          cands.add(Voucher(u, s.same ? u : rand(s.passLen, s.alnum)));
        }
      }
      if (cands.isEmpty) break;

      final adds = [
        for (final k in cands)
          [
            '$_base/user/add',
            '=customer=$cust',
            '=username=${k.user}',
            '=password=${k.pass}',
            '=shared-users=1',
          ]
      ];
      final r1 = await c.bulk(adds,
          onProgress: (d) => progress((made.length + d * 0.5) / s.count));

      final okIdx = <int>[];
      for (var i = 0; i < r1.length; i++) {
        if (r1[i].error == null && r1[i].done['ret'] != null) {
          okIdx.add(i);
        } else {
          lastError = r1[i].error ?? lastError;
        }
      }
      if (okIdx.isEmpty) {
        throw RosError(lastError ??
            'فشل إنشاء المستخدمين. تأكد أن حزمة user-manager مفعّلة على الراوتر.');
      }

      final acts = [
        for (final i in okIdx)
          [
            '$_base/user/create-and-activate-profile',
            '=numbers=${r1[i].done['ret']}',
            '=customer=$cust',
            '=profile=${s.profile}',
          ]
      ];
      final r2 = await c.bulk(acts,
          onProgress: (d) =>
              progress((made.length + okIdx.length * 0.5 + d * 0.5) / s.count));

      final badIds = <String>[];
      for (var j = 0; j < okIdx.length; j++) {
        final i = okIdx[j];
        if (r2[j].error == null) {
          made.add(cands[i]);
        } else {
          lastError = r2[j].error;
          badIds.add(r1[i].done['ret']!);
        }
      }
      if (badIds.isNotEmpty) {
        try {
          await remove(c, badIds);
        } catch (_) {}
        if (made.isEmpty) {
          throw RosError(lastError ?? 'فشل ربط الكروت بالباقة "${s.profile}"');
        }
      }
    }
    if (made.length < s.count) {
      throw RosError(
          'تم إنشاء ${made.length} من ${s.count} فقط. ${lastError ?? ''}');
    }
    progress(1);
    return made;
  }
}
