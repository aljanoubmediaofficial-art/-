import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Voucher {
  final String user, pass;
  const Voucher(this.user, this.pass);
  Map<String, dynamic> toJson() => {'u': user, 'p': pass};
  factory Voucher.fromJson(Map<String, dynamic> j) =>
      Voucher(j['u'] as String, j['p'] as String);
}

class Batch {
  final String id;
  final DateTime date;
  final String profile;
  final double price;
  bool counted;
  final List<Voucher> cards;
  Batch(
      {required this.id,
      required this.date,
      required this.profile,
      required this.price,
      this.counted = true,
      required this.cards});

  double get total => counted ? price * cards.length : 0;

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'profile': profile,
        'price': price,
        'counted': counted,
        'cards': cards.map((c) => c.toJson()).toList(),
      };
  factory Batch.fromJson(Map<String, dynamic> j) => Batch(
        id: j['id'] as String,
        date: DateTime.parse(j['date'] as String),
        profile: j['profile'] as String,
        price: (j['price'] as num).toDouble(),
        counted: j['counted'] as bool? ?? true,
        cards: (j['cards'] as List)
            .map((e) => Voucher.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class Template {
  String name, profile, prefix;
  int count, userLen, passLen;
  bool same, alnum, noPass;
  double price;
  Template(
      {required this.name,
      required this.profile,
      this.prefix = '',
      this.count = 100,
      this.userLen = 6,
      this.passLen = 6,
      this.same = true,
      this.alnum = false,
      this.noPass = false,
      this.price = 0});
  Map<String, dynamic> toJson() => {
        'name': name,
        'profile': profile,
        'prefix': prefix,
        'count': count,
        'userLen': userLen,
        'passLen': passLen,
        'same': same,
        'alnum': alnum,
        'noPass': noPass,
        'price': price,
      };
  factory Template.fromJson(Map<String, dynamic> j) => Template(
        name: j['name'] as String,
        profile: j['profile'] as String,
        prefix: j['prefix'] as String? ?? '',
        count: j['count'] as int? ?? 100,
        userLen: j['userLen'] as int? ?? 6,
        passLen: j['passLen'] as int? ?? 6,
        same: j['same'] as bool? ?? true,
        alnum: j['alnum'] as bool? ?? false,
        noPass: j['noPass'] as bool? ?? false,
        price: (j['price'] as num? ?? 0).toDouble(),
      );
}

class RouterCfg {
  String host, user, pass, customer;
  int port;
  RouterCfg(
      {this.host = '',
      this.port = 8728,
      this.user = 'admin',
      this.pass = '',
      this.customer = 'admin'});
}

/// تخزين محلي على الجوال: الحساب، إعدادات الراوتر، القوالب، وسجل الكروت.
class Store {
  static late SharedPreferences _p;
  static late File _file;
  static late String dir;
  static final List<Batch> batches = [];

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final d = await getApplicationDocumentsDirectory();
    dir = d.path;
    _file = File('${d.path}/alzhernet_batches.json');
    if (await _file.exists()) {
      try {
        final l = jsonDecode(await _file.readAsString()) as List;
        batches
          ..clear()
          ..addAll(l.map((e) => Batch.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    }
  }

  // ---- الحساب (المالك / المدير العام) ----
  static String _hash(String pw) =>
      sha256.convert(utf8.encode('alzhernet|$pw')).toString();
  static bool get hasOwner => _p.getString('ownerHash') != null;
  static String get ownerName => _p.getString('ownerName') ?? 'المالك';
  static Future<void> createOwner(String name, String pw) async {
    await _p.setString('ownerName', name);
    await _p.setString('ownerHash', _hash(pw));
  }

  static bool checkPassword(String pw) => _p.getString('ownerHash') == _hash(pw);

  // ---- الراوتر ----
  static RouterCfg get router => RouterCfg(
        host: _p.getString('r_host') ?? '',
        port: _p.getInt('r_port') ?? 8728,
        user: _p.getString('r_user') ?? 'admin',
        pass: _p.getString('r_pass') ?? '',
        customer: _p.getString('r_customer') ?? 'admin',
      );
  static Future<void> saveRouter(RouterCfg c) async {
    await _p.setString('r_host', c.host);
    await _p.setInt('r_port', c.port);
    await _p.setString('r_user', c.user);
    await _p.setString('r_pass', c.pass);
    await _p.setString('r_customer', c.customer);
  }

  // ---- القوالب ----
  static List<Template> get templates {
    final l = _p.getStringList('templates') ?? [];
    return l
        .map((e) => Template.fromJson(Map<String, dynamic>.from(jsonDecode(e))))
        .toList();
  }

  static Future<void> saveTemplates(List<Template> t) => _p.setStringList(
      'templates', t.map((e) => jsonEncode(e.toJson())).toList());

  // ---- سجل الكروت ----
  static Future<void> _saveBatches() => _file
      .writeAsString(jsonEncode(batches.map((b) => b.toJson()).toList()));
  static Future<void> addBatch(Batch b) async {
    batches.insert(0, b);
    await _saveBatches();
  }

  static Future<void> removeBatch(Batch b) async {
    batches.removeWhere((x) => x.id == b.id);
    await _saveBatches();
  }

  static Future<void> updateBatches() => _saveBatches();

  // ---- الباقات (سعر + صورة) ----
  static Map<String, PkgInfo> get pkgs {
    final s = _p.getString('pkgs');
    if (s == null) return {};
    try {
      final m = jsonDecode(s) as Map;
      return m.map((k, v) =>
          MapEntry(k as String, PkgInfo.fromJson(Map<String, dynamic>.from(v))));
    } catch (_) {
      return {};
    }
  }

  static Future<void> savePkgs(Map<String, PkgInfo> m) => _p.setString(
      'pkgs', jsonEncode(m.map((k, v) => MapEntry(k, v.toJson()))));

  static double priceFor(String profile) {
    final p = pkgs[profile]?.price ?? 0;
    if (p > 0) return p;
    for (final b in batches) {
      if (b.profile == profile && b.price > 0) return b.price;
    }
    return 0;
  }

  // ---- تصاميم الكروت ----
  static List<CardDesign> get designs {
    final l = _p.getStringList('designs') ?? [];
    final out = <CardDesign>[];
    for (final e in l) {
      try {
        out.add(CardDesign.fromJson(Map<String, dynamic>.from(jsonDecode(e))));
      } catch (_) {}
    }
    return out;
  }

  static Future<void> saveDesigns(List<CardDesign> l) => _p.setStringList(
      'designs', l.map((e) => jsonEncode(e.toJson())).toList());
}

class PkgInfo {
  double price;
  String? image;
  PkgInfo({this.price = 0, this.image});
  Map<String, dynamic> toJson() => {'price': price, 'image': image};
  factory PkgInfo.fromJson(Map<String, dynamic> j) => PkgInfo(
      price: (j['price'] as num? ?? 0).toDouble(), image: j['image'] as String?);
}

/// تصميم كرت: صورة خلفية + مواضع الاسم وكلمة المرور (نسب من 0 إلى 1).
class CardDesign {
  String id, name;
  String? bg;
  double w, h; // مم
  double ux, uy, usz, px, py, psz;
  int color;
  bool showPass;
  CardDesign(
      {required this.id,
      required this.name,
      this.bg,
      this.w = 85,
      this.h = 54,
      this.ux = 0.5,
      this.uy = 0.5,
      this.usz = 16,
      this.px = 0.5,
      this.py = 0.75,
      this.psz = 13,
      this.color = 0xFF000000,
      this.showPass = true});
  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'bg': bg, 'w': w, 'h': h,
        'ux': ux, 'uy': uy, 'usz': usz, 'px': px, 'py': py, 'psz': psz,
        'color': color, 'showPass': showPass,
      };
  factory CardDesign.fromJson(Map<String, dynamic> j) => CardDesign(
        id: j['id'] as String,
        name: j['name'] as String,
        bg: j['bg'] as String?,
        w: (j['w'] as num? ?? 85).toDouble(),
        h: (j['h'] as num? ?? 54).toDouble(),
        ux: (j['ux'] as num? ?? .5).toDouble(),
        uy: (j['uy'] as num? ?? .5).toDouble(),
        usz: (j['usz'] as num? ?? 16).toDouble(),
        px: (j['px'] as num? ?? .5).toDouble(),
        py: (j['py'] as num? ?? .75).toDouble(),
        psz: (j['psz'] as num? ?? 13).toDouble(),
        color: j['color'] as int? ?? 0xFF000000,
        showPass: j['showPass'] as bool? ?? true,
      );
}
