import 'package:flutter/material.dart';

const petrol = Color(0xFF0A3F52);
const petrolLight = Color(0xFF0F5168);
const turq = Color(0xFF2DD4E4);
const turqBtn = Color(0xFF0A8FA0);

ThemeData buildTheme() {
  final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: turq, width: 1));
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: petrol,
    colorScheme: const ColorScheme.dark(
      primary: turqBtn,
      onPrimary: Colors.white,
      secondary: turq,
      surface: petrolLight,
      onSurface: Colors.white,
    ),
    appBarTheme: const AppBarTheme(
        backgroundColor: petrol,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0),
    cardTheme: CardThemeData(
        color: petrolLight,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: petrolLight,
        border: border,
        enabledBorder: border,
        focusedBorder: border.copyWith(
            borderSide: const BorderSide(color: turq, width: 2)),
        labelStyle: const TextStyle(color: Colors.white70)),
    filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
            backgroundColor: turqBtn,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(48),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)))),
    outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
            foregroundColor: Colors.white,
            side: const BorderSide(color: turq),
            minimumSize: const Size.fromHeight(48),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)))),
    switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.all(Colors.white),
        trackColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? turqBtn : Colors.white24)),
  );
}

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c)
    .showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 4)));

/// يعرض دائرة انتظار أثناء المهمة ويعرض الخطأ إن حدث.
Future<T?> busy<T>(BuildContext context, Future<T> Function() job) async {
  final nav = Navigator.of(context, rootNavigator: true);
  showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()));
  try {
    return await job();
  } catch (e) {
    if (context.mounted) toast(context, '$e');
    return null;
  } finally {
    nav.pop();
  }
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
            content: Text(msg),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(c, false),
                  child: const Text('إلغاء')),
              TextButton(
                  onPressed: () => Navigator.pop(c, true),
                  child: const Text('تأكيد')),
            ],
          ));
  return r ?? false;
}

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
  return '${(b / 1073741824).toStringAsFixed(2)} GB';
}

String fmtDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String fmtMoney(double v) => v.toStringAsFixed(v % 1 == 0 ? 0 : 2);

Widget field(TextEditingController c, String label,
        {bool number = false, bool obscure = false}) =>
    Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: obscure,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(labelText: label),
      ),
    );

class Logo extends StatelessWidget {
  const Logo({super.key, this.height = 90});
  final double height;
  @override
  Widget build(BuildContext context) =>
      Image.asset('assets/logo.png', height: height, fit: BoxFit.contain);
}
