//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dgv3XgBf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/_app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BqzhbWaO.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CuP9zDxQ.js",
			"/assets/link-CVAdlhQp.js",
			"/assets/useMatch-DzgUJ3Nt.js",
			"/assets/jsx-runtime-BtH0gOTJ.js",
			"/assets/useRouter-DTQ3YH1D.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BqzhbWaO.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/active",
			"/_app/alerts",
			"/_app/assist",
			"/_app/audit",
			"/_app/backups",
			"/_app/channels",
			"/_app/devices",
			"/_app/diagnose",
			"/_app/hotspot",
			"/_app/inventory",
			"/_app/maintenance",
			"/_app/network",
			"/_app/pppoe",
			"/_app/profiles",
			"/_app/reports",
			"/_app/resellers",
			"/_app/routers",
			"/_app/scripts",
			"/_app/settings",
			"/_app/sources",
			"/_app/subscribers",
			"/_app/subscription",
			"/_app/support",
			"/_app/templates",
			"/_app/towers",
			"/_app/userman",
			"/_app/vouchers",
			"/_app/"
		],
		preloads: [
			"/assets/_app-xzscd694.js",
			"/assets/client-cLw6edTc.js",
			"/assets/login-screen-Cq3AM2_m.js",
			"/assets/dist-BwWpl9Eg.js",
			"/assets/api-DvtmR9sl.js",
			"/assets/kit-P8qqwOn1.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-BXSNm5O2.js", "/assets/login-screen-Cq3AM2_m.js"]
	},
	"/_app/active": {
		filePath: "/workspace/src/routes/_app/active.tsx",
		children: void 0,
		preloads: ["/assets/active-Cvn5T1nO.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/alerts": {
		filePath: "/workspace/src/routes/_app/alerts.tsx",
		children: void 0,
		preloads: ["/assets/alerts-CobsOnM-.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/assist": {
		filePath: "/workspace/src/routes/_app/assist.tsx",
		children: void 0,
		preloads: ["/assets/assist-BQ1QsPNn.js", "/assets/desk-DeEJcZqH.js"]
	},
	"/_app/audit": {
		filePath: "/workspace/src/routes/_app/audit.tsx",
		children: void 0,
		preloads: ["/assets/audit-CTnR_jhU.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/backups": {
		filePath: "/workspace/src/routes/_app/backups.tsx",
		children: void 0,
		preloads: ["/assets/backups-Cs0qjw_a.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/channels": {
		filePath: "/workspace/src/routes/_app/channels.tsx",
		children: void 0,
		preloads: [
			"/assets/channels-DkIyr2UH.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/devices": {
		filePath: "/workspace/src/routes/_app/devices.tsx",
		children: void 0,
		preloads: ["/assets/devices-CCliF0XY.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/diagnose": {
		filePath: "/workspace/src/routes/_app/diagnose.tsx",
		children: void 0,
		preloads: [
			"/assets/diagnose-CTZMtklx.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/hotspot": {
		filePath: "/workspace/src/routes/_app/hotspot.tsx",
		children: void 0,
		preloads: ["/assets/hotspot-CtIcsb4I.js", "/assets/accounts-Cu5V2Orb.js"]
	},
	"/_app/inventory": {
		filePath: "/workspace/src/routes/_app/inventory.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-HhTcG2TX.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/maintenance": {
		filePath: "/workspace/src/routes/_app/maintenance.tsx",
		children: void 0,
		preloads: [
			"/assets/maintenance-DYRJlrZy.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/network": {
		filePath: "/workspace/src/routes/_app/network.tsx",
		children: void 0,
		preloads: ["/assets/network-69UTEi12.js", "/assets/desk-DeEJcZqH.js"]
	},
	"/_app/pppoe": {
		filePath: "/workspace/src/routes/_app/pppoe.tsx",
		children: void 0,
		preloads: ["/assets/pppoe-CbfhvDWW.js", "/assets/accounts-Cu5V2Orb.js"]
	},
	"/_app/profiles": {
		filePath: "/workspace/src/routes/_app/profiles.tsx",
		children: void 0,
		preloads: ["/assets/profiles-SCvI7ERr.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/reports": {
		filePath: "/workspace/src/routes/_app/reports.tsx",
		children: void 0,
		preloads: ["/assets/reports-CzVkAkWx.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/resellers": {
		filePath: "/workspace/src/routes/_app/resellers.tsx",
		children: void 0,
		preloads: [
			"/assets/resellers-DrLoTcWW.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/routers": {
		filePath: "/workspace/src/routes/_app/routers.tsx",
		children: ["/_app/routers/$routerId"],
		preloads: ["/assets/routers-CkSV3jTR.js"]
	},
	"/_app/scripts": {
		filePath: "/workspace/src/routes/_app/scripts.tsx",
		children: void 0,
		preloads: ["/assets/scripts-fheeIHMb.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-BZUc8Dex.js"]
	},
	"/_app/sources": {
		filePath: "/workspace/src/routes/_app/sources.tsx",
		children: void 0,
		preloads: [
			"/assets/sources-ewpR3eN6.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/subscribers": {
		filePath: "/workspace/src/routes/_app/subscribers.tsx",
		children: void 0,
		preloads: [
			"/assets/subscribers-DOxUT2oR.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/subscription": {
		filePath: "/workspace/src/routes/_app/subscription.tsx",
		children: void 0,
		preloads: ["/assets/subscription-BLwVxfO3.js"]
	},
	"/_app/support": {
		filePath: "/workspace/src/routes/_app/support.tsx",
		children: void 0,
		preloads: [
			"/assets/support-DdKwtaNk.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/templates": {
		filePath: "/workspace/src/routes/_app/templates.tsx",
		children: void 0,
		preloads: ["/assets/templates-DBePjo6d.js"]
	},
	"/_app/towers": {
		filePath: "/workspace/src/routes/_app/towers.tsx",
		children: void 0,
		preloads: ["/assets/towers-BOVdAHri.js", "/assets/desk-DeEJcZqH.js"]
	},
	"/_app/userman": {
		filePath: "/workspace/src/routes/_app/userman.tsx",
		children: void 0,
		preloads: [
			"/assets/userman-9vdEii4V.js",
			"/assets/format-cjIpDnYr.js",
			"/assets/desk-DeEJcZqH.js"
		]
	},
	"/_app/vouchers": {
		filePath: "/workspace/src/routes/_app/vouchers.tsx",
		children: void 0,
		preloads: ["/assets/vouchers-DVVKz3_G.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: ["/assets/_app-jyQ1Kxua.js", "/assets/format-cjIpDnYr.js"]
	},
	"/_app/routers/$routerId": {
		filePath: "/workspace/src/routes/_app/routers.$routerId.tsx",
		children: void 0,
		preloads: ["/assets/routers._routerId-D7MpQHAm.js", "/assets/format-cjIpDnYr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
