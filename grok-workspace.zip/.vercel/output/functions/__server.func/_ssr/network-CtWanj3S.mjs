import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as listNetwork, y as saveNetNote } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/network-CtWanj3S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AREAS = [
	["firewall", "جدار ناري"],
	["nat", "NAT"],
	["dhcp", "DHCP"],
	["dns", "DNS"],
	["queue", "السرعات"],
	["route", "التوجيه"],
	["vlan", "VLAN"],
	["bridge", "Bridge"],
	["vpn", "VPN"]
];
function NetworkPage() {
	const load = (0, import_react.useCallback)(() => listNetwork(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		area: "firewall",
		name: "",
		detail: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			const result = await saveNetNote({ data: form });
			toast.success(result.message);
			setForm({
				...form,
				name: "",
				detail: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	const label = (area) => AREAS.find((item) => item[0] === area)?.[1] ?? area;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "قراءة وسجل، بلا تطبيق صامت",
			title: "أدوات الشبكة"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "الواجهات الظاهرة أتت من آخر مزامنة أو من المختبر. الملاحظة لا تُرسل أمراً إلى الراوتر."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [(data?.interfaces ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						item.router,
						" · ",
						item.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						item.kind || "نوع غير معروف",
						" · ",
						item.running ? "يعمل" : "متوقف",
						" · ",
						item.comment || "بدون تعليق",
						" · ",
						item.origin === "lab" ? "مختبر" : "سجل"
					]
				})]
			}, `${item.router}-${item.name}`)), data && data.interfaces.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "لا واجهات مسجّلة."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel mt-4 grid gap-3 p-4",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "ملاحظة إعداد"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "القسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: form.area,
						onChange: (e) => setForm({
							...form,
							area: e.target.value
						}),
						children: AREAS.map(([value, name]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value,
							children: name
						}, value))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الاسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						required: true,
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "التفصيل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-20",
						value: form.detail,
						onChange: (e) => setForm({
							...form,
							detail: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary",
					type: "submit",
					children: "حفظ الملاحظة"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-2",
			children: (data?.notes ?? []).map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						label(note.area),
						" · ",
						note.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: note.detail
				})]
			}, note.id))
		})
	] });
}
//#endregion
export { NetworkPage as component };
