import { n as adenDay } from "./format-HomJAAR4.mjs";
import { r as getSql } from "./db-BFrD0jNM.mjs";
import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.server-CvohupfA.js
function id() {
	return randomUUID();
}
function text(v, fallback = "") {
	if (v === null || v === void 0) return fallback;
	return String(v);
}
function num(v) {
	if (v === null || v === void 0 || v === "") return null;
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : null;
}
function flag(v) {
	return v === true || v === "t" || v === "true" || v === 1;
}
async function dek(sql) {
	const env = process.env.ROUTER_KEY;
	if (env && env.trim()) return createHash("sha256").update(env).digest();
	const existing = (await sql`select key_b64 from platform_keys where id = 'dek'`)[0]?.key_b64;
	if (typeof existing === "string") return Buffer.from(existing, "base64");
	await sql`insert into platform_keys (id, key_b64) values ('dek', ${randomBytes(32).toString("base64")}) on conflict (id) do nothing`;
	const again = await sql`select key_b64 from platform_keys where id = 'dek'`;
	return Buffer.from(text(again[0]?.key_b64), "base64");
}
async function seal(sql, plain) {
	const key = await dek(sql);
	const iv = randomBytes(12);
	const cipher = createCipheriv("aes-256-gcm", key, iv);
	const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
	const tag = cipher.getAuthTag();
	return `${iv.toString("base64")}.${tag.toString("base64")}.${enc.toString("base64")}`;
}
async function open(sql, packed) {
	if (!packed) return "";
	const [ivB, tagB, dataB] = packed.split(".");
	if (!ivB || !tagB || !dataB) return "";
	try {
		const key = await dek(sql);
		const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB, "base64"));
		decipher.setAuthTag(Buffer.from(tagB, "base64"));
		return Buffer.concat([decipher.update(Buffer.from(dataB, "base64")), decipher.final()]).toString("utf8");
	} catch {
		return "";
	}
}
async function ctx(userId) {
	const sql = await getSql();
	const rows = await sql`select id, name from tenants where owner_user_id = ${userId}`;
	const tenantId = text(rows[0]?.id);
	if (!tenantId) throw new Error("افتح مركز القيادة أولاً حتى تُنشأ الشبكة");
	const license = await sql`select status from licenses where tenant_id = ${tenantId}`;
	return {
		sql,
		tenantId,
		name: text(rows[0]?.name),
		suspended: text(license[0]?.status) === "suspended"
	};
}
function assertWritable(suspended) {
	if (suspended) throw new Error("الحساب موقوف. تبقى المراقبة، وتتوقف أوامر التعديل.");
}
async function audit(sql, tenantId, userId, action, target, detail) {
	await sql`insert into audit_logs (id, tenant_id, user_id, action, target, detail)
    values (${id()}, ${tenantId}, ${userId}, ${action}, ${target}, ${detail})`;
}
async function listResellers(userId) {
	const { sql, tenantId } = await ctx(userId);
	const people = await sql`select * from resellers where tenant_id = ${tenantId} order by name`;
	const entries = await sql`select * from wallet_entries where tenant_id = ${tenantId} order by created_at desc limit 80`;
	const sums = await sql`select reseller_id, coalesce(sum(amount), 0)::int as balance from wallet_entries where tenant_id = ${tenantId} group by reseller_id`;
	const balance = new Map(sums.map((row) => [text(row.reseller_id), num(row.balance) ?? 0]));
	return {
		resellers: people.map((row) => ({
			id: text(row.id),
			name: text(row.name),
			phone: text(row.phone),
			commissionPct: num(row.commission_pct) ?? 0,
			active: flag(row.active),
			notes: text(row.notes),
			balance: balance.get(text(row.id)) ?? 0
		})),
		entries: entries.map((row) => ({
			id: text(row.id),
			resellerId: text(row.reseller_id),
			kind: text(row.kind),
			amount: num(row.amount) ?? 0,
			note: text(row.note),
			reversesId: text(row.reverses_id),
			createdAt: text(row.created_at)
		}))
	};
}
async function saveReseller(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const rowId = id();
	await sql`insert into resellers (id, tenant_id, name, phone, commission_pct, notes)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.phone}, ${input.commissionPct}, ${input.notes})`;
	await audit(sql, tenantId, userId, "إضافة بائع", rowId, input.name);
	return { id: rowId };
}
async function walletMove(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (input.amount <= 0) throw new Error("المبلغ يجب أن يكون أكبر من صفر");
	const owner = await sql`select id, name from resellers where id = ${input.resellerId} and tenant_id = ${tenantId}`;
	if (!owner[0]) throw new Error("البائع غير موجود");
	const signed = input.kind === "withdraw" || input.kind === "sale" ? -input.amount : input.amount;
	const rowId = id();
	await sql`insert into wallet_entries (id, tenant_id, reseller_id, kind, amount, note)
    values (${rowId}, ${tenantId}, ${input.resellerId}, ${input.kind}, ${signed}, ${input.note})`;
	await audit(sql, tenantId, userId, "قيد محفظة", rowId, `${text(owner[0].name)} ${input.kind} ${signed}`);
	return { id: rowId };
}
async function reverseWallet(userId, entryId) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const row = (await sql`select * from wallet_entries where id = ${entryId} and tenant_id = ${tenantId}`)[0];
	if (!row) throw new Error("القيد غير موجود");
	if (text(row.kind) === "reverse") throw new Error("لا يُعكس قيد عكسي");
	if ((await sql`select id from wallet_entries where tenant_id = ${tenantId} and reverses_id = ${entryId}`)[0]) throw new Error("عُكس هذا القيد مسبقاً");
	const amount = -(num(row.amount) ?? 0);
	const rowId = id();
	await sql`insert into wallet_entries (id, tenant_id, reseller_id, kind, amount, note, reverses_id)
    values (${rowId}, ${tenantId}, ${text(row.reseller_id)}, 'reverse', ${amount}, ${`عكس: ${text(row.note)}`}, ${entryId})`;
	await audit(sql, tenantId, userId, "عكس قيد", rowId, entryId);
	return { id: rowId };
}
async function listUm(userId) {
	const { sql, tenantId } = await ctx(userId);
	return (await sql`select * from um_users where tenant_id = ${tenantId} order by username`).map((row) => ({
		id: text(row.id),
		username: text(row.username),
		profile: text(row.profile_name),
		credit: num(row.credit) ?? 0,
		limitation: text(row.limitation),
		disabled: flag(row.disabled),
		note: text(row.note)
	}));
}
async function saveUm(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const rowId = id();
	await sql`insert into um_users (id, tenant_id, username, profile_name, credit, limitation, note)
    values (${rowId}, ${tenantId}, ${input.username}, ${input.profile}, ${input.credit}, ${input.limitation}, ${input.note})`;
	await audit(sql, tenantId, userId, "مستخدم يوزر منجر", rowId, input.username);
	return {
		id: rowId,
		message: "حُفظ في سجل المنصة. لم يُرسل إلى الراوتر حتى تربط User Manager وتزامنه."
	};
}
async function setUmDisabled(userId, rowId, disabled) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	await sql`update um_users set disabled = ${disabled} where id = ${rowId} and tenant_id = ${tenantId}`;
	await audit(sql, tenantId, userId, disabled ? "تعطيل يوزر منجر" : "تفعيل يوزر منجر", rowId, "");
	return { ok: true };
}
async function listJobs(userId) {
	const { sql, tenantId } = await ctx(userId);
	return (await sql`select * from jobs where tenant_id = ${tenantId} order by created_at desc`).map((row) => ({
		id: text(row.id),
		title: text(row.title),
		site: text(row.site),
		tower: text(row.tower),
		assignee: text(row.assignee),
		status: text(row.status),
		notes: text(row.notes),
		createdAt: text(row.created_at)
	}));
}
async function saveJob(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const rowId = id();
	const status = input.assignee.trim() ? "assigned" : "open";
	await sql`insert into jobs (id, tenant_id, title, site, tower, assignee, status, notes)
    values (${rowId}, ${tenantId}, ${input.title}, ${input.site}, ${input.tower}, ${input.assignee}, ${status}, ${input.notes})`;
	await audit(sql, tenantId, userId, "بلاغ صيانة", rowId, input.title);
	return { id: rowId };
}
async function setJobStatus(userId, jobId, status) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	await sql`update jobs set status = ${status} where id = ${jobId} and tenant_id = ${tenantId}`;
	await audit(sql, tenantId, userId, "حالة بلاغ", jobId, status);
	return { ok: true };
}
async function listInventory(userId) {
	const { sql, tenantId } = await ctx(userId);
	return (await sql`select * from inventory where tenant_id = ${tenantId} order by name`).map((row) => ({
		id: text(row.id),
		name: text(row.name),
		kind: text(row.kind),
		serial: text(row.serial),
		model: text(row.model),
		qty: num(row.qty) ?? 0,
		buyPrice: num(row.buy_price) ?? 0,
		location: text(row.location),
		state: text(row.state),
		warranty: text(row.warranty),
		boughtOn: text(row.bought_on)
	}));
}
async function saveInventory(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const kinds = /* @__PURE__ */ new Set([
		"router",
		"antenna",
		"modem",
		"switch",
		"cable",
		"power",
		"other"
	]);
	const states = /* @__PURE__ */ new Set([
		"stock",
		"installed",
		"faulty",
		"spare"
	]);
	if (!kinds.has(input.kind) || !states.has(input.state)) throw new Error("نوع القطعة أو حالتها غير معروف");
	const rowId = id();
	await sql`insert into inventory (id, tenant_id, name, kind, serial, model, qty, buy_price, location, state, warranty, bought_on)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.kind}, ${input.serial}, ${input.model}, ${input.qty}, ${input.buyPrice}, ${input.location}, ${input.state}, ${input.warranty}, ${input.boughtOn})`;
	await audit(sql, tenantId, userId, "إضافة مخزون", rowId, input.name);
	return { id: rowId };
}
async function listChannels(userId) {
	const { sql, tenantId } = await ctx(userId);
	const rows = await sql`select tg_chat, tg_bot_name, tg_token_cipher, wa_phone, wa_note from channels where tenant_id = ${tenantId}`;
	const outbox = await sql`select id, channel, to_addr, body, status, detail, created_at from outbox where tenant_id = ${tenantId} order by created_at desc limit 30`;
	const row = rows[0];
	return {
		chat: text(row?.tg_chat),
		botName: text(row?.tg_bot_name),
		hasToken: Boolean(row?.tg_token_cipher),
		waPhone: text(row?.wa_phone),
		waNote: text(row?.wa_note),
		outbox: outbox.map((item) => ({
			id: text(item.id),
			channel: text(item.channel),
			to: text(item.to_addr),
			body: text(item.body),
			status: text(item.status),
			detail: text(item.detail),
			createdAt: text(item.created_at)
		}))
	};
}
async function saveChannels(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	let cipher = text((await sql`select tg_token_cipher from channels where tenant_id = ${tenantId}`)[0]?.tg_token_cipher) || null;
	if (input.token.trim()) {
		if (!/^\d{6,}:[A-Za-z0-9_-]{20,}$/.test(input.token.trim())) throw new Error("صيغة توكن البوت غير صالحة");
		cipher = await seal(sql, input.token.trim());
	}
	await sql`insert into channels (tenant_id, tg_token_cipher, tg_chat, wa_phone, wa_note)
    values (${tenantId}, ${cipher}, ${input.chat.trim()}, ${input.waPhone.trim()}, ${input.waNote.trim()})
    on conflict (tenant_id) do update set
      tg_token_cipher = excluded.tg_token_cipher,
      tg_chat = excluded.tg_chat,
      wa_phone = excluded.wa_phone,
      wa_note = excluded.wa_note`;
	await audit(sql, tenantId, userId, "حفظ قنوات الإشعار", tenantId, input.chat ? "تيليجرام" : "بدون محادثة");
	return { ok: true };
}
async function telegram(token, method, body) {
	const payload = await (await fetch(`https://api.telegram.org/bot${token}/${method}`, {
		method: body ? "POST" : "GET",
		headers: body ? { "content-type": "application/json" } : void 0,
		body: body ? JSON.stringify(body) : void 0,
		signal: AbortSignal.timeout(8e3)
	})).json();
	if (!payload.ok) throw new Error(payload.description || "رفض تيليجرام الطلب");
	return payload;
}
async function testTelegram(userId, send) {
	const { sql, tenantId, name } = await ctx(userId);
	const rows = await sql`select tg_token_cipher, tg_chat from channels where tenant_id = ${tenantId}`;
	const token = await open(sql, text(rows[0]?.tg_token_cipher) || null);
	if (!token) throw new Error("احفظ توكن البوت أولاً");
	const me = await telegram(token, "getMe");
	const botName = me.result?.username ? `@${me.result.username}` : "";
	await sql`update channels set tg_bot_name = ${botName} where tenant_id = ${tenantId}`;
	if (!send) {
		await audit(sql, tenantId, userId, "فحص بوت", tenantId, botName);
		return {
			ok: true,
			message: botName ? `البوت ${botName} صالح` : "البوت صالح"
		};
	}
	const chat = text(rows[0]?.tg_chat);
	if (!chat) throw new Error("أدخل معرّف المحادثة قبل الإرسال");
	await telegram(token, "sendMessage", {
		chat_id: chat,
		text: `اختبار من الزهر MikroTik — ${name}. هذه رسالة حقيقية من المنصة.`
	});
	await sql`insert into outbox (id, tenant_id, channel, to_addr, body, status, detail)
    values (${id()}, ${tenantId}, 'telegram', ${chat}, ${"رسالة اختبار"}, 'sent', ${botName})`;
	await audit(sql, tenantId, userId, "اختبار تيليجرام", chat, botName);
	return {
		ok: true,
		message: `أُرسلت رسالة الاختبار إلى ${chat}`
	};
}
async function holdWhatsapp(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const rowId = id();
	await sql`insert into outbox (id, tenant_id, channel, to_addr, body, status, detail)
    values (${rowId}, ${tenantId}, 'whatsapp', ${input.to}, ${input.body}, 'held', ${"محجوزة. لا يوجد مزود واتساب موصول، ولم تُرسل."})`;
	await audit(sql, tenantId, userId, "حجز رسالة واتساب", rowId, input.to);
	return {
		id: rowId,
		message: "حُجزت الرسالة في السجل ولم تُرسل. اربط مزود واتساب لاحقاً للإرسال الفعلي."
	};
}
async function listTickets(userId) {
	const { sql, tenantId } = await ctx(userId);
	return (await sql`select * from tickets where tenant_id = ${tenantId} order by created_at desc`).map((row) => ({
		id: text(row.id),
		subject: text(row.subject),
		body: text(row.body),
		status: text(row.status),
		createdAt: text(row.created_at)
	}));
}
async function saveTicket(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	const rowId = id();
	await sql`insert into tickets (id, tenant_id, subject, body) values (${rowId}, ${tenantId}, ${input.subject}, ${input.body})`;
	await audit(sql, tenantId, userId, "تذكرة دعم", rowId, input.subject);
	return { id: rowId };
}
async function closeTicket(userId, ticketId) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	await sql`update tickets set status = 'closed' where id = ${ticketId} and tenant_id = ${tenantId}`;
	await audit(sql, tenantId, userId, "إغلاق تذكرة", ticketId, "");
	return { ok: true };
}
async function listNetwork(userId) {
	const { sql, tenantId } = await ctx(userId);
	const ifaces = await sql`select i.name, i.kind, i.running, i.comment, i.origin, r.name as router
    from interfaces i join routers r on r.id = i.router_id
    where i.tenant_id = ${tenantId} order by r.name, i.name`;
	const notes = await sql`select * from net_notes where tenant_id = ${tenantId} order by area, name`;
	return {
		interfaces: ifaces.map((row) => ({
			name: text(row.name),
			kind: text(row.kind),
			running: flag(row.running),
			comment: text(row.comment),
			origin: text(row.origin),
			router: text(row.router)
		})),
		notes: notes.map((row) => ({
			id: text(row.id),
			area: text(row.area),
			name: text(row.name),
			detail: text(row.detail)
		}))
	};
}
async function saveNetNote(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (!(/* @__PURE__ */ new Set([
		"firewall",
		"nat",
		"dhcp",
		"dns",
		"queue",
		"route",
		"vlan",
		"bridge",
		"vpn"
	])).has(input.area)) throw new Error("القسم غير معروف");
	const rowId = id();
	await sql`insert into net_notes (id, tenant_id, area, name, detail)
    values (${rowId}, ${tenantId}, ${input.area}, ${input.name}, ${input.detail})`;
	await audit(sql, tenantId, userId, "ملاحظة شبكة", rowId, `${input.area} ${input.name}`);
	return {
		id: rowId,
		message: "سُجّلت كملاحظة تشغيل. لم تُطبَّق على الراوتر."
	};
}
async function diagnose(userId) {
	const { sql, tenantId } = await ctx(userId);
	const routers = await sql`select name, mode, status, cpu, ram, last_error from routers where tenant_id = ${tenantId}`;
	const alerts = await sql`select count(*)::int as n from alerts where tenant_id = ${tenantId} and acked = false`;
	const due = await sql`select count(*)::int as n from subscribers where tenant_id = ${tenantId} and (status = 'due' or ends_on < ${adenDay()})`;
	const weak = await sql`select name, signal from antennas where tenant_id = ${tenantId} and signal is not null and signal < -70`;
	const sources = await sql`select name, status, latency_ms from sources where tenant_id = ${tenantId}`;
	const live = routers.filter((row) => text(row.mode) === "live").length;
	const findings = [];
	if (routers.length === 0) findings.push({
		severity: "warn",
		title: "لا راوترات في السجل",
		evidence: "جدول الراوترات فارغ لهذا الحساب.",
		action: "أضف راوتراً أو افتح المختبر إن أردت تجربة الواجهة."
	});
	if (live === 0 && routers.length > 0) findings.push({
		severity: "warn",
		title: "لا توجد قراءة حية",
		evidence: "كل الراوترات الحالية معلّمة كمختبر أو لم يُفحص اتصالها.",
		action: "اربط عنوان API-SSL حقيقياً قبل اعتبار الأرقام حالة الشبكة."
	});
	for (const router of routers) {
		if (text(router.status) === "offline") findings.push({
			severity: "danger",
			title: `انقطاع ${text(router.name)}`,
			evidence: text(router.last_error) || "الحالة المخزّنة: منقطع.",
			action: "تحقق من الطاقة والمنفذ 8729 والنفق قبل إعادة التشغيل."
		});
		const cpu = num(router.cpu);
		if (cpu !== null && cpu >= 80) findings.push({
			severity: "warn",
			title: `معالج ${text(router.name)} مرتفع`,
			evidence: `آخر قراءة مخزّنة ${cpu}٪.`,
			action: "راجع الجلسات والفايرول. لا تُغلق شيئاً من هذا الفحص."
		});
		const ram = num(router.ram);
		if (ram !== null && ram >= 85) findings.push({
			severity: "warn",
			title: `ذاكرة ${text(router.name)} مرتفعة`,
			evidence: `آخر قراءة مخزّنة ${ram}٪.`,
			action: "راجع عدد الجلسات والكاش قبل زيادة العتاد."
		});
	}
	const openAlerts = num(alerts[0]?.n) ?? 0;
	if (openAlerts > 0) findings.push({
		severity: "warn",
		title: "تنبيهات غير مغلقة",
		evidence: `${openAlerts} تنبيهاً ما زال مفتوحاً.`,
		action: "راجع مركز التنبيهات وأغلق ما عولج."
	});
	const late = num(due[0]?.n) ?? 0;
	if (late > 0) findings.push({
		severity: "warn",
		title: "اشتراكات متأخرة",
		evidence: `${late} عميلاً تاريخ انتهائه فات أو حالته متأخر.`,
		action: "جدّد من شاشة العملاء أو علّق الخدمة يدوياً. الفحص لا يفصل أحداً."
	});
	for (const antenna of weak) findings.push({
		severity: "warn",
		title: `إشارة ضعيفة: ${text(antenna.name)}`,
		evidence: `${num(antenna.signal)} dBm في السجل. ليست قياساً لحظياً إلا إذا زامنت الجهاز.`,
		action: "عاين التوجيه والتردد في الموقع."
	});
	for (const source of sources) {
		const latency = num(source.latency_ms);
		if (text(source.status) === "offline" || latency !== null && latency > 150) findings.push({
			severity: text(source.status) === "offline" ? "danger" : "warn",
			title: `مصدر ${text(source.name)}`,
			evidence: text(source.status) === "offline" ? "الحالة المخزّنة: منقطع." : `تأخير مخزّن ${latency} ms.`,
			action: "لا يُغيّر هذا الفحص التوجيه أو PCC."
		});
	}
	if (findings.length === 0) findings.push({
		severity: "ok",
		title: "لا مؤشر خطر في السجلات",
		evidence: "الراوترات المسجّلة ليست منقطعة، ولا تنبيهات مفتوحة، ولا اشتراك متأخر.",
		action: "هذا لا يثبت أن الخط سليم الآن إذا كانت القراءة قديمة."
	});
	return {
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		liveRouters: live,
		findings
	};
}
async function assist(userId, question) {
	const report = await diagnose(userId);
	const q = question.trim();
	const folded = q.toLowerCase();
	const hit = [
		[
			"معالج",
			"cpu",
			"معالج"
		],
		[
			"ذاكرة",
			"ram",
			"ذاكرة"
		],
		[
			"انقطاع",
			"offline",
			"انقطاع"
		],
		[
			"اشتراك",
			"عميل",
			"اشتراك"
		],
		[
			"إشارة",
			"انتينا",
			"إشارة"
		],
		[
			"ستار",
			"فايبر",
			"مصدر"
		],
		[
			"dns",
			"دي ان اس",
			"مصدر"
		]
	].find((group) => group.slice(0, 2).some((word) => folded.includes(word) || q.includes(word)));
	const related = hit ? report.findings.filter((item) => item.title.includes(hit[2]) || item.evidence.includes(hit[2])) : report.findings;
	const used = related.length > 0 ? related : report.findings;
	return {
		question: q || "فحص عام",
		note: "تحليل على السجلات المخزّنة في حسابك. لا يطبّق تغييراً ولا يتصل بنموذج خارجي.",
		findings: used.slice(0, 6),
		generatedAt: report.generatedAt
	};
}
async function saveSubscriber(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (!/^\d{4}-\d{2}-\d{2}$/.test(input.endsOn)) throw new Error("تاريخ الانتهاء بصيغة سنة-شهر-يوم");
	const rowId = id();
	const code = `ZN-${String(Date.now()).slice(-6)}`;
	const status = input.endsOn < adenDay() ? "due" : "active";
	await sql`insert into subscribers (
    id, tenant_id, name, phone, address, code, tower, antenna, service, account, plan_name, started_on, ends_on, status, origin
  ) values (
    ${rowId}, ${tenantId}, ${input.name}, ${input.phone}, ${input.address}, ${code}, ${input.tower}, ${input.antenna},
    ${input.service}, ${input.account}, ${input.plan}, ${adenDay()}, ${input.endsOn}, ${status}, 'desk'
  )`;
	await audit(sql, tenantId, userId, "إضافة عميل", rowId, input.name);
	return {
		id: rowId,
		code
	};
}
async function recordPayment(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (input.amount <= 0) throw new Error("المبلغ غير صالح");
	const person = await sql`select name from subscribers where id = ${input.subscriberId} and tenant_id = ${tenantId}`;
	if (!person[0]) throw new Error("العميل غير موجود");
	const rowId = id();
	const day = adenDay();
	await sql`insert into payments (id, tenant_id, subscriber_id, amount, note, day)
    values (${rowId}, ${tenantId}, ${input.subscriberId}, ${input.amount}, ${input.note}, ${day})`;
	await sql`insert into sales (id, tenant_id, day, amount, qty, note, origin)
    values (${id()}, ${tenantId}, ${day}, ${input.amount}, 1, ${`دفعة ${text(person[0].name)}`}, 'desk')`;
	await audit(sql, tenantId, userId, "دفعة عميل", rowId, `${text(person[0].name)} ${input.amount}`);
	return {
		id: rowId,
		message: "سُجّلت الدفعة في دفتر المبيعات"
	};
}
async function listPayments(userId) {
	const { sql, tenantId } = await ctx(userId);
	return (await sql`select p.subscriber_id, p.amount, p.note, p.day from payments p
    where p.tenant_id = ${tenantId} order by p.created_at desc limit 40`).map((row) => ({
		subscriberId: text(row.subscriber_id),
		amount: num(row.amount) ?? 0,
		note: text(row.note),
		day: text(row.day)
	}));
}
async function saveTower(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (input.routerId) {
		if (!(await sql`select id from routers where id = ${input.routerId} and tenant_id = ${tenantId}`)[0]) throw new Error("الراوتر غير موجود");
	}
	const rowId = id();
	await sql`insert into towers (id, tenant_id, name, site, lat, lng, router_id, power_note, notes, status, origin)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.site}, ${input.lat || null}, ${input.lng || null}, ${input.routerId || null}, ${input.power}, ${input.notes}, 'unknown', 'desk')`;
	if (input.routerId) await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
      values (${id()}, ${tenantId}, 'router', ${input.routerId}, 'tower', ${rowId}, 'desk')`;
	await audit(sql, tenantId, userId, "إضافة برج", rowId, input.name);
	return { id: rowId };
}
async function saveAntenna(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (!(await sql`select id from towers where id = ${input.towerId} and tenant_id = ${tenantId}`)[0]) throw new Error("البرج غير موجود");
	const rowId = id();
	await sql`insert into antennas (id, tenant_id, tower_id, name, kind, model, ip, frequency, channel, status, origin)
    values (${rowId}, ${tenantId}, ${input.towerId}, ${input.name}, 'sector', ${input.model}, ${input.ip}, ${input.frequency}, ${input.channel}, 'unknown', 'desk')`;
	await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
    values (${id()}, ${tenantId}, 'tower', ${input.towerId}, 'antenna', ${rowId}, 'desk')`;
	await audit(sql, tenantId, userId, "إضافة انتينا", rowId, input.name);
	return { id: rowId };
}
async function saveSource(userId, input) {
	const { sql, tenantId, suspended } = await ctx(userId);
	assertWritable(suspended);
	if (!(/* @__PURE__ */ new Set([
		"Starlink",
		"Fiber",
		"Wireless",
		"DSL",
		"Other"
	])).has(input.kind)) throw new Error("نوع المصدر غير معروف");
	if (input.routerId) {
		if (!(await sql`select id from routers where id = ${input.routerId} and tenant_id = ${tenantId}`)[0]) throw new Error("الراوتر غير موجود");
	}
	const rowId = id();
	await sql`insert into sources (id, tenant_id, name, kind, iface, contracted, cost, status, note, origin)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.kind}, ${input.iface}, ${input.contracted}, ${input.cost}, 'unknown', ${input.note}, 'desk')`;
	if (input.routerId) await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
      values (${id()}, ${tenantId}, 'source', ${rowId}, 'router', ${input.routerId}, 'desk')`;
	await audit(sql, tenantId, userId, "إضافة مصدر إنترنت", rowId, input.name);
	return { id: rowId };
}
//#endregion
export { assist, closeTicket, diagnose, holdWhatsapp, listChannels, listInventory, listJobs, listNetwork, listPayments, listResellers, listTickets, listUm, recordPayment, reverseWallet, saveAntenna, saveChannels, saveInventory, saveJob, saveNetNote, saveReseller, saveSource, saveSubscriber, saveTicket, saveTower, saveUm, setJobStatus, setUmDisabled, testTelegram, walletMove };
