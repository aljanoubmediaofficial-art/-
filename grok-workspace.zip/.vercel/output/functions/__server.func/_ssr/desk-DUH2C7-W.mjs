import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D6nHeuCK.mjs";
import { cn as _enum, dn as boolean, gn as object, hn as number, yn as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-DUH2C7-W.js
async function desk() {
	return import("./desk.server-CvohupfA.mjs");
}
var listResellers_createServerFn_handler = createServerRpc({
	id: "7ed330294e3c2d7ffdcc2a7ba1913fa3bdc1ca7513f7b0ef019185c3164161b7",
	name: "listResellers",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listResellers.__executeServer(opts));
var listResellers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listResellers_createServerFn_handler, async ({ context }) => (await desk()).listResellers(context.userId));
var saveReseller_createServerFn_handler = createServerRpc({
	id: "29936b3698be976abfab7f7f5b00d6cc062b2decf93ad34975eb3aaf6aa972a7",
	name: "saveReseller",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveReseller.__executeServer(opts));
var saveReseller = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(60),
	phone: string().max(20),
	commissionPct: number().int().min(0).max(80),
	notes: string().max(200)
}).parse(input)).handler(saveReseller_createServerFn_handler, async ({ context, data }) => (await desk()).saveReseller(context.userId, data));
var walletMove_createServerFn_handler = createServerRpc({
	id: "f70629bd31c63f8a5e7e709c76f0332674b103e80463a31b04e8f964e5f40308",
	name: "walletMove",
	filename: "src/lib/noc/desk.ts"
}, (opts) => walletMove.__executeServer(opts));
var walletMove = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	resellerId: string(),
	kind: _enum([
		"topup",
		"withdraw",
		"sale",
		"commission"
	]),
	amount: number().int().min(1).max(5e6),
	note: string().max(160)
}).parse(input)).handler(walletMove_createServerFn_handler, async ({ context, data }) => (await desk()).walletMove(context.userId, data));
var reverseWallet_createServerFn_handler = createServerRpc({
	id: "decbf054cd0495969fd50a7cc4c13c792539641e13db717a5c4f7df9ec9a4830",
	name: "reverseWallet",
	filename: "src/lib/noc/desk.ts"
}, (opts) => reverseWallet.__executeServer(opts));
var reverseWallet = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(reverseWallet_createServerFn_handler, async ({ context, data }) => (await desk()).reverseWallet(context.userId, data.id));
var listUm_createServerFn_handler = createServerRpc({
	id: "17f131fdd3946cbbeaa77d8d2f903b958813b926d1d27cd277babbcc22c42dc8",
	name: "listUm",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listUm.__executeServer(opts));
var listUm = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listUm_createServerFn_handler, async ({ context }) => (await desk()).listUm(context.userId));
var saveUm_createServerFn_handler = createServerRpc({
	id: "402ae73f19cd73d31baa1367adcef77c6f7d31e15779ec730bd4d4a69b119b08",
	name: "saveUm",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveUm.__executeServer(opts));
var saveUm = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	username: string().min(2).max(32),
	profile: string().max(64),
	credit: number().int().min(0).max(1e6),
	limitation: string().max(80),
	note: string().max(160)
}).parse(input)).handler(saveUm_createServerFn_handler, async ({ context, data }) => (await desk()).saveUm(context.userId, data));
var setUmDisabled_createServerFn_handler = createServerRpc({
	id: "7e283c69d1026527ae79a3871013780f9d42b8c1716b5c461f44d4bd8c8ec1ff",
	name: "setUmDisabled",
	filename: "src/lib/noc/desk.ts"
}, (opts) => setUmDisabled.__executeServer(opts));
var setUmDisabled = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	disabled: boolean()
}).parse(input)).handler(setUmDisabled_createServerFn_handler, async ({ context, data }) => (await desk()).setUmDisabled(context.userId, data.id, data.disabled));
var listJobs_createServerFn_handler = createServerRpc({
	id: "4fc66cf311a2f82562ecc89c114eebae20be9fd01547c02d9a66e3cdeb04a61b",
	name: "listJobs",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listJobs.__executeServer(opts));
var listJobs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listJobs_createServerFn_handler, async ({ context }) => (await desk()).listJobs(context.userId));
var saveJob_createServerFn_handler = createServerRpc({
	id: "7adfaffc207e29ea9268f65c185ba1fcc5c9430d6e7acc2d69c0bf24b2920191",
	name: "saveJob",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveJob.__executeServer(opts));
var saveJob = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	title: string().min(2).max(80),
	site: string().max(80),
	tower: string().max(80),
	assignee: string().max(60),
	notes: string().max(400)
}).parse(input)).handler(saveJob_createServerFn_handler, async ({ context, data }) => (await desk()).saveJob(context.userId, data));
var setJobStatus_createServerFn_handler = createServerRpc({
	id: "6b241a7fe0b5f0e27b4716034b318911795706bf3fa4482002c9f8452499b560",
	name: "setJobStatus",
	filename: "src/lib/noc/desk.ts"
}, (opts) => setJobStatus.__executeServer(opts));
var setJobStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	status: _enum([
		"open",
		"assigned",
		"done",
		"closed"
	])
}).parse(input)).handler(setJobStatus_createServerFn_handler, async ({ context, data }) => (await desk()).setJobStatus(context.userId, data.id, data.status));
var listInventory_createServerFn_handler = createServerRpc({
	id: "07374168c8bf5f98fa806e4c612a8623d78071c96365594ce9734c9e832e3401",
	name: "listInventory",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listInventory.__executeServer(opts));
var listInventory = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listInventory_createServerFn_handler, async ({ context }) => (await desk()).listInventory(context.userId));
var saveInventory_createServerFn_handler = createServerRpc({
	id: "cdb4d0cb2bccf2cb38e1fe4a3d350ed51e1d5fdd0218233e478693c4cb3b01cb",
	name: "saveInventory",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveInventory.__executeServer(opts));
var saveInventory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	kind: string().max(20),
	serial: string().max(40),
	model: string().max(40),
	qty: number().int().min(1).max(1e4),
	buyPrice: number().int().min(0).max(5e7),
	location: string().max(80),
	state: string().max(20),
	warranty: string().max(40),
	boughtOn: string().max(20)
}).parse(input)).handler(saveInventory_createServerFn_handler, async ({ context, data }) => (await desk()).saveInventory(context.userId, data));
var listChannels_createServerFn_handler = createServerRpc({
	id: "1a98656b20cd39e8fd353df692fa017d982bf2eb3ed355f43cfd4dedcf8559b8",
	name: "listChannels",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listChannels.__executeServer(opts));
var listChannels = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listChannels_createServerFn_handler, async ({ context }) => (await desk()).listChannels(context.userId));
var saveChannels_createServerFn_handler = createServerRpc({
	id: "aaa5ac7d026bdf5ddd3831ddc89b531514f4c6eadf9543a36dcceb80d9233a64",
	name: "saveChannels",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveChannels.__executeServer(opts));
var saveChannels = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	token: string().max(120),
	chat: string().max(40),
	waPhone: string().max(20),
	waNote: string().max(400)
}).parse(input)).handler(saveChannels_createServerFn_handler, async ({ context, data }) => (await desk()).saveChannels(context.userId, data));
var testTelegram_createServerFn_handler = createServerRpc({
	id: "2f613c2c7826754c3bd0fda62f5cf743d155046e5f80d269298b6b4f704e103b",
	name: "testTelegram",
	filename: "src/lib/noc/desk.ts"
}, (opts) => testTelegram.__executeServer(opts));
var testTelegram = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ send: boolean() }).parse(input)).handler(testTelegram_createServerFn_handler, async ({ context, data }) => (await desk()).testTelegram(context.userId, data.send));
var holdWhatsapp_createServerFn_handler = createServerRpc({
	id: "ba1ede3e4d84a9bbbe5e80d2b3e34fb295be678ac4730593f7f025bbcbe93ce5",
	name: "holdWhatsapp",
	filename: "src/lib/noc/desk.ts"
}, (opts) => holdWhatsapp.__executeServer(opts));
var holdWhatsapp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	to: string().min(6).max(20),
	body: string().min(2).max(400)
}).parse(input)).handler(holdWhatsapp_createServerFn_handler, async ({ context, data }) => (await desk()).holdWhatsapp(context.userId, data));
var listTickets_createServerFn_handler = createServerRpc({
	id: "21536f59813c743f45b37e1a46464a700dbca9e01c5e973e6521c4137f5bb46f",
	name: "listTickets",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listTickets.__executeServer(opts));
var listTickets = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTickets_createServerFn_handler, async ({ context }) => (await desk()).listTickets(context.userId));
var saveTicket_createServerFn_handler = createServerRpc({
	id: "9d63732ab407480cc475d2ebe8817339197cca4aa53c4d66ca04afcd6ea5f175",
	name: "saveTicket",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveTicket.__executeServer(opts));
var saveTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	subject: string().min(2).max(80),
	body: string().min(2).max(800)
}).parse(input)).handler(saveTicket_createServerFn_handler, async ({ context, data }) => (await desk()).saveTicket(context.userId, data));
var closeTicket_createServerFn_handler = createServerRpc({
	id: "e3086338241cfc12ba4cd70daa9cd4eef74f946266c7e47da5200dbf67323716",
	name: "closeTicket",
	filename: "src/lib/noc/desk.ts"
}, (opts) => closeTicket.__executeServer(opts));
var closeTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(closeTicket_createServerFn_handler, async ({ context, data }) => (await desk()).closeTicket(context.userId, data.id));
var listNetwork_createServerFn_handler = createServerRpc({
	id: "8a6313c95b3590fedd164fe8f2a531bc7f198c8e4577a2e730dd0a970917b4af",
	name: "listNetwork",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listNetwork.__executeServer(opts));
var listNetwork = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listNetwork_createServerFn_handler, async ({ context }) => (await desk()).listNetwork(context.userId));
var saveNetNote_createServerFn_handler = createServerRpc({
	id: "0c5a4739ced788fbb37464a3abc49a534bc66bff8ac9fec2b16846ed184c3cc8",
	name: "saveNetNote",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveNetNote.__executeServer(opts));
var saveNetNote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	area: string().max(20),
	name: string().min(2).max(80),
	detail: string().max(400)
}).parse(input)).handler(saveNetNote_createServerFn_handler, async ({ context, data }) => (await desk()).saveNetNote(context.userId, data));
var diagnose_createServerFn_handler = createServerRpc({
	id: "3384068c6c5119834b8a43d2dea1a8f3ac69e64353b268049215d39b7a92d09f",
	name: "diagnose",
	filename: "src/lib/noc/desk.ts"
}, (opts) => diagnose.__executeServer(opts));
var diagnose = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(diagnose_createServerFn_handler, async ({ context }) => (await desk()).diagnose(context.userId));
var assist_createServerFn_handler = createServerRpc({
	id: "bc0743f38d858e24ce6970bec4d69e4da6bd9c6b9c3793d9f1f082bae29154d0",
	name: "assist",
	filename: "src/lib/noc/desk.ts"
}, (opts) => assist.__executeServer(opts));
var assist = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ question: string().max(300) }).parse(input)).handler(assist_createServerFn_handler, async ({ context, data }) => (await desk()).assist(context.userId, data.question));
var saveSubscriber_createServerFn_handler = createServerRpc({
	id: "6624b7994486c22e4f8e5501ee53525fd6147318b2cfb701f75ad62541bf55c3",
	name: "saveSubscriber",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveSubscriber.__executeServer(opts));
var saveSubscriber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	phone: string().max(20),
	address: string().max(80),
	tower: string().max(80),
	antenna: string().max(80),
	service: string().max(20),
	account: string().max(40),
	plan: string().max(40),
	endsOn: string().max(20)
}).parse(input)).handler(saveSubscriber_createServerFn_handler, async ({ context, data }) => (await desk()).saveSubscriber(context.userId, data));
var recordPayment_createServerFn_handler = createServerRpc({
	id: "b8a58f2f460bce36fbf55695396807eb27c14b14e702513c12c9a43a7ecbf491",
	name: "recordPayment",
	filename: "src/lib/noc/desk.ts"
}, (opts) => recordPayment.__executeServer(opts));
var recordPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	subscriberId: string(),
	amount: number().int().min(1).max(5e6),
	note: string().max(160)
}).parse(input)).handler(recordPayment_createServerFn_handler, async ({ context, data }) => (await desk()).recordPayment(context.userId, data));
var listPayments_createServerFn_handler = createServerRpc({
	id: "d3fb2ed759370a652dbc95b2e7624b8be3b0bcda785a751844036687e7004ff3",
	name: "listPayments",
	filename: "src/lib/noc/desk.ts"
}, (opts) => listPayments.__executeServer(opts));
var listPayments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPayments_createServerFn_handler, async ({ context }) => (await desk()).listPayments(context.userId));
var saveTower_createServerFn_handler = createServerRpc({
	id: "06529aa178bfe3f32d211b6129a2b06956cbcbb12e84e0ca000a86f41862ab76",
	name: "saveTower",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveTower.__executeServer(opts));
var saveTower = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	site: string().max(80),
	lat: string().max(20),
	lng: string().max(20),
	routerId: string().max(80),
	power: string().max(80),
	notes: string().max(200)
}).parse(input)).handler(saveTower_createServerFn_handler, async ({ context, data }) => (await desk()).saveTower(context.userId, data));
var saveAntenna_createServerFn_handler = createServerRpc({
	id: "bf84217e1723fe6dffd1c8649377670129b846aad529744556237edc7b114691",
	name: "saveAntenna",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveAntenna.__executeServer(opts));
var saveAntenna = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	towerId: string(),
	name: string().min(2).max(80),
	model: string().max(40),
	ip: string().max(40),
	frequency: string().max(20),
	channel: string().max(20)
}).parse(input)).handler(saveAntenna_createServerFn_handler, async ({ context, data }) => (await desk()).saveAntenna(context.userId, data));
var saveSource_createServerFn_handler = createServerRpc({
	id: "9fc0e15370e35b1f47c8d02a61fe051f47b2cae6892076cb3ed5bb909a549e35",
	name: "saveSource",
	filename: "src/lib/noc/desk.ts"
}, (opts) => saveSource.__executeServer(opts));
var saveSource = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	kind: string().max(20),
	iface: string().max(40),
	contracted: string().max(40),
	cost: number().int().min(0).max(5e7).nullable(),
	routerId: string().max(80),
	note: string().max(200)
}).parse(input)).handler(saveSource_createServerFn_handler, async ({ context, data }) => (await desk()).saveSource(context.userId, data));
//#endregion
export { assist_createServerFn_handler, closeTicket_createServerFn_handler, diagnose_createServerFn_handler, holdWhatsapp_createServerFn_handler, listChannels_createServerFn_handler, listInventory_createServerFn_handler, listJobs_createServerFn_handler, listNetwork_createServerFn_handler, listPayments_createServerFn_handler, listResellers_createServerFn_handler, listTickets_createServerFn_handler, listUm_createServerFn_handler, recordPayment_createServerFn_handler, reverseWallet_createServerFn_handler, saveAntenna_createServerFn_handler, saveChannels_createServerFn_handler, saveInventory_createServerFn_handler, saveJob_createServerFn_handler, saveNetNote_createServerFn_handler, saveReseller_createServerFn_handler, saveSource_createServerFn_handler, saveSubscriber_createServerFn_handler, saveTicket_createServerFn_handler, saveTower_createServerFn_handler, saveUm_createServerFn_handler, setJobStatus_createServerFn_handler, setUmDisabled_createServerFn_handler, testTelegram_createServerFn_handler, walletMove_createServerFn_handler };
