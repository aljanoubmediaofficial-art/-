import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as runScript, F as saveScript, b as listRouters, x as listScripts } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scripts-Mp0kYiYB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ScriptsPage() {
	const load = (0, import_react.useCallback)(() => listScripts(), []);
	const { data, error, loading, reload } = useLoad(load);
	const routers = useLoad((0, import_react.useCallback)(() => listRouters(), []));
	const [routerId, setRouterId] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	async function run(id) {
		try {
			const result = await runScript({ data: {
				id,
				routerId: routerId || routers.data?.routers[0]?.id || ""
			} });
			if (result.ok) toast.success(result.message);
			else toast.message(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function save(event) {
		event.preventDefault();
		try {
			const result = await saveScript({ data: {
				name,
				body
			} });
			toast.success(result.message);
			setName("");
			setBody("");
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "قائمة معتمدة فقط",
			title: "السكربتات"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "الراوتر المستهدف",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "field",
				value: routerId,
				onChange: (e) => setRouterId(e.target.value),
				children: (routers.data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: router.id,
					children: router.name
				}, router.id))
			})
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [(data?.builtin ?? []).map((script) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: script.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: ["الخطورة: ", script.danger]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-2 whitespace-pre-wrap text-sm text-muted",
						children: script.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary mt-3",
						onClick: () => void run(script.id),
						children: "تنفيذ بعد المراجعة"
					})
				]
			}, script.id)), (data?.drafts ?? []).map((script) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: script.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-warn",
						children: "بانتظار المراجعة — التشغيل مرفوض"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-2 whitespace-pre-wrap text-sm text-muted",
						children: script.body
					})
				]
			}, script.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel mt-4 grid gap-3 p-4",
			onSubmit: (e) => void save(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "سكربت للمراجعة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الاسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "النص",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-28",
						value: body,
						onChange: (e) => setBody(e.target.value),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-ghost",
					type: "submit",
					children: "حفظ دون تشغيل"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 font-semibold",
				children: "سجل التنفيذ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: (data?.runs ?? []).map((runItem, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						formatWhen(runItem.createdAt),
						" · ",
						runItem.name,
						" · ",
						runItem.status,
						" · ",
						runItem.detail
					]
				}, `${runItem.createdAt}-${index}`))
			})]
		})
	] });
}
//#endregion
export { ScriptsPage as component };
