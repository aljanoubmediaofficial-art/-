import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { L as saveTemplate, T as listTemplates } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/templates-Bx4s9f43.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TemplatesPage() {
	const load = (0, import_react.useCallback)(() => listTemplates(), []);
	const { data, error, loading, reload } = useLoad(load);
	const current = data?.[0];
	const [name, setName] = (0, import_react.useState)("");
	const [footer, setFooter] = (0, import_react.useState)("");
	const [flags, setFlags] = (0, import_react.useState)({
		showUser: true,
		showPass: true,
		showPrice: true,
		showValidity: true,
		showProfile: true,
		showQr: true
	});
	const ready = current && name === "" ? current : null;
	const view = {
		name: name || current?.name || "كرت جديد",
		footer: footer || current?.footer || "",
		...name === "" && current ? current : flags
	};
	async function save() {
		try {
			await saveTemplate({ data: {
				id: current?.id,
				name: view.name,
				accent: "cyan",
				showUser: view.showUser,
				showPass: view.showPass,
				showPrice: view.showPrice,
				showValidity: view.showValidity,
				showProfile: view.showProfile,
				showQr: view.showQr,
				footer: view.footer
			} });
			toast.success("حُفظ القالب");
			setName("");
			setFooter("");
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	const toggle = (key) => setFlags((prev) => {
		const base = current && name === "" ? { ...current } : prev;
		return {
			...base,
			[key]: !base[key]
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "حقول الكرت لا مواضع حرة",
			title: "قالب الطباعة"
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اسم القالب",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: name || current?.name || "",
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تذييل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: footer || current?.footer || "",
							onChange: (e) => setFooter(e.target.value)
						})
					}),
					[
						"showUser",
						"showPass",
						"showPrice",
						"showValidity",
						"showProfile",
						"showQr"
					].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: Boolean(view[key]),
							onChange: () => toggle(key)
						}), label(key)]
					}, key)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "رمز QR يحمل اسم المستخدم فقط، ولا يضع كلمة المرور في رابط."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => void save(),
						children: "حفظ القالب"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-cyan-text",
						children: "معاينة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-xl font-semibold",
						children: view.name
					}),
					view.showUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ltr mt-3",
						children: "ZN10421"
					}) : null,
					view.showPass ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ltr",
						children: "ZN10421"
					}) : null,
					view.showPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: "200 ر.ي"
					}) : null,
					view.showValidity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "١ يوم" }) : null,
					view.showProfile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يوم-٢ميجا" }) : null,
					view.showQr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-16 w-16 rounded-lg border border-line",
						"aria-hidden": "true"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: view.footer
					}),
					ready ? null : null
				]
			})]
		})
	] });
}
function label(key) {
	return {
		showUser: "اسم المستخدم",
		showPass: "كلمة المرور",
		showPrice: "السعر",
		showValidity: "الصلاحية",
		showProfile: "البروفايل",
		showQr: "رمز المستخدم"
	}[key] ?? key;
}
//#endregion
export { TemplatesPage as component };
