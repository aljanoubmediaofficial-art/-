import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as saveRouter, b as listRouters, n as connectRouter } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, r as Modal, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routers-BFLRuSTe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	name: "",
	host: "",
	port: 8729,
	connType: "api-ssl",
	apiUser: "",
	password: "",
	rosHint: "",
	site: "",
	tower: "",
	notes: "",
	wanInterface: ""
};
function RoutersPage() {
	const load = (0, import_react.useCallback)(() => listRouters(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(empty);
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setPending(true);
		try {
			const saved = await saveRouter({ data: {
				...form,
				port: Number(form.port)
			} });
			toast.success("حُفظ الراوتر. افحص الاتصال من صفحته.");
			setOpen(false);
			setForm(empty);
			await reload();
			if (form.host) {
				const probe = await connectRouter({ data: { id: saved.id } });
				if (probe.needsTrust) toast.message(`بصمة الشهادة: ${probe.fingerprint}`);
				else if (!probe.ok) toast.error(probe.message);
				else toast.success(probe.message);
				await reload();
			}
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "الاتصال يمر من المنصة لا من المتصفح",
			title: "الراوترات",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setOpen(true),
				children: "إضافة"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "panel mb-4 p-4 text-sm text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-fg",
					children: "ربط MikroTik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "أنشئ مستخدم API بصلاحية القراءة، وفعّل API-SSL على 8729. لا تفتح المنفذ للعالم. العنوان الخاص لا يصل من منصة خارج الشبكة إلا عبر نفق. الشهادة الذاتية تُثبَّت بمطابقة البصمة، ولا يُتجاوز التحقق بصمت."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2",
					children: [
						"الحد الحالي للراوترات الحقيقية: ",
						data ? `${data.license.liveRouters} / ${data.license.routerLimit}` : "…",
						" . المختبر لا يُحتسب."
					]
				})
			]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/routers/$routerId",
				params: { routerId: router.id },
				className: "panel block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: router.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(router.status)}`,
							children: statusText(router.status)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							router.mode === "lab" ? "مختبر" : "حقيقي",
							" · ",
							router.host || "بدون عنوان",
							" · ",
							router.site || "بدون موقع"
						]
					}),
					router.lastError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: router.lastError
					}) : null
				]
			}, router.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: "راوتر جديد",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (e) => void submit(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							required: true,
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "العنوان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.host,
							onChange: (e) => setForm({
								...form,
								host: e.target.value
							}),
							placeholder: "عنوان عام أو عبر النفق"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نوع الاتصال",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: form.connType,
							onChange: (e) => setForm({
								...form,
								connType: e.target.value,
								port: e.target.value === "api" ? 8728 : 8729
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "api-ssl",
								children: "API-SSL 8729"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "api",
								children: "API 8728 غير مشفّر"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المستخدم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.apiUser,
							onChange: (e) => setForm({
								...form,
								apiUser: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "كلمة المرور",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "password",
							value: form.password,
							onChange: (e) => setForm({
								...form,
								password: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تلميح الإصدار (لا يُعرض كقراءة)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.rosHint,
							onChange: (e) => setForm({
								...form,
								rosHint: e.target.value
							}),
							placeholder: "6 أو 7"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الموقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.site,
							onChange: (e) => setForm({
								...form,
								site: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "البرج",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.tower,
							onChange: (e) => setForm({
								...form,
								tower: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "منفذ الإنترنت للقياس",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.wanInterface,
							onChange: (e) => setForm({
								...form,
								wanInterface: e.target.value
							}),
							placeholder: "ether1"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field",
							value: form.notes,
							onChange: (e) => setForm({
								...form,
								notes: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						disabled: pending,
						type: "submit",
						children: pending ? "جارٍ الحفظ…" : "حفظ وفحص"
					})
				]
			})
		})
	] });
}
//#endregion
export { RoutersPage as component };
