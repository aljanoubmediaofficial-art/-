import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D6nHeuCK.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { cn as _enum, dn as boolean, gn as object, hn as number, un as array, yn as string } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BC5M9OSJ.js
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a79cb6ed7bdb6ec68b44333f9d2232dcf3b1e0ffbb46abe8d1f9c86f3c364251"));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f95e950f1f924cb6c7c2a5f53e77d736887d9b9a491e30d20b7ac11f443a63d3"));
var listRouters = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("57ba66a21894c4100430246055c7b146c5359ff3293459cd6b124eb7b6c53564"));
var getRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("8d1191acbcfd5a7330566dad0fc1e7ae8c9019a90195bf8736e8836c0147bc19"));
var routerInput = object({
	id: string().optional(),
	name: string().min(2).max(80),
	host: string().max(253),
	port: number().int().min(1).max(65535),
	connType: _enum(["api", "api-ssl"]),
	apiUser: string().max(64),
	password: string().max(128).optional(),
	rosHint: string().max(40),
	site: string().max(80),
	tower: string().max(80),
	notes: string().max(400),
	wanInterface: string().max(64)
});
var saveRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => routerInput.parse(input)).handler(createSsrRpc("40f491f0b5aabeb771cd0977f241205ee30c100f51ec5e1c13cdec1fabbc4e90"));
var connectRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	trust: string().max(128).optional()
}).parse(input)).handler(createSsrRpc("f110e98850b1f383f760690d4b7c430676b50660c63f40c7ae6373afead52d4b"));
var deleteRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("63416f142277e02904fbd056deed2b6f41c594cb8c45056ce308307b4ad5e004"));
var rebootRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	confirmName: string().max(80)
}).parse(input)).handler(createSsrRpc("28cadd50dd65830880f18d4e86d9c8aaf871cffe293e1ebe2f753c4bd99b9178"));
var listSessions = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("5fd53a0828ce29b50f646e8f6754226e3967f431b3288ce0e679cea27769ed9c"));
var disconnectSession = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("d1c6a7b60058271949cbbb06410eb99f1e15967cc0d90ffb48647125f5302485"));
var listHotspot = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c3b340b3a34f84477f71af676e24d86851090a9db09dc781cff245e03f401e84"));
var listPppoe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("88b89a12ba354f46afdea535b215149caca1016a4846a41ad3be3a3aca4f7dfb"));
var serviceUser = object({
	id: string().optional(),
	routerId: string(),
	username: string().min(2).max(32),
	password: string().max(64),
	profile: string().max(64),
	mac: string().max(32).optional(),
	remoteAddress: string().max(64).optional(),
	comment: string().max(160),
	disabled: boolean(),
	expiresOn: string().max(20)
});
var saveHotspot = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => serviceUser.parse(input)).handler(createSsrRpc("12b4661d5afbb77706deb22e1cdf9781fcb244306babec00e3b658ad8531d5bc"));
var savePppoe = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => serviceUser.parse(input)).handler(createSsrRpc("7833abc32481ab4932216c511f189ce22608dac495238dd0919913664ddb9cc6"));
var setUserDisabled = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	kind: _enum(["hotspot", "pppoe"]),
	id: string(),
	disabled: boolean()
}).parse(input)).handler(createSsrRpc("5446e6079f38ec9225029be1a531d9fdea989e5374aafc093849d59be4453095"));
var listProfiles = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("cacdb64eaed3768bf3b6d8bf176735209e2a025b1ff75e328cc182b24523f9ff"));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	price: number().int().min(0).max(1e6),
	rateDown: string().max(20),
	rateUp: string().max(20),
	validity: string().max(40),
	sharedUsers: number().int().min(1).max(50),
	dataLimit: string().max(40)
}).parse(input)).handler(createSsrRpc("d2709e391685b5e48cb6bb7daa7eea1df03e449be2baf38a7d10680805e4a076"));
var listVouchers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d479063dc1428a07554003480394d81e9439b4fa2f5a7ee98d791929457794fa"));
var generateVouchers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	routerId: string(),
	profile: string().max(64),
	price: number().int().min(0).max(1e6),
	cardType: _enum([
		"user",
		"same",
		"different"
	]),
	count: number().int().min(1).max(100),
	length: number().int().min(4).max(10),
	charset: _enum([
		"digits",
		"letters",
		"mixed"
	]),
	prefix: string().max(8),
	validity: string().max(40),
	recordSale: boolean()
}).parse(input)).handler(createSsrRpc("be7ada8ef7ce80d6c6ced6702a1c5b166ab9d4d858ecd269942fbc6167d2c185"));
var sellVouchers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ ids: array(string()).max(100) }).parse(input)).handler(createSsrRpc("742fc60aa1f51e786feb13c4fa78c76a8ce23ff2f3f75410a74340884d227e2e"));
var setVoucherStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	status: _enum(["new", "disabled"])
}).parse(input)).handler(createSsrRpc("6c0edb796df698c8b8d5179f72d470232f955cc945bcc0f2853b411b76862888"));
var voucherCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ ids: array(string()).max(60) }).parse(input)).handler(createSsrRpc("6afed8323c847d420f8ced10edd28f0acf5466ca8d63abc30ddb35f4a566e80b"));
var listTemplates = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d4a777df987bde2f4865958d3a9123c4a1db594aeab9635a0208e9942547bfb4"));
var saveTemplate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string().optional(),
	name: string().min(2).max(40),
	accent: string().max(20),
	showUser: boolean(),
	showPass: boolean(),
	showPrice: boolean(),
	showValidity: boolean(),
	showProfile: boolean(),
	showQr: boolean(),
	footer: string().max(80)
}).parse(input)).handler(createSsrRpc("58e3f0d3f59fd752f400d41648e75b7d046b6bef44ef7eff5e150f3b92ef4675"));
var listDevices = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e7ff8f0f6f2a2d942125724cc5888e3fef514748b968a1fb071a2ff71bea040e"));
var listTopology = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("2cd46fea541f479c6256159e73e64bffaf3c5e054c653817f59f9f4d8fe749f9"));
var listAlerts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7f9cb38e3c40bbb8e8b5d60e6fa68ba05db92a739a7b0598c7e1aac20d0f24b8"));
var ackAlert = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("2ac47d6b8f194445a70f3f62a448b5ba866205aac245a973cbc1b8bafb16c52a"));
var listBackups = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ad7fc6d2002039fb54c33d36c3268225ab3e98e90978c14066f44a559f11a281"));
var createBackup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ routerId: string() }).parse(input)).handler(createSsrRpc("138d4c4b84fc3d151f2ccfe147c8edfd30f6596246e1dccdf1b458a8ecf050df"));
var downloadBackup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("2fe7eceda733e522a5f3037c281ea7a1b23d4e8f23fd60ae032a1522c5e0174c"));
var explainRestore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("d60f77870eb107746a2035f20b0af248c5646ca637ed31bc16abc2d4b255b7ec"));
var getReports = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d8a49ac900222c5b511c1f082e501fbe75242dae128ef30d8a946ebcbdf49937"));
var listAudit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("0a200a545630006c056e1a2bbcc5471d9123c1123dfe2805de27c20bb5a174db"));
var listScripts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("2c580850a0fce233ee13de978c94768a8c81f0fc4af93fdb8338527ee66dc5d2"));
var saveScript = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(60),
	body: string().min(1).max(4e3)
}).parse(input)).handler(createSsrRpc("93ed95c28ac6caa23278e583f1cd258f065004527c868083ebab44c50b7abc07"));
var runScript = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	routerId: string()
}).parse(input)).handler(createSsrRpc("19d6c26acb587d21966887f45588dfa63fcf29a59adaeeacebe489fbbc2e12dc"));
var listSubscribers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e5debe0d0c341b237dae92bb34df2e9fb7af9e6cc8b350bcb4c290ee63bea76a"));
var renewSubscriber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	days: number().int()
}).parse(input)).handler(createSsrRpc("97eb6e06702c01e535a96b0e240129fc9bbe5a78b1f943e79d6ff7437b8e0ab0"));
var listStaff = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("691de4a37db4f26ccc827e55da17fbe1d7f5800a7e9cf5b3a3b2c4833af0b680"));
var saveStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string().optional(),
	name: string().min(2).max(60),
	role: string().max(20),
	phone: string().max(20),
	active: boolean()
}).parse(input)).handler(createSsrRpc("5343e96051461b4f4b11f2f29f85fb751de14617a30cf1c5df074fa7d9d6290b"));
var updateWorkspace = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	area: string().max(80),
	logo: string().max(18e4).nullable().optional()
}).parse(input)).handler(createSsrRpc("e4cb7f7af00fced8fd7f706afab6f289a82b5829ce123aaead82c88a74b63895"));
var setLab = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ action: _enum(["clear", "restore"]) }).parse(input)).handler(createSsrRpc("f597cdefd89864b418848b3a10b2e24ffa76b934e0045cb840d2cc0dce6522b7"));
//#endregion
export { runScript as A, setUserDisabled as B, listStaff as C, listVouchers as D, listTopology as E, saveScript as F, updateWorkspace as H, saveStaff as I, saveTemplate as L, savePppoe as M, saveProfile as N, rebootRouter as O, saveRouter as P, sellVouchers as R, listSessions as S, listTemplates as T, voucherCodes as U, setVoucherStatus as V, listHotspot as _, disconnectSession as a, listRouters as b, generateVouchers as c, getRouter as d, getWorkspace as f, listDevices as g, listBackups as h, deleteRouter as i, saveHotspot as j, renewSubscriber as k, getDashboard as l, listAudit as m, connectRouter as n, downloadBackup as o, listAlerts as p, createBackup as r, explainRestore as s, ackAlert as t, getReports as u, listPppoe as v, listSubscribers as w, listScripts as x, listProfiles as y, setLab as z };
