import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as testTelegram, a as listChannels, g as saveChannels, i as holdWhatsapp } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/channels-CPNbtqrk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChannelsPage() {
	const load = (0, import_react.useCallback)(() => listChannels(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		token: "",
		chat: "",
		waPhone: "",
		waNote: ""
	});
	const [msg, setMsg] = (0, import_react.useState)({
		to: "",
		body: ""
	});
	const [ready, setReady] = (0, import_react.useState)(false);
	const chat = ready ? form.chat : data?.chat ?? "";
	const waPhone = ready ? form.waPhone : data?.waPhone ?? "";
	const waNote = ready ? form.waNote : data?.waNote ?? "";
	async function save(event) {
		event.preventDefault();
		try {
			await saveChannels({ data: {
				token: form.token,
				chat,
				waPhone,
				waNote
			} });
			toast.success("حُفظت القنوات. التوكن مشفّر ولا يُعرض مرة أخرى.");
			setForm({
				...form,
				token: ""
			});
			setReady(true);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function ping(send) {
		try {
			const result = await testTelegram({ data: { send } });
			toast.success(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function hold(event) {
		event.preventDefault();
		try {
			const result = await holdWhatsapp({ data: msg });
			toast.success(result.message);
			setMsg({
				to: "",
				body: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "تيليجرام يُختبر فعلياً",
			title: "القنوات"
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4",
			onSubmit: (e) => void save(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: data?.hasToken ? `توكن محفوظ${data.botName ? ` · ${data.botName}` : ""}. اترك الخانة فارغة للإبقاء عليه.` : "لا يوجد توكن محفوظ."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "توكن البوت",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						type: "password",
						autoComplete: "off",
						value: form.token,
						onChange: (e) => setForm({
							...form,
							token: e.target.value
						}),
						placeholder: "123456:ABC..."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "معرّف المحادثة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: chat,
						onChange: (e) => {
							setReady(true);
							setForm({
								...form,
								chat: e.target.value
							});
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "هاتف واتساب للأعمال",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: waPhone,
						onChange: (e) => {
							setReady(true);
							setForm({
								...form,
								waPhone: e.target.value
							});
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "قالب واتساب المعتمد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-20",
						value: waNote,
						onChange: (e) => {
							setReady(true);
							setForm({
								...form,
								waNote: e.target.value
							});
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							children: "حفظ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-ghost",
							type: "button",
							onClick: () => void ping(false),
							children: "فحص البوت"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-ghost",
							type: "button",
							onClick: () => void ping(true),
							children: "إرسال اختبار"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel mt-4 grid gap-3 p-4",
			onSubmit: (e) => void hold(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "رسالة واتساب محجوزة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "تُحفظ في السجل بحالة «لم تُرسل». لا يُزعم الإرسال دون مزود."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "إلى",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						required: true,
						value: msg.to,
						onChange: (e) => setMsg({
							...msg,
							to: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "النص",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-20",
						required: true,
						value: msg.body,
						onChange: (e) => setMsg({
							...msg,
							body: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary",
					type: "submit",
					children: "حجز الرسالة"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-2",
			children: (data?.outbox ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel px-4 py-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							item.channel === "telegram" ? "تيليجرام" : "واتساب",
							" · ",
							item.to,
							" · ",
							statusText(item.status)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: item.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							item.detail,
							" · ",
							formatWhen(item.createdAt)
						]
					})
				]
			}, item.id))
		})
	] });
}
//#endregion
export { ChannelsPage as component };
