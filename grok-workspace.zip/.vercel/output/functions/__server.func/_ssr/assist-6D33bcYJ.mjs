import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as statusBadge, i as PageHead, s as messageOf } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as assist } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assist-6D33bcYJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRESETS = [
	"لماذا المعالج مرتفع؟",
	"ما الراوترات المنقطعة؟",
	"من تأخر اشتراكه؟",
	"هل الإشارة ضعيفة؟"
];
function AssistPage() {
	const [question, setQuestion] = (0, import_react.useState)(PRESETS[0]);
	const [report, setReport] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function ask(text) {
		setBusy(true);
		try {
			const next = await assist({ data: { question: text } });
			setReport(next);
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "يقرأ سجلاتك فقط",
			title: "مساعد الزهر"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "لا يطبّق تغييراً على الشبكة. إن لم تكفِ الأدلة يقول ذلك صراحة."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex flex-wrap gap-2",
			children: PRESETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost",
				onClick: () => {
					setQuestion(item);
					ask(item);
				},
				children: item
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4",
			onSubmit: (e) => {
				e.preventDefault();
				ask(question);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "field min-h-24",
				value: question,
				onChange: (e) => setQuestion(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn-primary",
				type: "submit",
				disabled: busy,
				children: busy ? "يحلل…" : "حلّل"
			})]
		}),
		report ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: report.note
			}), report.findings.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(item.severity === "ok" ? "online" : item.severity)}`,
							children: item.severity === "danger" ? "مرتفع" : item.severity === "warn" ? "تحذير" : "ملاحظة"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: item.evidence
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: item.action
					})
				]
			}, `${item.title}-${item.evidence}`))]
		}) : null
	] });
}
//#endregion
export { AssistPage as component };
