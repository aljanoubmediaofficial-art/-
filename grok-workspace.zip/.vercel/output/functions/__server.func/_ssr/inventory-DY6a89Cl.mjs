import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney, i as formatInt } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as saveInventory, o as listInventory } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory-DY6a89Cl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KINDS = [
	["router", "راوتر"],
	["antenna", "انتينا"],
	["modem", "مودم"],
	["switch", "سويتش"],
	["cable", "كيبل"],
	["power", "طاقة"],
	["other", "أخرى"]
];
function InventoryPage() {
	const load = (0, import_react.useCallback)(() => listInventory(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		kind: "router",
		serial: "",
		model: "",
		qty: 1,
		buyPrice: 0,
		location: "",
		state: "stock",
		warranty: "",
		boughtOn: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			await saveInventory({ data: form });
			toast.success("سُجّلت القطعة");
			setForm({
				...form,
				name: "",
				serial: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	const kindName = (kind) => KINDS.find((item) => item[0] === kind)?.[1] ?? kind;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "الرقم التسلسلي والموقع",
			title: "المخزون"
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الاسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						required: true,
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "النوع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: form.kind,
						onChange: (e) => setForm({
							...form,
							kind: e.target.value
						}),
						children: KINDS.map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value,
							children: label
						}, value))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الموديل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.model,
						onChange: (e) => setForm({
							...form,
							model: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "التسلسل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.serial,
						onChange: (e) => setForm({
							...form,
							serial: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الكمية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						type: "number",
						min: 1,
						value: form.qty,
						onChange: (e) => setForm({
							...form,
							qty: Number(e.target.value)
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "سعر الشراء",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						type: "number",
						min: 0,
						value: form.buyPrice,
						onChange: (e) => setForm({
							...form,
							buyPrice: Number(e.target.value)
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الموقع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.location,
						onChange: (e) => setForm({
							...form,
							location: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: form.state,
						onChange: (e) => setForm({
							...form,
							state: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "stock",
								children: "مخزن"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "installed",
								children: "مركّب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "spare",
								children: "احتياط"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "faulty",
								children: "عطل"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الضمان",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.warranty,
						onChange: (e) => setForm({
							...form,
							warranty: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "تاريخ الشراء",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						placeholder: "2026-11-05",
						value: form.boughtOn,
						onChange: (e) => setForm({
							...form,
							boughtOn: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary sm:col-span-2",
					type: "submit",
					children: "إضافة"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "badge",
							children: statusText(item.state)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							kindName(item.kind),
							" · ",
							item.model || "بدون موديل",
							" · ",
							item.serial || "بدون تسلسل"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							item.location || "بدون موقع",
							" · كمية ",
							formatInt(item.qty),
							" · ",
							formatMoney(item.buyPrice)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							item.warranty || "ضمان غير مسجّل",
							" · شراء ",
							item.boughtOn || "غير مؤرخ"
						]
					})
				]
			}, item.id))
		})
	] });
}
//#endregion
export { InventoryPage as component };
