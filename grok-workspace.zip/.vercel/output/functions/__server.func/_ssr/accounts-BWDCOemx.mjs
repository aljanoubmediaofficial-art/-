import { o as __toESM } from "../_runtime.mjs";
import { r as formatBytes } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as setUserDisabled, M as savePppoe, b as listRouters, j as saveHotspot } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, n as Field, r as Modal, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accounts-BWDCOemx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountsPage({ title, kind, loader }) {
	const load = (0, import_react.useCallback)(loader, [loader]);
	const { data, error, loading, reload } = useLoad(load);
	const routersLoad = (0, import_react.useCallback)(() => listRouters(), []);
	const routers = useLoad(routersLoad);
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		routerId: "",
		username: "",
		password: "",
		profile: "",
		mac: "",
		remoteAddress: "",
		comment: "",
		disabled: false,
		expiresOn: ""
	});
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return (data ?? []).filter((row) => !query || `${row.username} ${row.mac} ${row.profile}`.toLowerCase().includes(query));
	}, [data, q]);
	async function submit(event) {
		event.preventDefault();
		const payload = {
			...form,
			routerId: form.routerId || routers.data?.routers[0]?.id || ""
		};
		try {
			const result = kind === "hotspot" ? await saveHotspot({ data: payload }) : await savePppoe({ data: payload });
			toast.success(result.message);
			setOpen(false);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function toggle(row) {
		try {
			const result = await setUserDisabled({ data: {
				kind,
				id: row.id,
				disabled: !row.disabled
			} });
			toast.success(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: kind === "hotspot" ? "مستخدمو الهوتسبوت" : "حسابات PPPoE",
			title,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setOpen(true),
				children: "إضافة"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field mb-4",
			placeholder: "بحث",
			value: q,
			onChange: (e) => setQ(e.target.value)
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: row.username
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								row.profile || "بدون بروفايل",
								" · ",
								row.router,
								" · ",
								row.mode === "lab" ? "مختبر" : "حقيقي"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => void toggle(row),
							children: row.disabled ? "تفعيل" : "تعطيل"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm",
						children: [
							"كلمة المرور: ",
							show === row.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ltr",
								children: row.password || "غير متاحة"
							}) : "••••",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "ms-2 text-cyan-text",
								onClick: () => setShow(show === row.id ? null : row.id),
								children: show === row.id ? "إخفاء" : "إظهار"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							kind === "hotspot" ? row.mac || "بدون MAC" : row.remoteAddress || "بدون IP ثابت",
							" · ينتهي ",
							row.expiresOn || "غير محدد",
							" · ",
							formatBytes(row.bytesIn + row.bytesOut),
							" · ",
							row.disabled ? "معطّل" : "فعّال"
						]
					})
				]
			}, row.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: `إضافة ${title}`,
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (e) => void submit(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الراوتر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: form.routerId,
							onChange: (e) => setForm({
								...form,
								routerId: e.target.value
							}),
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر"
							}), (routers.data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: router.id,
								children: [
									router.name,
									" · ",
									router.mode === "lab" ? "مختبر" : "حقيقي"
								]
							}, router.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اسم المستخدم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							required: true,
							value: form.username,
							onChange: (e) => setForm({
								...form,
								username: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "كلمة المرور",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							required: true,
							value: form.password,
							onChange: (e) => setForm({
								...form,
								password: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "البروفايل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.profile,
							onChange: (e) => setForm({
								...form,
								profile: e.target.value
							})
						})
					}),
					kind === "hotspot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "MAC",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.mac,
							onChange: (e) => setForm({
								...form,
								mac: e.target.value
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "IP ثابت",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.remoteAddress,
							onChange: (e) => setForm({
								...form,
								remoteAddress: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ينتهي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "date",
							value: form.expiresOn,
							onChange: (e) => setForm({
								...form,
								expiresOn: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ملاحظة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.comment,
							onChange: (e) => setForm({
								...form,
								comment: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "حفظ"
					})
				]
			})
		})
	] });
}
//#endregion
export { AccountsPage as t };
