import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as listStaff, H as updateWorkspace, I as saveStaff, f as getWorkspace } from "./api-BC5M9OSJ.mjs";
import { a as ROLE_LABEL, i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Dg7SrmbA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const workspace = useLoad((0, import_react.useCallback)(() => getWorkspace(), []));
	const staff = useLoad((0, import_react.useCallback)(() => listStaff(), []));
	const [name, setName] = (0, import_react.useState)("");
	const [area, setArea] = (0, import_react.useState)("");
	const [theme, setTheme] = (0, import_react.useState)("dark");
	const [person, setPerson] = (0, import_react.useState)({
		name: "",
		role: "tech",
		phone: "",
		active: true
	});
	(0, import_react.useEffect)(() => {
		if (workspace.data && !name) {
			setName(workspace.data.tenant.name);
			setArea(workspace.data.tenant.area);
		}
	}, [workspace.data, name]);
	(0, import_react.useEffect)(() => {
		setTheme(document.documentElement.dataset.theme === "light" ? "light" : "dark");
	}, []);
	function applyTheme(next) {
		setTheme(next);
		document.documentElement.dataset.theme = next === "light" ? "light" : "dark";
		localStorage.setItem("alzher-theme", next);
	}
	async function saveNetwork(event) {
		event.preventDefault();
		try {
			await updateWorkspace({ data: {
				name,
				area,
				logo: workspace.data?.tenant.logo ?? null
			} });
			toast.success("حُفظت بيانات الشبكة");
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function onLogo(file) {
		if (!file) return;
		const data = await file.arrayBuffer();
		const bytes = new Uint8Array(data);
		let binary = "";
		bytes.forEach((byte) => {
			binary += String.fromCharCode(byte);
		});
		const mime = file.type === "image/jpeg" ? "image/jpeg" : "image/png";
		try {
			await updateWorkspace({ data: {
				name: name || workspace.data?.tenant.name || "شبكة",
				area,
				logo: `data:${mime};base64,${btoa(binary)}`
			} });
			toast.success("رُفع الشعار");
			window.location.reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function addStaff(event) {
		event.preventDefault();
		try {
			await saveStaff({ data: person });
			toast.success("أُضيف الموظف. الدخول ما زال لحساب المالك فقط.");
			setPerson({
				name: "",
				role: "tech",
				phone: "",
				active: true
			});
			await staff.reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, { title: "الإعدادات" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4",
			onSubmit: (e) => void saveNetwork(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "اسم الشبكة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "النطاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: area,
						onChange: (e) => setArea(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الشعار الرسمي PNG أو JPEG",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "file",
						accept: "image/png,image/jpeg",
						onChange: (e) => void onLogo(e.target.files?.[0])
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "لا يُستبدل شعارك بعلامة مولّدة. إن لم يُرفع، تبقى الكلمة «الزهر» نصاً."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary",
					type: "submit",
					children: "حفظ"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel mt-4 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "المظهر"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `btn ${theme === "dark" ? "btn-primary" : "btn-ghost"}`,
					onClick: () => applyTheme("dark"),
					children: "داكن"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `btn ${theme === "light" ? "btn-primary" : "btn-ghost"}`,
					onClick: () => applyTheme("light"),
					children: "فاتح"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel mt-4 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "الموظفون"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "الحساب الذي دخل هو المالك. سجل الموظف هنا لا يفتح له دخولاً مستقلاً بعد."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-2",
					children: (staff.data?.staff ?? []).map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							member.name,
							" · ",
							ROLE_LABEL[member.role] ?? member.role,
							" · ",
							member.phone
						]
					}, member.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 grid gap-3",
					onSubmit: (e) => void addStaff(e),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الاسم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: person.name,
								onChange: (e) => setPerson({
									...person,
									name: e.target.value
								}),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الدور",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: person.role,
								onChange: (e) => setPerson({
									...person,
									role: e.target.value
								}),
								children: Object.entries(ROLE_LABEL).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: key,
									children: label
								}, key))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الهاتف",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field ltr",
								value: person.phone,
								onChange: (e) => setPerson({
									...person,
									phone: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-ghost",
							type: "submit",
							children: "إضافة"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 text-sm text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "جدار الحماية وDHCP وVPN ليست في هذه النسخة حتى لا تُفتح شاشات بلا تنفيذ." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "واتساب وتيليجرام وخريطة المواقع تُستكمل بعد مسار الربط هذا."
			})]
		})
	] });
}
//#endregion
export { SettingsPage as component };
