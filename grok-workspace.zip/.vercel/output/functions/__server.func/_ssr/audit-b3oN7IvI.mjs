import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as listAudit } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, u as useLoad } from "./kit-DNv6U2L1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-b3oN7IvI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const load = (0, import_react.useCallback)(() => listAudit(), []);
	const { data, error, loading } = useLoad(load);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "لا يُحذف ولا يُعدَّل",
			title: "سجل العمليات"
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: (data ?? []).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel px-4 py-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: row.action
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: row.detail || row.target
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: formatWhen(row.createdAt)
					})
				]
			}, `${row.createdAt}-${index}`))
		})
	] });
}
//#endregion
export { AuditPage as component };
