import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney, i as formatInt } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as listTopology } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { x as saveSource } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sources-DQ_30a9f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SourcesPage() {
	const load = (0, import_react.useCallback)(() => listTopology(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		kind: "Starlink",
		iface: "",
		contracted: "",
		cost: null,
		routerId: "",
		note: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			await saveSource({ data: form });
			toast.success("أُضيف المصدر. حالته تبقى غير مفحوصة حتى تُقاس.");
			setForm({
				name: "",
				kind: "Starlink",
				iface: "",
				contracted: "",
				cost: null,
				routerId: "",
				note: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "قياس الخط لا لوحة المزود",
			title: "مصادر الإنترنت"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "ستارلينك يُراقب كمنفذ وبنج وفقد. لا تُقرأ بيانات تطبيق ستارلينك نفسه، ولا يُعرض قياس غير موجود على أنه صفر."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel mb-4 grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الاسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						required: true,
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "النوع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: form.kind,
						onChange: (e) => setForm({
							...form,
							kind: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Starlink",
								children: "ستارلينك"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Fiber",
								children: "فايبر"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Wireless",
								children: "لاسلكي"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "DSL",
								children: "DSL"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Other",
								children: "آخر"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "المنفذ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.iface,
						onChange: (e) => setForm({
							...form,
							iface: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "السرعة المتعاقد عليها",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.contracted,
						onChange: (e) => setForm({
							...form,
							contracted: e.target.value
						}),
						placeholder: "200/30"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "التكلفة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						type: "number",
						min: 0,
						value: form.cost ?? "",
						onChange: (e) => setForm({
							...form,
							cost: e.target.value === "" ? null : Number(e.target.value)
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الراوتر",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: form.routerId,
						onChange: (e) => setForm({
							...form,
							routerId: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "بدون ربط"
						}), (data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: router.id,
							children: router.name
						}, router.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ملاحظة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field sm:col-span-2",
						value: form.note,
						onChange: (e) => setForm({
							...form,
							note: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary sm:col-span-2",
					type: "submit",
					children: "إضافة المصدر"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data?.sources ?? []).map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: source.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(source.status)}`,
							children: statusText(source.status)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							source.kind,
							" · ",
							source.iface || "منفذ غير محدد",
							" · تعاقد ",
							source.contracted || "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm tabular-nums",
						children: [
							"تأخير ",
							source.latencyMs === null ? "غير مقاس" : `${formatInt(source.latencyMs)} ms`,
							" · فقد ",
							source.loss ?? "غير مقاس",
							" · تحميل ",
							source.downloadMbps === null ? "غير مقاس" : formatInt(source.downloadMbps),
							" · رفع ",
							source.uploadMbps === null ? "غير مقاس" : formatInt(source.uploadMbps)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: ["التكلفة: ", source.cost === null ? "غير مسجّلة" : formatMoney(source.cost)]
					}),
					source.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: source.note
					}) : null
				]
			}, source.id))
		})
	] });
}
//#endregion
export { SourcesPage as component };
