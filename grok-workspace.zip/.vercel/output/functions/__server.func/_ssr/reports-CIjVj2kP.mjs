import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney, i as formatInt } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as getReports } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, u as useLoad } from "./kit-DNv6U2L1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-CIjVj2kP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReportsPage() {
	const load = (0, import_react.useCallback)(() => getReports(), []);
	const { data, error, loading } = useLoad(load);
	function csv() {
		if (!data) return;
		const body = data.days.map((day) => `${day.day},${day.qty},${day.amount}`).join("\n");
		const blob = new Blob([`\uFEFFday,qty,amount\n${body}`], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "sales.csv";
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "التقارير",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost",
				onClick: csv,
				children: "تصدير المبيعات"
			})
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4 grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "جلسات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xl tabular-nums",
							children: formatInt(data.tech.sessions)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "راوترات متصلة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xl tabular-nums",
							children: formatInt(data.tech.online)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "تنبيهات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xl tabular-nums",
							children: formatInt(data.tech.alerts)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: ["مصدر المبيعات: ", data.origins.map((item) => `${item.origin === "lab" ? "مختبر" : "تشغيل"} ${formatMoney(item.amount)}`).join(" · ") || "لا مبيعات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: data.days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel flex items-center justify-between px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ltr",
						children: day.day
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [
							formatInt(day.qty),
							" كرت · ",
							formatMoney(day.amount)
						]
					})]
				}, day.day))
			})
		] }) : null
	] });
}
//#endregion
export { ReportsPage as component };
