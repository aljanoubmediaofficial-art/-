import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kit-DNv6U2L1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function messageOf(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "object" && error && "message" in error) {
		const msg = error.message;
		if (typeof msg === "string" && msg) return msg;
	}
	return "تعذر التنفيذ";
}
function useLoad(loader) {
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const reload = (0, import_react.useCallback)(() => {
		setLoading(true);
		return loader().then((next) => {
			setData(next);
			setError(null);
			setLoading(false);
			return next;
		}).catch((error) => {
			setError(messageOf(error));
			setLoading(false);
			throw error;
		});
	}, [loader]);
	(0, import_react.useEffect)(() => {
		let dead = false;
		setLoading(true);
		loader().then((next) => {
			if (!dead) {
				setData(next);
				setError(null);
			}
		}).catch((error) => {
			if (!dead) setError(messageOf(error));
		}).finally(() => {
			if (!dead) setLoading(false);
		});
		return () => {
			dead = true;
		};
	}, [loader]);
	return {
		data,
		error,
		loading,
		reload
	};
}
function PageHead({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-5 flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 text-sm text-cyan-text",
			children: kicker
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold",
			children: title
		})] }), children]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-2xl font-semibold tabular-nums",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Empty({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel px-5 py-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-2 max-w-md text-sm text-pretty text-muted",
			children: body
		})]
	});
}
function Modal({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim fixed inset-0 z-40 grid place-items-end p-3 sm:place-items-center",
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel max-h-[90vh] w-full max-w-lg overflow-y-auto p-5",
			role: "dialog",
			"aria-modal": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost min-h-10 px-3",
					onClick: onClose,
					children: "إغلاق"
				})]
			}), children]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "lbl",
			children: label
		}), children]
	});
}
var ROLE_LABEL = {
	manager: "مدير",
	supervisor: "مشرف",
	seller: "بائع",
	tech: "فني",
	accountant: "محاسب"
};
function statusBadge(status) {
	if ([
		"online",
		"active",
		"sold",
		"done",
		"closed",
		"sent",
		"stock",
		"installed",
		"spare",
		"ok"
	].includes(status)) return "badge-ok";
	if ([
		"offline",
		"disabled",
		"danger",
		"faulty",
		"failed"
	].includes(status)) return "badge-danger";
	if ([
		"unknown",
		"due",
		"warn",
		"new",
		"open",
		"assigned",
		"held"
	].includes(status)) return "badge-warn";
	return "";
}
function statusText(status) {
	return {
		online: "متصل",
		offline: "منقطع",
		unknown: "لم يُفحص",
		active: "ساري",
		due: "متأخر",
		new: "جديد",
		sold: "مباع",
		disabled: "معطّل",
		lab: "مختبر",
		live: "حقيقي",
		authenticated: "جلسة دخول",
		hotspot: "هوتسبوت",
		pppoe: "PPPoE",
		open: "مفتوح",
		assigned: "معيّن",
		done: "منجز",
		closed: "مغلق",
		stock: "مخزن",
		installed: "مركّب",
		spare: "احتياط",
		faulty: "عطل",
		held: "لم يُرسل",
		sent: "أُرسل",
		failed: "فشل"
	}[status] ?? status;
}
//#endregion
export { ROLE_LABEL as a, statusBadge as c, PageHead as i, statusText as l, Field as n, Stat as o, Modal as r, messageOf as s, Empty as t, useLoad as u };
