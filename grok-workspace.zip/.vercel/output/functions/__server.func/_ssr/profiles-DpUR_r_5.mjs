import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as saveProfile, y as listProfiles } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, n as Field, r as Modal, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profiles-DpUR_r_5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilesPage() {
	const load = (0, import_react.useCallback)(() => listProfiles(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(false);
	async function apply() {
		if (!edit) return;
		try {
			const result = await saveProfile({ data: {
				id: edit.id,
				price: Number(edit.price),
				rateDown: edit.rateDown,
				rateUp: edit.rateUp,
				validity: edit.validity,
				sharedUsers: Number(edit.sharedUsers),
				dataLimit: edit.dataLimit
			} });
			toast.success(result.message);
			setEdit(null);
			setPreview(false);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "تعديل الحد فقط",
			title: "البروفايلات والسرعات"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "لا تُنشأ Simple Queue جديدة من هنا حتى لا تتعارض القواعد. القيمة المرسلة هي rate-limit بالشكل تحميل/رفع."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data ?? []).map((profile) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: profile.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							profile.kind,
							" · ",
							profile.router,
							" · ",
							profile.mode === "lab" ? "مختبر" : "حقيقي"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => setEdit({
							id: profile.id,
							name: profile.name,
							price: profile.price,
							rateDown: profile.rateDown,
							rateUp: profile.rateUp,
							validity: profile.validity,
							sharedUsers: profile.sharedUsers,
							dataLimit: profile.dataLimit,
							before: `${profile.rateDown}/${profile.rateUp}`
						}),
						children: "تعديل"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm tabular-nums",
					children: [
						profile.rateDown || "—",
						" / ",
						profile.rateUp || "—",
						" · ",
						formatMoney(profile.price),
						" · مشاركة ",
						profile.sharedUsers
					]
				})]
			}, profile.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: Boolean(edit),
			title: edit?.name ?? "",
			onClose: () => {
				setEdit(null);
				setPreview(false);
			},
			children: edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "السعر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							value: edit.price,
							onChange: (e) => setEdit({
								...edit,
								price: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "التحميل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: edit.rateDown,
							onChange: (e) => setEdit({
								...edit,
								rateDown: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الرفع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: edit.rateUp,
							onChange: (e) => setEdit({
								...edit,
								rateUp: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الصلاحية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: edit.validity,
							onChange: (e) => setEdit({
								...edit,
								validity: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المشاركة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							value: edit.sharedUsers,
							onChange: (e) => setEdit({
								...edit,
								sharedUsers: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "حد البيانات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: edit.dataLimit,
							onChange: (e) => setEdit({
								...edit,
								dataLimit: e.target.value
							})
						})
					}),
					preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-surface-2 p-3 text-sm",
						children: [
							"من ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ltr",
								children: edit.before
							}),
							" إلى ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ltr",
								children: [
									edit.rateDown,
									"/",
									edit.rateUp
								]
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => setPreview(true),
							children: "معاينة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: () => void apply(),
							disabled: !preview,
							children: "تطبيق"
						})]
					})
				]
			}) : null
		})
	] });
}
//#endregion
export { ProfilesPage as component };
