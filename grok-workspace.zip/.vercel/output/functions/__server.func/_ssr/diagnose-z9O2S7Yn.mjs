import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as statusBadge, i as PageHead, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { r as diagnose } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diagnose-z9O2S7Yn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DiagnosePage() {
	const load = (0, import_react.useCallback)(() => diagnose(), []);
	const { data, error, loading, reload } = useLoad(load);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "أدلة من السجل لا سبب مؤكد",
			title: "البحث عن المشاكل",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => void reload(),
				children: "إعادة الفحص"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 text-sm text-muted",
			children: ["الفحص يقرأ الراوترات والتنبيهات والاشتراكات والمصادر المخزّنة. لا يشغّل ping على الإنترنت ولا يغيّر الإعدادات.", data ? ` آخر فحص ${formatWhen(data.generatedAt)}. راوترات حقيقية: ${data.liveRouters}.` : ""]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري الفحص…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data?.findings ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(item.severity === "ok" ? "online" : item.severity)}`,
							children: item.severity === "danger" ? "مرتفع" : item.severity === "warn" ? "تحذير" : "سليم"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: item.evidence
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: item.action
					})
				]
			}, `${item.title}-${item.evidence}`))
		})
	] });
}
//#endregion
export { DiagnosePage as component };
