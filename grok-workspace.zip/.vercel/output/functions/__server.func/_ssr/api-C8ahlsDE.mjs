import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D6nHeuCK.mjs";
import { cn as _enum, dn as boolean, gn as object, hn as number, un as array, yn as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-C8ahlsDE.js
async function eng() {
	return import("./engine.server-ZfSrJlAi.mjs");
}
var getWorkspace_createServerFn_handler = createServerRpc({
	id: "a79cb6ed7bdb6ec68b44333f9d2232dcf3b1e0ffbb46abe8d1f9c86f3c364251",
	name: "getWorkspace",
	filename: "src/lib/noc/api.ts"
}, (opts) => getWorkspace.__executeServer(opts));
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWorkspace_createServerFn_handler, async ({ context }) => (await eng()).getWorkspace(context.userId));
var getDashboard_createServerFn_handler = createServerRpc({
	id: "f95e950f1f924cb6c7c2a5f53e77d736887d9b9a491e30d20b7ac11f443a63d3",
	name: "getDashboard",
	filename: "src/lib/noc/api.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDashboard_createServerFn_handler, async ({ context }) => (await eng()).getDashboard(context.userId));
var listRouters_createServerFn_handler = createServerRpc({
	id: "57ba66a21894c4100430246055c7b146c5359ff3293459cd6b124eb7b6c53564",
	name: "listRouters",
	filename: "src/lib/noc/api.ts"
}, (opts) => listRouters.__executeServer(opts));
var listRouters = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listRouters_createServerFn_handler, async ({ context }) => (await eng()).listRouters(context.userId));
var getRouter_createServerFn_handler = createServerRpc({
	id: "8d1191acbcfd5a7330566dad0fc1e7ae8c9019a90195bf8736e8836c0147bc19",
	name: "getRouter",
	filename: "src/lib/noc/api.ts"
}, (opts) => getRouter.__executeServer(opts));
var getRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(getRouter_createServerFn_handler, async ({ context, data }) => (await eng()).getRouter(context.userId, data.id));
var routerInput = object({
	id: string().optional(),
	name: string().min(2).max(80),
	host: string().max(253),
	port: number().int().min(1).max(65535),
	connType: _enum(["api", "api-ssl"]),
	apiUser: string().max(64),
	password: string().max(128).optional(),
	rosHint: string().max(40),
	site: string().max(80),
	tower: string().max(80),
	notes: string().max(400),
	wanInterface: string().max(64)
});
var saveRouter_createServerFn_handler = createServerRpc({
	id: "40f491f0b5aabeb771cd0977f241205ee30c100f51ec5e1c13cdec1fabbc4e90",
	name: "saveRouter",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveRouter.__executeServer(opts));
var saveRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => routerInput.parse(input)).handler(saveRouter_createServerFn_handler, async ({ context, data }) => (await eng()).saveRouter(context.userId, data));
var connectRouter_createServerFn_handler = createServerRpc({
	id: "f110e98850b1f383f760690d4b7c430676b50660c63f40c7ae6373afead52d4b",
	name: "connectRouter",
	filename: "src/lib/noc/api.ts"
}, (opts) => connectRouter.__executeServer(opts));
var connectRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	trust: string().max(128).optional()
}).parse(input)).handler(connectRouter_createServerFn_handler, async ({ context, data }) => (await eng()).connectRouter(context.userId, data.id, data.trust));
var deleteRouter_createServerFn_handler = createServerRpc({
	id: "63416f142277e02904fbd056deed2b6f41c594cb8c45056ce308307b4ad5e004",
	name: "deleteRouter",
	filename: "src/lib/noc/api.ts"
}, (opts) => deleteRouter.__executeServer(opts));
var deleteRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(deleteRouter_createServerFn_handler, async ({ context, data }) => (await eng()).deleteRouter(context.userId, data.id));
var rebootRouter_createServerFn_handler = createServerRpc({
	id: "28cadd50dd65830880f18d4e86d9c8aaf871cffe293e1ebe2f753c4bd99b9178",
	name: "rebootRouter",
	filename: "src/lib/noc/api.ts"
}, (opts) => rebootRouter.__executeServer(opts));
var rebootRouter = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	confirmName: string().max(80)
}).parse(input)).handler(rebootRouter_createServerFn_handler, async ({ context, data }) => (await eng()).rebootRouter(context.userId, data.id, data.confirmName));
var listSessions_createServerFn_handler = createServerRpc({
	id: "5fd53a0828ce29b50f646e8f6754226e3967f431b3288ce0e679cea27769ed9c",
	name: "listSessions",
	filename: "src/lib/noc/api.ts"
}, (opts) => listSessions.__executeServer(opts));
var listSessions = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listSessions_createServerFn_handler, async ({ context }) => (await eng()).listSessions(context.userId));
var disconnectSession_createServerFn_handler = createServerRpc({
	id: "d1c6a7b60058271949cbbb06410eb99f1e15967cc0d90ffb48647125f5302485",
	name: "disconnectSession",
	filename: "src/lib/noc/api.ts"
}, (opts) => disconnectSession.__executeServer(opts));
var disconnectSession = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(disconnectSession_createServerFn_handler, async ({ context, data }) => (await eng()).disconnectSession(context.userId, data.id));
var listHotspot_createServerFn_handler = createServerRpc({
	id: "c3b340b3a34f84477f71af676e24d86851090a9db09dc781cff245e03f401e84",
	name: "listHotspot",
	filename: "src/lib/noc/api.ts"
}, (opts) => listHotspot.__executeServer(opts));
var listHotspot = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listHotspot_createServerFn_handler, async ({ context }) => (await eng()).listHotspot(context.userId));
var listPppoe_createServerFn_handler = createServerRpc({
	id: "88b89a12ba354f46afdea535b215149caca1016a4846a41ad3be3a3aca4f7dfb",
	name: "listPppoe",
	filename: "src/lib/noc/api.ts"
}, (opts) => listPppoe.__executeServer(opts));
var listPppoe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPppoe_createServerFn_handler, async ({ context }) => (await eng()).listPppoe(context.userId));
var serviceUser = object({
	id: string().optional(),
	routerId: string(),
	username: string().min(2).max(32),
	password: string().max(64),
	profile: string().max(64),
	mac: string().max(32).optional(),
	remoteAddress: string().max(64).optional(),
	comment: string().max(160),
	disabled: boolean(),
	expiresOn: string().max(20)
});
var saveHotspot_createServerFn_handler = createServerRpc({
	id: "12b4661d5afbb77706deb22e1cdf9781fcb244306babec00e3b658ad8531d5bc",
	name: "saveHotspot",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveHotspot.__executeServer(opts));
var saveHotspot = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => serviceUser.parse(input)).handler(saveHotspot_createServerFn_handler, async ({ context, data }) => (await eng()).saveHotspot(context.userId, data));
var savePppoe_createServerFn_handler = createServerRpc({
	id: "7833abc32481ab4932216c511f189ce22608dac495238dd0919913664ddb9cc6",
	name: "savePppoe",
	filename: "src/lib/noc/api.ts"
}, (opts) => savePppoe.__executeServer(opts));
var savePppoe = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => serviceUser.parse(input)).handler(savePppoe_createServerFn_handler, async ({ context, data }) => (await eng()).savePppoe(context.userId, data));
var setUserDisabled_createServerFn_handler = createServerRpc({
	id: "5446e6079f38ec9225029be1a531d9fdea989e5374aafc093849d59be4453095",
	name: "setUserDisabled",
	filename: "src/lib/noc/api.ts"
}, (opts) => setUserDisabled.__executeServer(opts));
var setUserDisabled = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	kind: _enum(["hotspot", "pppoe"]),
	id: string(),
	disabled: boolean()
}).parse(input)).handler(setUserDisabled_createServerFn_handler, async ({ context, data }) => (await eng()).setUserDisabled(context.userId, data.kind, data.id, data.disabled));
var listProfiles_createServerFn_handler = createServerRpc({
	id: "cacdb64eaed3768bf3b6d8bf176735209e2a025b1ff75e328cc182b24523f9ff",
	name: "listProfiles",
	filename: "src/lib/noc/api.ts"
}, (opts) => listProfiles.__executeServer(opts));
var listProfiles = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listProfiles_createServerFn_handler, async ({ context }) => (await eng()).listProfiles(context.userId));
var saveProfile_createServerFn_handler = createServerRpc({
	id: "d2709e391685b5e48cb6bb7daa7eea1df03e449be2baf38a7d10680805e4a076",
	name: "saveProfile",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	price: number().int().min(0).max(1e6),
	rateDown: string().max(20),
	rateUp: string().max(20),
	validity: string().max(40),
	sharedUsers: number().int().min(1).max(50),
	dataLimit: string().max(40)
}).parse(input)).handler(saveProfile_createServerFn_handler, async ({ context, data }) => (await eng()).saveProfile(context.userId, data));
var listVouchers_createServerFn_handler = createServerRpc({
	id: "d479063dc1428a07554003480394d81e9439b4fa2f5a7ee98d791929457794fa",
	name: "listVouchers",
	filename: "src/lib/noc/api.ts"
}, (opts) => listVouchers.__executeServer(opts));
var listVouchers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listVouchers_createServerFn_handler, async ({ context }) => (await eng()).listVouchers(context.userId));
var generateVouchers_createServerFn_handler = createServerRpc({
	id: "be7ada8ef7ce80d6c6ced6702a1c5b166ab9d4d858ecd269942fbc6167d2c185",
	name: "generateVouchers",
	filename: "src/lib/noc/api.ts"
}, (opts) => generateVouchers.__executeServer(opts));
var generateVouchers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	routerId: string(),
	profile: string().max(64),
	price: number().int().min(0).max(1e6),
	cardType: _enum([
		"user",
		"same",
		"different"
	]),
	count: number().int().min(1).max(100),
	length: number().int().min(4).max(10),
	charset: _enum([
		"digits",
		"letters",
		"mixed"
	]),
	prefix: string().max(8),
	validity: string().max(40),
	recordSale: boolean()
}).parse(input)).handler(generateVouchers_createServerFn_handler, async ({ context, data }) => (await eng()).generateVouchers(context.userId, data));
var sellVouchers_createServerFn_handler = createServerRpc({
	id: "742fc60aa1f51e786feb13c4fa78c76a8ce23ff2f3f75410a74340884d227e2e",
	name: "sellVouchers",
	filename: "src/lib/noc/api.ts"
}, (opts) => sellVouchers.__executeServer(opts));
var sellVouchers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ ids: array(string()).max(100) }).parse(input)).handler(sellVouchers_createServerFn_handler, async ({ context, data }) => (await eng()).sellVouchers(context.userId, data.ids));
var setVoucherStatus_createServerFn_handler = createServerRpc({
	id: "6c0edb796df698c8b8d5179f72d470232f955cc945bcc0f2853b411b76862888",
	name: "setVoucherStatus",
	filename: "src/lib/noc/api.ts"
}, (opts) => setVoucherStatus.__executeServer(opts));
var setVoucherStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	status: _enum(["new", "disabled"])
}).parse(input)).handler(setVoucherStatus_createServerFn_handler, async ({ context, data }) => (await eng()).setVoucherStatus(context.userId, data.id, data.status));
var voucherCodes_createServerFn_handler = createServerRpc({
	id: "6afed8323c847d420f8ced10edd28f0acf5466ca8d63abc30ddb35f4a566e80b",
	name: "voucherCodes",
	filename: "src/lib/noc/api.ts"
}, (opts) => voucherCodes.__executeServer(opts));
var voucherCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ ids: array(string()).max(60) }).parse(input)).handler(voucherCodes_createServerFn_handler, async ({ context, data }) => (await eng()).voucherCodes(context.userId, data.ids));
var listTemplates_createServerFn_handler = createServerRpc({
	id: "d4a777df987bde2f4865958d3a9123c4a1db594aeab9635a0208e9942547bfb4",
	name: "listTemplates",
	filename: "src/lib/noc/api.ts"
}, (opts) => listTemplates.__executeServer(opts));
var listTemplates = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTemplates_createServerFn_handler, async ({ context }) => (await eng()).listTemplates(context.userId));
var saveTemplate_createServerFn_handler = createServerRpc({
	id: "58e3f0d3f59fd752f400d41648e75b7d046b6bef44ef7eff5e150f3b92ef4675",
	name: "saveTemplate",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveTemplate.__executeServer(opts));
var saveTemplate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string().optional(),
	name: string().min(2).max(40),
	accent: string().max(20),
	showUser: boolean(),
	showPass: boolean(),
	showPrice: boolean(),
	showValidity: boolean(),
	showProfile: boolean(),
	showQr: boolean(),
	footer: string().max(80)
}).parse(input)).handler(saveTemplate_createServerFn_handler, async ({ context, data }) => (await eng()).saveTemplate(context.userId, data));
var listDevices_createServerFn_handler = createServerRpc({
	id: "e7ff8f0f6f2a2d942125724cc5888e3fef514748b968a1fb071a2ff71bea040e",
	name: "listDevices",
	filename: "src/lib/noc/api.ts"
}, (opts) => listDevices.__executeServer(opts));
var listDevices = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listDevices_createServerFn_handler, async ({ context }) => (await eng()).listDevices(context.userId));
var listTopology_createServerFn_handler = createServerRpc({
	id: "2cd46fea541f479c6256159e73e64bffaf3c5e054c653817f59f9f4d8fe749f9",
	name: "listTopology",
	filename: "src/lib/noc/api.ts"
}, (opts) => listTopology.__executeServer(opts));
var listTopology = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTopology_createServerFn_handler, async ({ context }) => (await eng()).listTopology(context.userId));
var listAlerts_createServerFn_handler = createServerRpc({
	id: "7f9cb38e3c40bbb8e8b5d60e6fa68ba05db92a739a7b0598c7e1aac20d0f24b8",
	name: "listAlerts",
	filename: "src/lib/noc/api.ts"
}, (opts) => listAlerts.__executeServer(opts));
var listAlerts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAlerts_createServerFn_handler, async ({ context }) => (await eng()).listAlerts(context.userId));
var ackAlert_createServerFn_handler = createServerRpc({
	id: "2ac47d6b8f194445a70f3f62a448b5ba866205aac245a973cbc1b8bafb16c52a",
	name: "ackAlert",
	filename: "src/lib/noc/api.ts"
}, (opts) => ackAlert.__executeServer(opts));
var ackAlert = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(ackAlert_createServerFn_handler, async ({ context, data }) => (await eng()).ackAlert(context.userId, data.id));
var listBackups_createServerFn_handler = createServerRpc({
	id: "ad7fc6d2002039fb54c33d36c3268225ab3e98e90978c14066f44a559f11a281",
	name: "listBackups",
	filename: "src/lib/noc/api.ts"
}, (opts) => listBackups.__executeServer(opts));
var listBackups = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listBackups_createServerFn_handler, async ({ context }) => (await eng()).listBackups(context.userId));
var createBackup_createServerFn_handler = createServerRpc({
	id: "138d4c4b84fc3d151f2ccfe147c8edfd30f6596246e1dccdf1b458a8ecf050df",
	name: "createBackup",
	filename: "src/lib/noc/api.ts"
}, (opts) => createBackup.__executeServer(opts));
var createBackup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ routerId: string() }).parse(input)).handler(createBackup_createServerFn_handler, async ({ context, data }) => (await eng()).createBackup(context.userId, data.routerId));
var downloadBackup_createServerFn_handler = createServerRpc({
	id: "2fe7eceda733e522a5f3037c281ea7a1b23d4e8f23fd60ae032a1522c5e0174c",
	name: "downloadBackup",
	filename: "src/lib/noc/api.ts"
}, (opts) => downloadBackup.__executeServer(opts));
var downloadBackup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(downloadBackup_createServerFn_handler, async ({ context, data }) => (await eng()).downloadBackup(context.userId, data.id));
var explainRestore_createServerFn_handler = createServerRpc({
	id: "d60f77870eb107746a2035f20b0af248c5646ca637ed31bc16abc2d4b255b7ec",
	name: "explainRestore",
	filename: "src/lib/noc/api.ts"
}, (opts) => explainRestore.__executeServer(opts));
var explainRestore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(explainRestore_createServerFn_handler, async ({ context, data }) => (await eng()).explainRestore(context.userId, data.id));
var getReports_createServerFn_handler = createServerRpc({
	id: "d8a49ac900222c5b511c1f082e501fbe75242dae128ef30d8a946ebcbdf49937",
	name: "getReports",
	filename: "src/lib/noc/api.ts"
}, (opts) => getReports.__executeServer(opts));
var getReports = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getReports_createServerFn_handler, async ({ context }) => (await eng()).getReports(context.userId));
var listAudit_createServerFn_handler = createServerRpc({
	id: "0a200a545630006c056e1a2bbcc5471d9123c1123dfe2805de27c20bb5a174db",
	name: "listAudit",
	filename: "src/lib/noc/api.ts"
}, (opts) => listAudit.__executeServer(opts));
var listAudit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAudit_createServerFn_handler, async ({ context }) => (await eng()).listAudit(context.userId));
var listScripts_createServerFn_handler = createServerRpc({
	id: "2c580850a0fce233ee13de978c94768a8c81f0fc4af93fdb8338527ee66dc5d2",
	name: "listScripts",
	filename: "src/lib/noc/api.ts"
}, (opts) => listScripts.__executeServer(opts));
var listScripts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listScripts_createServerFn_handler, async ({ context }) => (await eng()).listScripts(context.userId));
var saveScript_createServerFn_handler = createServerRpc({
	id: "93ed95c28ac6caa23278e583f1cd258f065004527c868083ebab44c50b7abc07",
	name: "saveScript",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveScript.__executeServer(opts));
var saveScript = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(60),
	body: string().min(1).max(4e3)
}).parse(input)).handler(saveScript_createServerFn_handler, async ({ context, data }) => (await eng()).saveScript(context.userId, data.name, data.body));
var runScript_createServerFn_handler = createServerRpc({
	id: "19d6c26acb587d21966887f45588dfa63fcf29a59adaeeacebe489fbbc2e12dc",
	name: "runScript",
	filename: "src/lib/noc/api.ts"
}, (opts) => runScript.__executeServer(opts));
var runScript = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	routerId: string()
}).parse(input)).handler(runScript_createServerFn_handler, async ({ context, data }) => (await eng()).runScript(context.userId, data.id, data.routerId));
var listSubscribers_createServerFn_handler = createServerRpc({
	id: "e5debe0d0c341b237dae92bb34df2e9fb7af9e6cc8b350bcb4c290ee63bea76a",
	name: "listSubscribers",
	filename: "src/lib/noc/api.ts"
}, (opts) => listSubscribers.__executeServer(opts));
var listSubscribers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listSubscribers_createServerFn_handler, async ({ context }) => (await eng()).listSubscribers(context.userId));
var renewSubscriber_createServerFn_handler = createServerRpc({
	id: "97eb6e06702c01e535a96b0e240129fc9bbe5a78b1f943e79d6ff7437b8e0ab0",
	name: "renewSubscriber",
	filename: "src/lib/noc/api.ts"
}, (opts) => renewSubscriber.__executeServer(opts));
var renewSubscriber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	days: number().int()
}).parse(input)).handler(renewSubscriber_createServerFn_handler, async ({ context, data }) => (await eng()).renewSubscriber(context.userId, data.id, data.days));
var listStaff_createServerFn_handler = createServerRpc({
	id: "691de4a37db4f26ccc827e55da17fbe1d7f5800a7e9cf5b3a3b2c4833af0b680",
	name: "listStaff",
	filename: "src/lib/noc/api.ts"
}, (opts) => listStaff.__executeServer(opts));
var listStaff = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listStaff_createServerFn_handler, async ({ context }) => (await eng()).listStaff(context.userId));
var saveStaff_createServerFn_handler = createServerRpc({
	id: "5343e96051461b4f4b11f2f29f85fb751de14617a30cf1c5df074fa7d9d6290b",
	name: "saveStaff",
	filename: "src/lib/noc/api.ts"
}, (opts) => saveStaff.__executeServer(opts));
var saveStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string().optional(),
	name: string().min(2).max(60),
	role: string().max(20),
	phone: string().max(20),
	active: boolean()
}).parse(input)).handler(saveStaff_createServerFn_handler, async ({ context, data }) => (await eng()).saveStaff(context.userId, data));
var updateWorkspace_createServerFn_handler = createServerRpc({
	id: "e4cb7f7af00fced8fd7f706afab6f289a82b5829ce123aaead82c88a74b63895",
	name: "updateWorkspace",
	filename: "src/lib/noc/api.ts"
}, (opts) => updateWorkspace.__executeServer(opts));
var updateWorkspace = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	area: string().max(80),
	logo: string().max(18e4).nullable().optional()
}).parse(input)).handler(updateWorkspace_createServerFn_handler, async ({ context, data }) => (await eng()).updateWorkspace(context.userId, data));
var setLab_createServerFn_handler = createServerRpc({
	id: "f597cdefd89864b418848b3a10b2e24ffa76b934e0045cb840d2cc0dce6522b7",
	name: "setLab",
	filename: "src/lib/noc/api.ts"
}, (opts) => setLab.__executeServer(opts));
var setLab = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ action: _enum(["clear", "restore"]) }).parse(input)).handler(setLab_createServerFn_handler, async ({ context, data }) => (await eng()).setLab(context.userId, data.action));
//#endregion
export { ackAlert_createServerFn_handler, connectRouter_createServerFn_handler, createBackup_createServerFn_handler, deleteRouter_createServerFn_handler, disconnectSession_createServerFn_handler, downloadBackup_createServerFn_handler, explainRestore_createServerFn_handler, generateVouchers_createServerFn_handler, getDashboard_createServerFn_handler, getReports_createServerFn_handler, getRouter_createServerFn_handler, getWorkspace_createServerFn_handler, listAlerts_createServerFn_handler, listAudit_createServerFn_handler, listBackups_createServerFn_handler, listDevices_createServerFn_handler, listHotspot_createServerFn_handler, listPppoe_createServerFn_handler, listProfiles_createServerFn_handler, listRouters_createServerFn_handler, listScripts_createServerFn_handler, listSessions_createServerFn_handler, listStaff_createServerFn_handler, listSubscribers_createServerFn_handler, listTemplates_createServerFn_handler, listTopology_createServerFn_handler, listVouchers_createServerFn_handler, rebootRouter_createServerFn_handler, renewSubscriber_createServerFn_handler, runScript_createServerFn_handler, saveHotspot_createServerFn_handler, savePppoe_createServerFn_handler, saveProfile_createServerFn_handler, saveRouter_createServerFn_handler, saveScript_createServerFn_handler, saveStaff_createServerFn_handler, saveTemplate_createServerFn_handler, sellVouchers_createServerFn_handler, setLab_createServerFn_handler, setUserDisabled_createServerFn_handler, setVoucherStatus_createServerFn_handler, updateWorkspace_createServerFn_handler, voucherCodes_createServerFn_handler };
