import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as listHotspot } from "./api-BC5M9OSJ.mjs";
import { t as AccountsPage } from "./accounts-BWDCOemx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hotspot-Bz7wAf8M.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountsPage, {
	title: "هوتسبوت",
	kind: "hotspot",
	loader: listHotspot
});
//#endregion
export { SplitComponent as component };
