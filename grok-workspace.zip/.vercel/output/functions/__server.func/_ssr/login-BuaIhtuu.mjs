import { S as Navigate, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useCurrentUserState, n as Splash, t as LoginScreen } from "./login-screen-BhgTzSfL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BuaIhtuu.js
var import_jsx_runtime = require_jsx_runtime();
function LoginRoute() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
}
//#endregion
export { LoginRoute as component };
