import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as listRouters, h as listBackups, o as downloadBackup, r as createBackup, s as explainRestore } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/backups-DOMVe9CJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BackupsPage() {
	const load = (0, import_react.useCallback)(() => listBackups(), []);
	const { data, error, loading, reload } = useLoad(load);
	const routers = useLoad((0, import_react.useCallback)(() => listRouters(), []));
	const [routerId, setRouterId] = (0, import_react.useState)("");
	async function make() {
		try {
			const result = await createBackup({ data: { routerId: routerId || routers.data?.routers[0]?.id || "" } });
			toast.success(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function download(id, name) {
		try {
			const file = await downloadBackup({ data: { id } });
			const blob = new Blob([file.body], { type: "application/json" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = file.filename || `${name}.json`;
			a.click();
			URL.revokeObjectURL(url);
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "ملف المختبر مشفّر",
			title: "النسخ الاحتياطي"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-[1fr_auto]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "field",
				value: routerId,
				onChange: (e) => setRouterId(e.target.value),
				children: (routers.data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: router.id,
					children: router.name
				}, router.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => void make(),
				children: "إنشاء"
			})]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data ?? []).map((backup) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: backup.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							backup.router,
							" · ",
							backup.detail,
							" · ",
							formatWhen(backup.createdAt)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [backup.downloadable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => void download(backup.id, backup.name),
							children: "تنزيل"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-danger",
							onClick: () => void explainRestore({ data: { id: backup.id } }).then((result) => toast.message(result.message)).catch((err) => toast.error(messageOf(err))),
							children: "فحص الاستعادة"
						})]
					})
				]
			}, backup.id))
		})
	] });
}
//#endregion
export { BackupsPage as component };
