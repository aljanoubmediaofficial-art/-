import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as listDevices } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, u as useLoad } from "./kit-DNv6U2L1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/devices-L5hQl7p5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DevicesPage() {
	const load = (0, import_react.useCallback)(() => listDevices(), []);
	const { data, error, loading } = useLoad(load);
	const [id, setId] = (0, import_react.useState)(null);
	const selected = (data ?? []).find((device) => device.id === id) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "ما ظهر من الجيران واللاسلكي",
			title: "الأجهزة"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "القيمة غير المتاحة تبقى فارغة. لا تُعرض صفراً كأن الجهاز أبلغ بها."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: (data ?? []).map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "panel w-full p-4 text-start",
				onClick: () => setId(device.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: device.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `badge ${statusBadge(device.status)}`,
						children: statusText(device.status)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						device.kind,
						" · ",
						device.vendor || "شركة غير معروفة",
						" · ",
						device.source
					]
				})]
			}, device.id))
		}),
		selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "panel mt-4 p-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: selected.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2",
					children: ["الموديل: ", selected.model || "غير معروف"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "ltr",
					children: [
						"IP ",
						selected.ip || "—",
						" · MAC ",
						selected.mac || "—"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["الإشارة: ", selected.signal === null ? "غير متاحة" : `${selected.signal} dBm`] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["الضجيج: ", selected.noise === null ? "غير متاح" : `${selected.noise} dBm`] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["CCQ: ", selected.ccq === null ? "غير متاح" : `${selected.ccq}٪`] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["آخر ظهور: ", formatWhen(selected.lastSeen)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["البرج: ", selected.tower || "غير مربوط"] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						"المصدر: ",
						selected.source,
						" · ",
						selected.origin === "lab" ? "سجل مختبر" : "مزامنة"
					]
				})
			]
		}) : null
	] });
}
//#endregion
export { DevicesPage as component };
