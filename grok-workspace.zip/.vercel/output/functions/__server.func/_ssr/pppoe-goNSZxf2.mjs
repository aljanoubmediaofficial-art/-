import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as listPppoe } from "./api-BC5M9OSJ.mjs";
import { t as AccountsPage } from "./accounts-BWDCOemx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pppoe-goNSZxf2.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountsPage, {
	title: "PPPoE",
	kind: "pppoe",
	loader: listPppoe
});
//#endregion
export { SplitComponent as component };
