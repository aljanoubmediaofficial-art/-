//#region node_modules/.nitro/vite/services/ssr/assets/format-HomJAAR4.js
var latn = new Intl.NumberFormat("ar-YE-u-nu-latn");
function formatInt(n) {
	if (n === null || n === void 0 || Number.isNaN(n)) return "—";
	return latn.format(n);
}
function formatMoney(n) {
	if (n === null || n === void 0) return "—";
	return `${latn.format(n)} ر.ي`;
}
function formatWhen(iso) {
	if (!iso) return "لا يوجد";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return new Intl.DateTimeFormat("ar-YE-u-nu-latn", {
		timeZone: "Asia/Aden",
		dateStyle: "medium",
		timeStyle: "short"
	}).format(d);
}
function formatBytes(n) {
	if (n === null || n === void 0) return "—";
	const units = [
		"B",
		"KB",
		"MB",
		"GB",
		"TB"
	];
	let v = n;
	let i = 0;
	while (v >= 1024 && i < units.length - 1) {
		v /= 1024;
		i += 1;
	}
	const digits = i === 0 ? 0 : 1;
	return `${v.toFixed(digits)} ${units[i]}`;
}
function adenDay(date = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: "Asia/Aden",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(date);
}
function addDays(day, days) {
	const [y, m, d] = day.split("-").map(Number);
	const dt = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
	dt.setUTCDate(dt.getUTCDate() + days);
	return dt.toISOString().slice(0, 10);
}
//#endregion
export { formatMoney as a, formatInt as i, adenDay as n, formatWhen as o, formatBytes as r, addDays as t };
