import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as setJobStatus, s as listJobs, v as saveJob } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/maintenance-Dk9dAaQe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NEXT = [
	"open",
	"assigned",
	"done",
	"closed"
];
function MaintenancePage() {
	const load = (0, import_react.useCallback)(() => listJobs(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		title: "",
		site: "",
		tower: "",
		assignee: "",
		notes: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			await saveJob({ data: form });
			toast.success("فُتح البلاغ");
			setForm({
				title: "",
				site: "",
				tower: "",
				assignee: "",
				notes: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function move(id, status) {
		try {
			await setJobStatus({ data: {
				id,
				status
			} });
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "البلاغ حتى الإغلاق",
			title: "الصيانة والفنيون"
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "عنوان العطل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						required: true,
						value: form.title,
						onChange: (e) => setForm({
							...form,
							title: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الموقع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.site,
						onChange: (e) => setForm({
							...form,
							site: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "البرج أو الانتينا",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.tower,
						onChange: (e) => setForm({
							...form,
							tower: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الفني",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.assignee,
						onChange: (e) => setForm({
							...form,
							assignee: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-20 sm:col-span-2",
						value: form.notes,
						onChange: (e) => setForm({
							...form,
							notes: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary sm:col-span-2",
					type: "submit",
					children: "فتح بلاغ"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data ?? []).map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: job.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(job.status)}`,
							children: statusText(job.status)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							job.site || "بدون موقع",
							" · ",
							job.tower || "بدون برج",
							" · ",
							job.assignee || "غير معيّن"
						]
					}),
					job.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: job.notes
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: formatWhen(job.createdAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: NEXT.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							disabled: job.status === status,
							onClick: () => void move(job.id, status),
							children: statusText(status)
						}, status))
					})
				]
			}, job.id))
		})
	] });
}
//#endregion
export { MaintenancePage as component };
