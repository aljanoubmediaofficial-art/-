import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney, o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { b as saveReseller, k as walletMove, m as reverseWallet, u as listResellers } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resellers-NjIRNUgq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIND = {
	topup: "شحن",
	withdraw: "سحب",
	sale: "بيع",
	commission: "عمولة",
	reverse: "عكس"
};
function ResellersPage() {
	const load = (0, import_react.useCallback)(() => listResellers(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		commissionPct: 10,
		notes: ""
	});
	const [move, setMove] = (0, import_react.useState)({
		resellerId: "",
		kind: "topup",
		amount: 1e3,
		note: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			await saveReseller({ data: form });
			toast.success("أُضيف البائع");
			setForm({
				name: "",
				phone: "",
				commissionPct: 10,
				notes: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function post(event) {
		event.preventDefault();
		try {
			await walletMove({ data: move });
			toast.success("سُجّل القيد");
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function undo(id) {
		try {
			await reverseWallet({ data: { id } });
			toast.success("عُكس القيد بقيد جديد");
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "دفتر لا يُعدَّل بصمت",
			title: "البائعون والمحافظ"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "الشحن يزيد الرصيد، والبيع والسحب ينقصانه. التصحيح يتم بعكس القيد لا بحذفه."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel grid gap-3 p-4",
				onSubmit: (e) => void add(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "بائع جديد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							required: true,
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الهاتف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.phone,
							onChange: (e) => setForm({
								...form,
								phone: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نسبة العمولة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							min: 0,
							max: 80,
							value: form.commissionPct,
							onChange: (e) => setForm({
								...form,
								commissionPct: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.notes,
							onChange: (e) => setForm({
								...form,
								notes: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "حفظ البائع"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel grid gap-3 p-4",
				onSubmit: (e) => void post(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "قيد محفظة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "البائع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							required: true,
							value: move.resellerId,
							onChange: (e) => setMove({
								...move,
								resellerId: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر"
							}), (data?.resellers ?? []).map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: person.id,
								children: person.name
							}, person.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "النوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: move.kind,
							onChange: (e) => setMove({
								...move,
								kind: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "topup",
									children: "شحن رصيد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "sale",
									children: "خصم بيع"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "commission",
									children: "عمولة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "withdraw",
									children: "سحب / تسوية"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المبلغ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							min: 1,
							value: move.amount,
							onChange: (e) => setMove({
								...move,
								amount: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بيان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: move.note,
							onChange: (e) => setMove({
								...move,
								note: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "تسجيل القيد"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data?.resellers ?? []).map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: person.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${person.active ? "badge-ok" : "badge-danger"}`,
							children: person.active ? "نشط" : "موقوف"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							person.phone || "بدون هاتف",
							" · عمولة ",
							person.commissionPct,
							"٪"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-lg font-semibold tabular-nums",
						children: formatMoney(person.balance)
					}),
					person.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: person.notes
					}) : null
				]
			}, person.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 mt-6 font-semibold",
			children: "آخر القيود"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: (data?.entries ?? []).map((entry) => {
				const owner = data?.resellers.find((person) => person.id === entry.resellerId)?.name ?? "بائع";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							owner,
							" · ",
							KIND[entry.kind] ?? entry.kind
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							entry.note || "بدون بيان",
							" · ",
							formatWhen(entry.createdAt)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatMoney(entry.amount)
						}), entry.kind !== "reverse" && !data?.entries.some((item) => item.reversesId === entry.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost min-h-10",
							onClick: () => void undo(entry.id),
							children: "عكس"
						}) : null]
					})]
				}, entry.id);
			})
		})
	] });
}
//#endregion
export { ResellersPage as component };
