import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen, r as formatBytes } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as listSessions, a as disconnectSession } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, l as statusText, s as messageOf, t as Empty, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/active-Ckqmp6rd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ActivePage() {
	const load = (0, import_react.useCallback)(() => listSessions(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [q, setQ] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return (data ?? []).filter((row) => {
			if (kind && row.kind !== kind) return false;
			if (!query) return true;
			return [
				row.username,
				row.ip,
				row.mac,
				row.router
			].join(" ").toLowerCase().includes(query);
		});
	}, [
		data,
		q,
		kind
	]);
	async function cut(id) {
		setPending(id);
		try {
			const result = await disconnectSession({ data: { id } });
			toast.success(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setPending("");
		}
	}
	function exportCsv() {
		const header = "user,ip,mac,kind,source,router,tower\n";
		const body = rows.map((row) => [
			row.username,
			row.ip,
			row.mac,
			row.kind,
			row.source,
			row.router,
			row.tower
		].join(",")).join("\n");
		const blob = new Blob([`\uFEFF${header}${body}`], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "sessions.csv";
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "جلسات الدخول فقط",
			title: "المتصلون",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost",
				onClick: exportCsv,
				disabled: !rows.length,
				children: "تصدير"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "القائمة لجلسات الهوتسبوت وPPPoE. عقد DHCP وARP لا تُحسب مستخدماً نشطاً ولا تظهر هنا."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-[1fr_10rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "اسم أو IP أو MAC",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "field",
				value: kind,
				onChange: (e) => setKind(e.target.value),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "الكل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "hotspot",
						children: "هوتسبوت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pppoe",
						children: "PPPoE"
					})
				]
			})]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		!loading && rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "لا جلسات",
			body: "لا توجد جلسة دخول مطابقة. زامن راوتراً حقيقياً أو ابقِ المختبر ظاهراً."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: row.username
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							statusText(row.kind),
							" · ",
							row.source === "authenticated" ? "جلسة مصادقة" : row.source,
							" · ",
							row.router,
							row.mode === "lab" ? " · مختبر" : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger",
						disabled: pending === row.id,
						onClick: () => void cut(row.id),
						children: "فصل"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-3 grid grid-cols-2 gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "IP"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "ltr tabular-nums",
							children: row.ip || "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "MAC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "ltr tabular-nums",
							children: row.mac || "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "البرج"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: row.tower || "غير مربوط" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "الانتينا"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: row.antenna || "غير محدد" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "البداية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatWhen(row.startedAt) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "الاستهلاك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "tabular-nums",
							children: formatBytes(row.bytesIn + row.bytesOut)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "السرعة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: row.down && row.up ? `${row.down} / ${row.up}` : "غير مقاسة" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "البروفايل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: row.profile || "—" })] })
					]
				})]
			}, row.id))
		})
	] });
}
//#endregion
export { ActivePage as component };
