import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { k as renewSubscriber, w as listSubscribers } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as saveSubscriber, l as listPayments, p as recordPayment } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subscribers-BkEpAeDq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SubscribersPage() {
	const load = (0, import_react.useCallback)(async () => {
		const [people, payments] = await Promise.all([listSubscribers(), listPayments()]);
		return {
			people,
			payments
		};
	}, []);
	const { data, error, loading, reload } = useLoad(load);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [payFor, setPayFor] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)(3e3);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		address: "",
		tower: "",
		antenna: "",
		service: "PPPoE",
		account: "",
		plan: "",
		endsOn: ""
	});
	async function renew(id, days) {
		try {
			const result = await renewSubscriber({ data: {
				id,
				days
			} });
			toast.success(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function add(event) {
		event.preventDefault();
		try {
			const result = await saveSubscriber({ data: form });
			toast.success(`أُضيف العميل ${result.code}`);
			setOpen(false);
			setForm({
				name: "",
				phone: "",
				address: "",
				tower: "",
				antenna: "",
				service: "PPPoE",
				account: "",
				plan: "",
				endsOn: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function pay(event) {
		event.preventDefault();
		if (!payFor) return;
		try {
			const result = await recordPayment({ data: {
				subscriberId: payFor,
				amount,
				note: "دفعة اشتراك"
			} });
			toast.success(result.message);
			setPayFor(null);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "اشتراك الخدمة المستمرة",
			title: "العملاء",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setOpen((v) => !v),
				children: open ? "إغلاق" : "عميل جديد"
			})
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel mb-4 grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الاسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						required: true,
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الهاتف",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.phone,
						onChange: (e) => setForm({
							...form,
							phone: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "العنوان",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.address,
						onChange: (e) => setForm({
							...form,
							address: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الخدمة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: form.service,
						onChange: (e) => setForm({
							...form,
							service: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "PPPoE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hotspot" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "البرج",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.tower,
						onChange: (e) => setForm({
							...form,
							tower: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الانتينا",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.antenna,
						onChange: (e) => setForm({
							...form,
							antenna: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الحساب",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						value: form.account,
						onChange: (e) => setForm({
							...form,
							account: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الباقة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.plan,
						onChange: (e) => setForm({
							...form,
							plan: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ينتهي",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						required: true,
						placeholder: "2026-12-01",
						value: form.endsOn,
						onChange: (e) => setForm({
							...form,
							endsOn: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary sm:col-span-2",
					type: "submit",
					children: "حفظ العميل"
				})
			]
		}) : null,
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data?.people ?? []).map((person) => {
				const paid = (data?.payments ?? []).filter((row) => row.subscriberId === person.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold",
								children: person.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `badge ${statusBadge(person.status)}`,
								children: statusText(person.status)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								person.code,
								" · ",
								person.phone,
								" · ",
								person.address
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								person.tower,
								" · ",
								person.antenna,
								" · ",
								person.plan,
								" · ",
								person.account
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [
								"من ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ltr",
									children: person.startedOn
								}),
								" إلى ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ltr",
									children: person.endsOn
								})
							]
						}),
						paid.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								"آخر دفعة ",
								formatMoney(paid[0]?.amount),
								" في ",
								paid[0]?.day
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [[
								30,
								7,
								1
							].map((days) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => void renew(person.id, days),
								children: days === 30 ? "شهر" : days === 7 ? "أسبوع" : "يوم"
							}, days)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => setPayFor(payFor === person.id ? null : person.id),
								children: "دفعة"
							})]
						}),
						payFor === person.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-3 flex flex-wrap items-end gap-2",
							onSubmit: (e) => void pay(e),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "المبلغ",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field ltr",
									type: "number",
									min: 1,
									value: amount,
									onChange: (e) => setAmount(Number(e.target.value))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								children: "تسجيل"
							})]
						}) : null
					]
				}, person.id);
			})
		})
	] });
}
//#endregion
export { SubscribersPage as component };
