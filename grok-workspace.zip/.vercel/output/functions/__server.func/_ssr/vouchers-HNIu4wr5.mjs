import { o as __toESM } from "../_runtime.mjs";
import { a as formatMoney } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as listVouchers, R as sellVouchers, T as listTemplates, U as voucherCodes, V as setVoucherStatus, b as listRouters, c as generateVouchers, y as listProfiles } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, n as Field, r as Modal, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vouchers-HNIu4wr5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VouchersPage() {
	const load = (0, import_react.useCallback)(() => listVouchers(), []);
	const { data, error, loading, reload } = useLoad(load);
	const routers = useLoad((0, import_react.useCallback)(() => listRouters(), []));
	const profiles = useLoad((0, import_react.useCallback)(() => listProfiles(), []));
	const templates = useLoad((0, import_react.useCallback)(() => listTemplates(), []));
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [reveal, setReveal] = (0, import_react.useState)(false);
	const [sheet, setSheet] = (0, import_react.useState)([]);
	const [form, setForm] = (0, import_react.useState)({
		routerId: "",
		profile: "",
		price: 200,
		cardType: "same",
		count: 10,
		length: 5,
		charset: "digits",
		prefix: "ZN",
		validity: "١ يوم",
		recordSale: false
	});
	const template = templates.data?.[0];
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return (data?.vouchers ?? []).filter((row) => !query || row.username.toLowerCase().includes(query) || row.profile.toLowerCase().includes(query));
	}, [data, q]);
	async function generate(event) {
		event.preventDefault();
		try {
			const result = await generateVouchers({ data: {
				...form,
				routerId: form.routerId || routers.data?.routers[0]?.id || "",
				price: Number(form.price),
				count: Number(form.count),
				length: Number(form.length)
			} });
			toast.success(result.message);
			setOpen(false);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function sell() {
		try {
			const result = await sellVouchers({ data: { ids: picked } });
			toast.success(result.message);
			setPicked([]);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function printCards() {
		const cards = rows.filter((row) => picked.includes(row.id));
		const target = cards.length ? cards : rows.slice(0, 12);
		try {
			const codes = template?.showQr ? await voucherCodes({ data: { ids: target.map((row) => row.id) } }) : [];
			setSheet(target.map((row) => ({
				username: row.username,
				password: row.password,
				price: row.price,
				validity: row.validity,
				profile: row.profile,
				qr: codes.find((code) => code.id === row.id)?.qr
			})));
			setTimeout(() => window.print(), 200);
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	function csv() {
		const header = reveal ? "user,password,profile,price,status\n" : "user,profile,price,status\n";
		const body = rows.map((row) => (reveal ? [
			row.username,
			row.password,
			row.profile,
			row.price,
			row.status
		] : [
			row.username,
			row.profile,
			row.price,
			row.status
		]).join(",")).join("\n");
		const blob = new Blob([`\uFEFF${header}${body}`], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "vouchers.csv";
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "التوليد على الراوتر إن كان حقيقياً",
			title: "الكروت",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setOpen(true),
				children: "توليد"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field min-w-0 flex-1",
					placeholder: "بحث",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: () => void sell(),
					disabled: !picked.length,
					children: "تسجيل بيع"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: () => void printCards(),
					children: "طباعة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: csv,
					children: "تصدير"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mb-4 flex items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: reveal,
				onChange: (e) => setReveal(e.target.checked)
			}), "إظهار كلمات المرور في الشاشة والتصدير"]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 space-y-2",
			children: (data?.batches ?? []).slice(0, 4).map((batch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"دفعة ",
					batch.prefix || "بدون بادئة",
					" · ",
					batch.qty,
					" · ",
					batch.profile,
					" · ",
					batch.origin === "lab" ? "مختبر" : "حقيقي"
				]
			}, batch.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "panel flex items-center gap-3 p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: picked.includes(row.id),
						onChange: (e) => setPicked(e.target.checked ? [...picked, row.id] : picked.filter((id) => id !== row.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold ltr text-start",
								children: row.username
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted",
								children: [
									row.profile,
									" · ",
									formatMoney(row.price),
									" · ",
									row.status === "new" ? "جديد" : row.status === "sold" ? "مباع" : "معطّل",
									" · ",
									row.origin === "lab" ? "مختبر" : "حقيقي"
								]
							}),
							reveal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ltr text-xs",
								children: row.password
							}) : null
						]
					}),
					row.origin === "lab" && row.status !== "sold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost min-h-10",
						onClick: (e) => {
							e.preventDefault();
							setVoucherStatus({ data: {
								id: row.id,
								status: row.status === "disabled" ? "new" : "disabled"
							} }).then(() => reload()).catch((err) => toast.error(messageOf(err)));
						},
						children: row.status === "disabled" ? "إعادة" : "تعطيل"
					}) : null
				]
			}, row.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: "توليد دفعة",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (e) => void generate(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الراوتر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: form.routerId,
							onChange: (e) => setForm({
								...form,
								routerId: e.target.value
							}),
							children: (routers.data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: router.id,
								children: router.name
							}, router.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "البروفايل",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							list: "profile-names",
							value: form.profile,
							onChange: (e) => setForm({
								...form,
								profile: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
							id: "profile-names",
							children: (profiles.data ?? []).filter((profile) => profile.kind === "hotspot").map((profile) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: profile.name }, profile.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "النوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: form.cardType,
							onChange: (e) => setForm({
								...form,
								cardType: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "user",
									children: "اسم فقط"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "same",
									children: "اسم وكلمة متطابقان"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "different",
									children: "اسم وكلمة مختلفان"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "العدد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							min: 1,
							max: 100,
							value: form.count,
							onChange: (e) => setForm({
								...form,
								count: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "طول الرمز",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							min: 4,
							max: 10,
							value: form.length,
							onChange: (e) => setForm({
								...form,
								length: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الأحرف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: form.charset,
							onChange: (e) => setForm({
								...form,
								charset: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "digits",
									children: "أرقام"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "letters",
									children: "حروف"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "mixed",
									children: "مختلط"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بادئة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: form.prefix,
							onChange: (e) => setForm({
								...form,
								prefix: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "السعر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							type: "number",
							value: form.price,
							onChange: (e) => setForm({
								...form,
								price: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الصلاحية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: form.validity,
							onChange: (e) => setForm({
								...form,
								validity: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: form.recordSale,
							onChange: (e) => setForm({
								...form,
								recordSale: e.target.checked
							})
						}), "تسجيل القيمة كمبيعات"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "توليد"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "print-sheet",
			className: "mt-6 hidden print:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3",
				children: sheet.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "border border-line p-3 text-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "الزهر نت"
						}),
						template?.showUser !== false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ltr",
							children: card.username
						}) : null,
						template?.showPass !== false && card.password !== card.username ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ltr",
							children: card.password
						}) : null,
						template?.showPrice !== false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatMoney(card.price) }) : null,
						template?.showValidity !== false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: card.validity }) : null,
						template?.showProfile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: card.profile }) : null,
						card.qr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: card.qr,
							alt: "",
							className: "mt-2 h-16 w-16"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: template?.footer
						})
					]
				}, card.username))
			})
		})
	] });
}
//#endregion
export { VouchersPage as component };
