import { o as __toESM } from "../_runtime.mjs";
import { i as formatInt } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageHead, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as setUmDisabled, T as saveUm, f as listUm } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/userman-C4mqRSc8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserManagerPage() {
	const load = (0, import_react.useCallback)(() => listUm(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [form, setForm] = (0, import_react.useState)({
		username: "",
		profile: "",
		credit: 0,
		limitation: "",
		note: ""
	});
	async function add(event) {
		event.preventDefault();
		try {
			const result = await saveUm({ data: form });
			toast.success(result.message);
			setForm({
				username: "",
				profile: "",
				credit: 0,
				limitation: "",
				note: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function toggle(id, disabled) {
		try {
			await setUmDisabled({ data: {
				id,
				disabled
			} });
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "سجل المنصة وليس جلسة الراوتر",
			title: "يوزر منجر"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "الحسابات هنا دفتر تشغيلي. لا تُنشأ على الراوتر حتى يتوفر User Manager متوافق ويُزامَن صراحة."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: (e) => void add(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "المستخدم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						required: true,
						value: form.username,
						onChange: (e) => setForm({
							...form,
							username: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "البروفايل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.profile,
						onChange: (e) => setForm({
							...form,
							profile: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الرصيد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field ltr",
						type: "number",
						min: 0,
						value: form.credit,
						onChange: (e) => setForm({
							...form,
							credit: Number(e.target.value)
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الحد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.limitation,
						onChange: (e) => setForm({
							...form,
							limitation: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ملاحظة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field sm:col-span-2",
						value: form.note,
						onChange: (e) => setForm({
							...form,
							note: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary sm:col-span-2",
					type: "submit",
					children: "حفظ الحساب"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data ?? []).map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel flex flex-wrap items-center justify-between gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: user.username
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							user.profile || "بدون بروفايل",
							" · رصيد ",
							formatInt(user.credit),
							" · ",
							user.limitation || "بدون حد"
						]
					}),
					user.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: user.note
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: () => void toggle(user.id, !user.disabled),
					children: user.disabled ? "تفعيل" : "تعطيل"
				})]
			}, user.id))
		})
	] });
}
//#endregion
export { UserManagerPage as component };
