import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as getWorkspace } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, u as useLoad } from "./kit-DNv6U2L1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subscription-CNstycpO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLANS = {
	trial: "تجريبية",
	month: "شهرية",
	quarter: "ربع سنوية",
	half: "نصف سنوية",
	year: "سنوية",
	custom: "مخصصة"
};
function SubscriptionPage() {
	const load = (0, import_react.useCallback)(() => getWorkspace(), []);
	const { data, error, loading } = useLoad(load);
	const license = data?.license;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "ترخيص هذه الشبكة",
			title: "الاشتراك"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "هذه شاشة ترخيص الحساب الحالي. لوحة كل عملاء المنصة لا تُعرض هنا حتى لا تختلط بيانات الشبكات."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		license ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "panel space-y-2 p-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["الباقة: ", PLANS[license.plan] ?? license.plan] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["الحالة: ", license.status === "active" ? "فعّالة" : "موقوفة"] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["البداية: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ltr",
					children: license.startedOn
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["تنتهي التجربة / التجديد: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ltr",
					children: license.renewsOn
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"الراوترات الحقيقية: ",
					license.liveRouters,
					" من ",
					license.routerLimit
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["المستخدمون الإداريون حتى: ", license.staffLimit] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"مساحة النسخ: ",
					license.backupMb,
					" م.ب"
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "عند تعذر التحقق لا تُغلق شاشة المراقبة. إيقاف الباقة يوقف أوامر التعديل فقط."
				})
			]
		}) : null
	] });
}
//#endregion
export { SubscriptionPage as component };
