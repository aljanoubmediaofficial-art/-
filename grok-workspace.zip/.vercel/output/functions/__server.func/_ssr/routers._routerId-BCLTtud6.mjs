import { o as __toESM } from "../_runtime.mjs";
import { i as formatInt, o as formatWhen, r as formatBytes } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as rebootRouter, d as getRouter, i as deleteRouter, n as connectRouter } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$1 } from "./router-CKHNjyjL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routers._routerId-BCLTtud6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RouterPage() {
	const { routerId } = Route$1.useParams();
	const load = (0, import_react.useCallback)(() => getRouter({ data: { id: routerId } }), [routerId]);
	const { data, error, loading, reload } = useLoad(load);
	const [trust, setTrust] = (0, import_react.useState)("");
	const [confirmName, setConfirmName] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function probe(fingerprint) {
		setPending(true);
		try {
			const result = await connectRouter({ data: {
				id: routerId,
				trust: fingerprint
			} });
			if (result.needsTrust) {
				setTrust(result.fingerprint);
				toast.message("طابق البصمة قبل المتابعة");
			} else if (result.ok) toast.success(result.message);
			else toast.error(result.message);
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setPending(false);
		}
	}
	async function reboot() {
		setPending(true);
		try {
			const result = await rebootRouter({ data: {
				id: routerId,
				confirmName
			} });
			toast.success(result.message);
			setConfirmName("");
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setPending(false);
		}
	}
	async function remove() {
		if (!window.confirm("حذف ربط هذا الراوتر من المنصة؟")) return;
		try {
			await deleteRouter({ data: { id: routerId } });
			window.location.href = "/routers";
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	if (loading && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "جاري التحميل…"
	});
	if (error && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-danger",
		children: error
	});
	if (!data) return null;
	const router = data.router;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: router.mode === "lab" ? "مختبر" : "راوتر حقيقي",
			title: router.name,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `badge ${statusBadge(router.status)}`,
				children: statusText(router.status)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-3 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "الهوية",
						v: router.identity ?? "لم تُقرأ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "الموديل",
						v: router.model ?? "لم يُقرأ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "اللوحة",
						v: router.board ?? "لم تُقرأ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "RouterOS المقروء",
						v: router.rosVersion ?? "لم يُقرأ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "تلميح المالك",
						v: router.rosHint || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "التشغيل",
						v: router.uptime ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "المعالج",
						v: router.cpu === null ? "غير متاح" : `${formatInt(router.cpu)}٪`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "الذاكرة",
						v: router.ram === null ? "غير متاحة" : `${formatInt(router.ram)}٪`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "التخزين",
						v: router.storage === null ? "غير متاح" : `${formatInt(router.storage)}٪`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "الحرارة",
						v: router.temperature ?? "غير مدعومة على هذه القراءة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "الجهد",
						v: router.voltage ?? "غير مدعوم على هذه القراءة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "آخر ظهور",
						v: formatWhen(router.lastSeen)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "السرعة اللحظية",
						v: router.downloadMbps === null ? "حدّد منفذ الإنترنت ثم زامن" : `${formatInt(router.downloadMbps)} / ${formatInt(router.uploadMbps)} Mbps`
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: router.host ? `${router.connType} · ${router.host}:${router.port}` : "بدون عنوان اتصال"
					}),
					router.lastError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: router.lastError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary w-full",
						disabled: pending,
						onClick: () => void probe(),
						children: "مزامنة / فحص"
					}),
					trust ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "بصمة SHA-256. لم تُرسل كلمة المرور بعد."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ltr mt-2 break-all font-mono text-xs",
								children: trust
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-primary mt-3 w-full",
								disabled: pending,
								onClick: () => void probe(trust),
								children: "أثق بهذه البصمة وأكمل"
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اكتب اسم الراوتر لإعادة التشغيل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: confirmName,
							onChange: (e) => setConfirmName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger w-full",
						disabled: pending,
						onClick: () => void reboot(),
						children: "إعادة التشغيل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost w-full",
						onClick: () => void remove(),
						children: "حذف الربط"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-semibold",
					children: "الواجهات"
				}),
				data.interfaces.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "لا واجهات مقروءة."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: data.interfaces.map((iface) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel flex items-center justify-between px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ltr",
							children: iface.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								iface.kind,
								" · ",
								iface.running ? "يعمل" : "متوقف",
								" · ",
								iface.comment || iface.origin
							]
						})]
					}, iface.name))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-semibold",
				children: "جلسات هذا الراوتر"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: data.sessions.map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: session.username
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							statusText(session.kind),
							" · ",
							session.ip,
							" · ",
							formatBytes(session.bytesIn + session.bytesOut)
						]
					})]
				}, session.id))
			})]
		})
	] });
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 border-b border-line py-2 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-end tabular-nums",
			children: v
		})]
	});
}
//#endregion
export { RouterPage as component };
