import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D6nHeuCK.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { cn as _enum, dn as boolean, gn as object, hn as number, yn as string } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-BSHAfIB0.js
var listResellers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7ed330294e3c2d7ffdcc2a7ba1913fa3bdc1ca7513f7b0ef019185c3164161b7"));
var saveReseller = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(60),
	phone: string().max(20),
	commissionPct: number().int().min(0).max(80),
	notes: string().max(200)
}).parse(input)).handler(createSsrRpc("29936b3698be976abfab7f7f5b00d6cc062b2decf93ad34975eb3aaf6aa972a7"));
var walletMove = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	resellerId: string(),
	kind: _enum([
		"topup",
		"withdraw",
		"sale",
		"commission"
	]),
	amount: number().int().min(1).max(5e6),
	note: string().max(160)
}).parse(input)).handler(createSsrRpc("f70629bd31c63f8a5e7e709c76f0332674b103e80463a31b04e8f964e5f40308"));
var reverseWallet = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("decbf054cd0495969fd50a7cc4c13c792539641e13db717a5c4f7df9ec9a4830"));
var listUm = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("17f131fdd3946cbbeaa77d8d2f903b958813b926d1d27cd277babbcc22c42dc8"));
var saveUm = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	username: string().min(2).max(32),
	profile: string().max(64),
	credit: number().int().min(0).max(1e6),
	limitation: string().max(80),
	note: string().max(160)
}).parse(input)).handler(createSsrRpc("402ae73f19cd73d31baa1367adcef77c6f7d31e15779ec730bd4d4a69b119b08"));
var setUmDisabled = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	disabled: boolean()
}).parse(input)).handler(createSsrRpc("7e283c69d1026527ae79a3871013780f9d42b8c1716b5c461f44d4bd8c8ec1ff"));
var listJobs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4fc66cf311a2f82562ecc89c114eebae20be9fd01547c02d9a66e3cdeb04a61b"));
var saveJob = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	title: string().min(2).max(80),
	site: string().max(80),
	tower: string().max(80),
	assignee: string().max(60),
	notes: string().max(400)
}).parse(input)).handler(createSsrRpc("7adfaffc207e29ea9268f65c185ba1fcc5c9430d6e7acc2d69c0bf24b2920191"));
var setJobStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	id: string(),
	status: _enum([
		"open",
		"assigned",
		"done",
		"closed"
	])
}).parse(input)).handler(createSsrRpc("6b241a7fe0b5f0e27b4716034b318911795706bf3fa4482002c9f8452499b560"));
var listInventory = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("07374168c8bf5f98fa806e4c612a8623d78071c96365594ce9734c9e832e3401"));
var saveInventory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	kind: string().max(20),
	serial: string().max(40),
	model: string().max(40),
	qty: number().int().min(1).max(1e4),
	buyPrice: number().int().min(0).max(5e7),
	location: string().max(80),
	state: string().max(20),
	warranty: string().max(40),
	boughtOn: string().max(20)
}).parse(input)).handler(createSsrRpc("cdb4d0cb2bccf2cb38e1fe4a3d350ed51e1d5fdd0218233e478693c4cb3b01cb"));
var listChannels = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1a98656b20cd39e8fd353df692fa017d982bf2eb3ed355f43cfd4dedcf8559b8"));
var saveChannels = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	token: string().max(120),
	chat: string().max(40),
	waPhone: string().max(20),
	waNote: string().max(400)
}).parse(input)).handler(createSsrRpc("aaa5ac7d026bdf5ddd3831ddc89b531514f4c6eadf9543a36dcceb80d9233a64"));
var testTelegram = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ send: boolean() }).parse(input)).handler(createSsrRpc("2f613c2c7826754c3bd0fda62f5cf743d155046e5f80d269298b6b4f704e103b"));
var holdWhatsapp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	to: string().min(6).max(20),
	body: string().min(2).max(400)
}).parse(input)).handler(createSsrRpc("ba1ede3e4d84a9bbbe5e80d2b3e34fb295be678ac4730593f7f025bbcbe93ce5"));
var listTickets = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("21536f59813c743f45b37e1a46464a700dbca9e01c5e973e6521c4137f5bb46f"));
var saveTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	subject: string().min(2).max(80),
	body: string().min(2).max(800)
}).parse(input)).handler(createSsrRpc("9d63732ab407480cc475d2ebe8817339197cca4aa53c4d66ca04afcd6ea5f175"));
var closeTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ id: string() }).parse(input)).handler(createSsrRpc("e3086338241cfc12ba4cd70daa9cd4eef74f946266c7e47da5200dbf67323716"));
var listNetwork = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8a6313c95b3590fedd164fe8f2a531bc7f198c8e4577a2e730dd0a970917b4af"));
var saveNetNote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	area: string().max(20),
	name: string().min(2).max(80),
	detail: string().max(400)
}).parse(input)).handler(createSsrRpc("0c5a4739ced788fbb37464a3abc49a534bc66bff8ac9fec2b16846ed184c3cc8"));
var diagnose = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3384068c6c5119834b8a43d2dea1a8f3ac69e64353b268049215d39b7a92d09f"));
var assist = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ question: string().max(300) }).parse(input)).handler(createSsrRpc("bc0743f38d858e24ce6970bec4d69e4da6bd9c6b9c3793d9f1f082bae29154d0"));
var saveSubscriber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	phone: string().max(20),
	address: string().max(80),
	tower: string().max(80),
	antenna: string().max(80),
	service: string().max(20),
	account: string().max(40),
	plan: string().max(40),
	endsOn: string().max(20)
}).parse(input)).handler(createSsrRpc("6624b7994486c22e4f8e5501ee53525fd6147318b2cfb701f75ad62541bf55c3"));
var recordPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	subscriberId: string(),
	amount: number().int().min(1).max(5e6),
	note: string().max(160)
}).parse(input)).handler(createSsrRpc("b8a58f2f460bce36fbf55695396807eb27c14b14e702513c12c9a43a7ecbf491"));
var listPayments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d3fb2ed759370a652dbc95b2e7624b8be3b0bcda785a751844036687e7004ff3"));
var saveTower = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	site: string().max(80),
	lat: string().max(20),
	lng: string().max(20),
	routerId: string().max(80),
	power: string().max(80),
	notes: string().max(200)
}).parse(input)).handler(createSsrRpc("06529aa178bfe3f32d211b6129a2b06956cbcbb12e84e0ca000a86f41862ab76"));
var saveAntenna = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	towerId: string(),
	name: string().min(2).max(80),
	model: string().max(40),
	ip: string().max(40),
	frequency: string().max(20),
	channel: string().max(20)
}).parse(input)).handler(createSsrRpc("bf84217e1723fe6dffd1c8649377670129b846aad529744556237edc7b114691"));
var saveSource = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({
	name: string().min(2).max(80),
	kind: string().max(20),
	iface: string().max(40),
	contracted: string().max(40),
	cost: number().int().min(0).max(5e7).nullable(),
	routerId: string().max(80),
	note: string().max(200)
}).parse(input)).handler(createSsrRpc("9fc0e15370e35b1f47c8d02a61fe051f47b2cae6892076cb3ed5bb909a549e35"));
//#endregion
export { saveTicket as C, setUmDisabled as D, setJobStatus as E, testTelegram as O, saveSubscriber as S, saveUm as T, saveInventory as _, listChannels as a, saveReseller as b, listNetwork as c, listTickets as d, listUm as f, saveChannels as g, saveAntenna as h, holdWhatsapp as i, walletMove as k, listPayments as l, reverseWallet as m, closeTicket as n, listInventory as o, recordPayment as p, diagnose as r, listJobs as s, assist as t, listResellers as u, saveJob as v, saveTower as w, saveSource as x, saveNetNote as y };
