import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as listTopology } from "./api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, n as Field, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as saveAntenna, w as saveTower } from "./desk-BSHAfIB0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/towers-i8SfGvOG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TowersPage() {
	const load = (0, import_react.useCallback)(() => listTopology(), []);
	const { data, error, loading, reload } = useLoad(load);
	const [tower, setTower] = (0, import_react.useState)({
		name: "",
		site: "",
		lat: "",
		lng: "",
		routerId: "",
		power: "",
		notes: ""
	});
	const [antenna, setAntenna] = (0, import_react.useState)({
		towerId: "",
		name: "",
		model: "",
		ip: "",
		frequency: "",
		channel: ""
	});
	const nameOf = (kind, id) => {
		if (!data) return id;
		if (kind === "router") return data.routers.find((item) => item.id === id)?.name ?? id;
		if (kind === "tower") return data.towers.find((item) => item.id === id)?.name ?? id;
		if (kind === "antenna") return data.antennas.find((item) => item.id === id)?.name ?? id;
		if (kind === "source") return data.sources.find((item) => item.id === id)?.name ?? id;
		return id;
	};
	async function addTower(event) {
		event.preventDefault();
		try {
			await saveTower({ data: tower });
			toast.success("أُضيف البرج");
			setTower({
				name: "",
				site: "",
				lat: "",
				lng: "",
				routerId: "",
				power: "",
				notes: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	async function addAntenna(event) {
		event.preventDefault();
		try {
			await saveAntenna({ data: antenna });
			toast.success("أُضيفت الانتينا ووُبطت بالبرج");
			setAntenna({
				...antenna,
				name: ""
			});
			await reload();
		} catch (err) {
			toast.error(messageOf(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "علاقات مسجّلة فقط",
			title: "الأبراج والانتينات"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "هذا مخطط ربط منطقي. الإحداثيات النصية ليست خريطة، ولا يُرسم رابط لم يُسجَّل."
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel grid gap-3 p-4",
				onSubmit: (e) => void addTower(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "برج جديد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							required: true,
							value: tower.name,
							onChange: (e) => setTower({
								...tower,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الموقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: tower.site,
							onChange: (e) => setTower({
								...tower,
								site: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الراوتر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: tower.routerId,
							onChange: (e) => setTower({
								...tower,
								routerId: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "بدون ربط"
							}), (data?.routers ?? []).map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: router.id,
								children: router.name
							}, router.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "خط العرض",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field ltr",
								value: tower.lat,
								onChange: (e) => setTower({
									...tower,
									lat: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "خط الطول",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field ltr",
								value: tower.lng,
								onChange: (e) => setTower({
									...tower,
									lng: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الطاقة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: tower.power,
							onChange: (e) => setTower({
								...tower,
								power: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "حفظ البرج"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel grid gap-3 p-4",
				onSubmit: (e) => void addAntenna(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "انتينا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "البرج",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							required: true,
							value: antenna.towerId,
							onChange: (e) => setAntenna({
								...antenna,
								towerId: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر"
							}), (data?.towers ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							required: true,
							value: antenna.name,
							onChange: (e) => setAntenna({
								...antenna,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الموديل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: antenna.model,
							onChange: (e) => setAntenna({
								...antenna,
								model: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "IP",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: antenna.ip,
							onChange: (e) => setAntenna({
								...antenna,
								ip: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "التردد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field ltr",
							value: antenna.frequency,
							onChange: (e) => setAntenna({
								...antenna,
								frequency: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "حفظ الانتينا"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data?.links ?? []).map((link, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel px-4 py-3 text-sm",
				children: [
					nameOf(link.fromKind, link.fromId),
					" ← ",
					nameOf(link.toKind, link.toId)
				]
			}, `${link.fromId}-${link.toId}-${index}`))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-3",
			children: (data?.towers ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge ${statusBadge(item.status)}`,
							children: statusText(item.status)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							item.site,
							" · طاقة: ",
							item.power || "غير مسجّلة"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: ["إحداثيات: ", item.lat && item.lng ? `${item.lat} , ${item.lng}` : "غير مسجّلة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2",
						children: (data?.antennas ?? []).filter((row) => row.towerId === item.id).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-surface-2 px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: row.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted",
								children: [
									row.model || "موديل غير معروف",
									" · ",
									row.frequency || "تردد غير مسجّل",
									" · عملاء ",
									row.clients ?? "—",
									" · إشارة ",
									row.signal === null ? "غير متاحة" : `${row.signal} dBm`,
									" · CCQ ",
									row.ccq === null ? "غير متاح" : `${row.ccq}٪`
								]
							})]
						}, row.id))
					})
				]
			}, item.id))
		})
	] });
}
//#endregion
export { TowersPage as component };
