import { o as __toESM } from "../_runtime.mjs";
import { o as formatWhen } from "./format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as listAlerts, t as ackAlert } from "./api-BC5M9OSJ.mjs";
import { i as PageHead, s as messageOf, u as useLoad } from "./kit-DNv6U2L1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alerts-CZePy7Dj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AlertsPage() {
	const load = (0, import_react.useCallback)(() => listAlerts(), []);
	const { data, error, loading, reload } = useLoad(load);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, { title: "التنبيهات" }),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "جاري التحميل…"
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data ?? []).map((alert) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "panel p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: alert.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: alert.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								formatWhen(alert.createdAt),
								" · ",
								alert.origin === "lab" ? "مختبر" : "تشغيل",
								" · ",
								alert.severity === "danger" ? "مرتفع" : "تحذير"
							]
						})
					] }), alert.acked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "badge",
						children: "أُغلق"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => void ackAlert({ data: { id: alert.id } }).then(() => reload()).catch((err) => toast.error(messageOf(err))),
						children: "إغلاق"
					})]
				})
			}, alert.id))
		})
	] });
}
//#endregion
export { AlertsPage as component };
