import { o as __toESM } from "./_runtime.mjs";
import { a as formatMoney, i as formatInt, o as formatWhen } from "./_ssr/format-HomJAAR4.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { l as getDashboard } from "./_ssr/api-BC5M9OSJ.mjs";
import { c as statusBadge, i as PageHead, l as statusText, o as Stat, t as Empty, u as useLoad } from "./_ssr/kit-DNv6U2L1.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "./_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-DipggI1i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const load = (0, import_react.useCallback)(() => getDashboard(), []);
	const { data, error, loading } = useLoad(load);
	if (loading && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "جاري تحميل مركز القيادة…"
	});
	if (error && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-danger",
		children: error
	});
	if (!data) return null;
	const s = data.stats;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: data.tenant.area || "شبكة",
			title: "مركز قيادة الشبكة",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: ["آخر جلب ", formatWhen(data.generatedAt)]
			})
		}),
		data.routers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "لا يوجد راوتر",
			body: "اربط جهازاً حقيقياً أو افتح المختبر من الشريط أعلاه. لن تُعرض سرعات أو جلسات قبل ذلك."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "راوترات متصلة",
					value: `${formatInt(s.online)} / ${formatInt(s.routers)}`,
					hint: `${formatInt(s.offline)} منقطع`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "جلسات الدخول",
					value: formatInt(s.active),
					hint: `هوتسبوت ${formatInt(s.hotspotActive)} · PPPoE ${formatInt(s.pppoeActive)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "كروت متبقية",
					value: formatInt(data.finance.left),
					hint: `مباع ${formatInt(data.finance.sold)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "مبيعات اليوم",
					value: formatMoney(data.finance.today),
					hint: `الشهر ${formatMoney(data.finance.month)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "مشتركو الهوتسبوت",
					value: formatInt(s.hotspotUsers)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "حسابات PPPoE",
					value: formatInt(s.pppoeUsers)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "أجهزة مسجّلة",
					value: formatInt(s.devices),
					hint: `${formatInt(s.towers)} أبراج · ${formatInt(s.antennas)} انتينات`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "تنبيهات مفتوحة",
					value: formatInt(s.alerts),
					hint: `${formatInt(s.faults)} عطل مرتفع`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 grid gap-3 lg:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-semibold",
					children: ["حركة محفوظة ", data.trafficRouter ? `— ${data.trafficRouter}` : ""]
				}), data.traffic.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted",
					children: "لا توجد سلسلة قياس. السرعة اللحظية تُقرأ من منفذ الإنترنت بعد مزامنة راوتر حقيقي."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: data.traffic.every((p) => p.origin === "lab") ? "نمط يوم مخزّن في المختبر، وليس بثاً حياً." : "عينات محفوظة من الجهاز."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ltr mt-3 h-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: data.traffic,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "hour",
									stroke: "var(--muted)",
									tick: { fontSize: 11 }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									stroke: "var(--muted)",
									tick: { fontSize: 11 },
									width: 36
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--surface)",
									border: "1px solid var(--line)",
									borderRadius: 12
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									dataKey: "down",
									name: "تحميل",
									stroke: "var(--cyan)",
									fill: "var(--cyan)",
									fillOpacity: .2
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									dataKey: "up",
									name: "رفع",
									stroke: "var(--royal)",
									fill: "var(--royal)",
									fillOpacity: .15
								})
							]
						})
					})
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "التنبيهات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-3",
					children: [data.alerts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "لا تنبيهات مفتوحة."
					}) : null, data.alerts.map((alert) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: alert.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: alert.detail
					})] }, alert.id))]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "الراوترات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/routers",
						className: "text-sm text-cyan-text",
						children: "الإدارة"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: data.routers.map((router) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/routers/$routerId",
						params: { routerId: router.id },
						className: "block rounded-xl border border-line px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: router.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `badge ${statusBadge(router.status)}`,
									children: statusText(router.status)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									router.mode === "lab" ? "مختبر · " : "حقيقي · ",
									router.model ?? "الموديل لم يُقرأ",
									" · ",
									router.rosVersion ?? "الإصدار لم يُقرأ"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs tabular-nums text-muted",
								children: [
									"معالج ",
									router.cpu === null ? "غير متاح" : `${formatInt(router.cpu)}٪`,
									" · ذاكرة ",
									router.ram === null ? "غير متاحة" : `${formatInt(router.ram)}٪`,
									" · حرارة ",
									router.temperature ?? "غير متاحة"
								]
							})
						]
					}, router.id))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "آخر الجلسات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/active",
							className: "text-sm text-cyan-text",
							children: "الكل"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [data.sessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "لا جلسات."
						}) : null, data.sessions.map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: session.username
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									statusText(session.kind),
									" · ",
									session.tower || "بدون برج"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ltr text-xs tabular-nums text-muted",
								children: session.ip
							})]
						}, `${session.username}-${session.ip}`))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-muted",
						children: ["مستحقات البائعين: ", data.finance.resellerDue === null ? "لا يوجد دفتر بائعين في هذه النسخة" : formatMoney(data.finance.resellerDue)]
					})
				]
			})]
		})
	] });
}
//#endregion
export { Dashboard as component };
