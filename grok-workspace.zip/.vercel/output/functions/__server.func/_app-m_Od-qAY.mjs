import { o as __toESM } from "./_runtime.mjs";
import { Q as require_react, S as Navigate, T as require_jsx_runtime, _ as Outlet, m as useRouterState, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { f as getWorkspace, z as setLab } from "./_ssr/api-BC5M9OSJ.mjs";
import { s as messageOf, u as useLoad } from "./_ssr/kit-DNv6U2L1.mjs";
import { i as signOut } from "./_ssr/client-1vAx-gM_.mjs";
import { a as hasGateSessionMarker } from "./_ssr/server-CDJZvhbS.mjs";
import { i as useCurrentUserState, n as Splash, r as useCurrentUser } from "./_ssr/login-screen-BhgTzSfL.mjs";
import { C as CreditCard, D as BadgeCheck, E as Bell, O as Activity, S as FileChartColumnIncreasing, T as Bot, _ as Lightbulb, b as Globe, c as Stethoscope, d as Router, f as Radio, g as Menu, h as Network, i as Users, l as Settings, m as Package, n as Wrench, o as Terminal, p as RadioTower, r as Wifi, s as Store, t as X, u as ScrollText, v as LifeBuoy, w as Cable, x as Gauge, y as HardDrive } from "./_libs/lucide-react.mjs";
import { t as Toaster } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-m_Od-qAY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var NAV = [
	{
		label: "المراقبة",
		items: [
			{
				to: "/",
				label: "مركز القيادة",
				icon: Gauge
			},
			{
				to: "/active",
				label: "المتصلون",
				icon: Activity
			},
			{
				to: "/routers",
				label: "الراوترات",
				icon: Router
			},
			{
				to: "/devices",
				label: "الأجهزة",
				icon: Radio
			},
			{
				to: "/towers",
				label: "الأبراج",
				icon: RadioTower
			},
			{
				to: "/sources",
				label: "مصادر الإنترنت",
				icon: Globe
			}
		]
	},
	{
		label: "المشتركون",
		items: [
			{
				to: "/hotspot",
				label: "هوتسبوت",
				icon: Wifi
			},
			{
				to: "/pppoe",
				label: "PPPoE",
				icon: Cable
			},
			{
				to: "/userman",
				label: "يوزر منجر",
				icon: Users
			},
			{
				to: "/profiles",
				label: "البروفايلات",
				icon: Gauge
			},
			{
				to: "/subscribers",
				label: "العملاء",
				icon: Users
			}
		]
	},
	{
		label: "المبيعات",
		items: [
			{
				to: "/vouchers",
				label: "الكروت",
				icon: CreditCard
			},
			{
				to: "/templates",
				label: "قوالب الطباعة",
				icon: FileChartColumnIncreasing
			},
			{
				to: "/resellers",
				label: "البائعون",
				icon: Store
			}
		]
	},
	{
		label: "التشغيل",
		items: [
			{
				to: "/alerts",
				label: "التنبيهات",
				icon: Bell
			},
			{
				to: "/diagnose",
				label: "البحث عن المشاكل",
				icon: Stethoscope
			},
			{
				to: "/assist",
				label: "مساعد الزهر",
				icon: Lightbulb
			},
			{
				to: "/network",
				label: "أدوات الشبكة",
				icon: Network
			},
			{
				to: "/maintenance",
				label: "الصيانة",
				icon: Wrench
			},
			{
				to: "/inventory",
				label: "المخزون",
				icon: Package
			},
			{
				to: "/backups",
				label: "النسخ الاحتياطي",
				icon: HardDrive
			},
			{
				to: "/reports",
				label: "التقارير",
				icon: FileChartColumnIncreasing
			},
			{
				to: "/scripts",
				label: "السكربتات",
				icon: Terminal
			},
			{
				to: "/channels",
				label: "تيليجرام وواتساب",
				icon: Bot
			},
			{
				to: "/audit",
				label: "سجل العمليات",
				icon: ScrollText
			}
		]
	},
	{
		label: "الحساب",
		items: [
			{
				to: "/subscription",
				label: "الاشتراك",
				icon: BadgeCheck
			},
			{
				to: "/support",
				label: "الدعم",
				icon: LifeBuoy
			},
			{
				to: "/settings",
				label: "الإعدادات",
				icon: Settings
			}
		]
	}
];
function Shell({ name, hasLab, onLabChange, children }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setOpen(false), [path]);
	async function lab(action) {
		try {
			await setLab({ data: { action } });
			onLabChange();
		} catch (error) {
			window.alert(messageOf(error));
		}
	}
	const nav = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-5",
		children: NAV.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 px-3 text-xs text-muted",
			children: group.label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-1",
			children: group.items.map((item) => {
				const active = path === item.to;
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: `flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm ${active ? "bg-cyan-dim font-semibold text-cyan-text" : "text-fg"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-4 shrink-0",
						"aria-hidden": "true"
					}), item.label]
				}, item.to);
			})
		})] }, group.label))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { style: {
					background: "var(--surface)",
					color: "var(--fg)",
					border: "1px solid var(--line)"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mx-auto grid max-w-7xl md:grid-cols-[17rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden border-e border-line bg-raised px-3 py-5 md:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: nav
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "no-print sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-bg/95 px-3 py-3 backdrop-blur",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost min-h-11 px-3 md:hidden",
									onClick: () => setOpen(true),
									"aria-label": "القائمة",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm text-muted",
										children: "الزهر MikroTik"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-semibold",
										children: name
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
							]
						}),
						hasLab ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "no-print mx-3 mt-3 flex flex-wrap items-center justify-between gap-3 rounded-card border border-warn bg-warn-dim px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "مختبر الزهر نت ظاهر الآن. الأرقام المخزّنة ليست قراءة حية من راوتر." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost min-h-10",
								onClick: () => void lab("clear"),
								children: "إزالة المختبر"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "no-print mx-3 mt-3 flex flex-wrap items-center justify-between gap-3 rounded-card border border-line px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "لا يوجد مختبر. اربط راوتراً أو افتح شبكة تجريبية معلّمة."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost min-h-10",
								onClick: () => void lab("restore"),
								children: "فتح المختبر"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							className: "px-3 py-4 pb-24",
							children
						})
					]
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print fixed inset-0 z-30 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "scrim absolute inset-0",
					"aria-label": "إغلاق",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-y-0 start-0 w-[min(20rem,88vw)] overflow-y-auto bg-raised p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost min-h-10 px-3",
							onClick: () => setOpen(false),
							"aria-label": "إغلاق",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), nav]
				})]
			}) : null
		]
	});
}
function Brand({ name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold text-cyan-text",
			children: "الزهر"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs tracking-wide text-muted",
			children: ["MikroTik · ", name]
		})]
	});
}
function AppFrame() {
	const { user, isPending } = useCurrentUserState();
	const load = (0, import_react.useCallback)(() => getWorkspace(), []);
	const ws = useLoad(load);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!ws.data) return ws.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-md text-danger",
			children: ws.error
		})
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		name: ws.data.tenant.name,
		hasLab: ws.data.hasLab,
		onLabChange: () => window.location.reload(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var SplitComponent = AppFrame;
//#endregion
export { SplitComponent as component };
