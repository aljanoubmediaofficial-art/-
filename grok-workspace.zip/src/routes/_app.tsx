import { createFileRoute } from "@tanstack/react-router";
import { AppFrame } from "@/components/frame";

export const Route = createFileRoute("/_app")({ component: AppFrame });
