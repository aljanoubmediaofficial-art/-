import { createFileRoute } from "@tanstack/react-router";
import { AccountsPage } from "@/components/accounts";
import { listHotspot } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/hotspot")({
  component: () => <AccountsPage title="هوتسبوت" kind="hotspot" loader={listHotspot} />,
});
