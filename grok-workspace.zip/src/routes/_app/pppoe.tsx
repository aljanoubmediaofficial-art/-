import { createFileRoute } from "@tanstack/react-router";
import { AccountsPage } from "@/components/accounts";
import { listPppoe } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/pppoe")({
  component: () => <AccountsPage title="PPPoE" kind="pppoe" loader={listPppoe} />,
});
