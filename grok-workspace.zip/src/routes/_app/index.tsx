import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Empty, PageHead, Stat, statusText, useLoad } from "@/components/kit";
import { getDashboard } from "@/lib/noc/api";
import { formatInt, formatMoney, formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/")({ component: Dashboard });

function Dashboard() {
  const load = useCallback(() => getDashboard(), []);
  const { data, error, loading } = useLoad(load);
  if (loading && !data) return <p className="text-muted">جاري تحميل مركز القيادة…</p>;
  if (error && !data) return <p className="text-danger">{error}</p>;
  if (!data) return null;
  const s = data.stats;
  return (
    <div>
      <PageHead kicker={data.tenant.area || "شبكة"} title="مركز قيادة الشبكة">
        <p className="text-xs text-muted">آخر جلب {formatWhen(data.generatedAt)}</p>
      </PageHead>
      {data.routers.length === 0 ? (
        <Empty
          title="لا يوجد راوتر"
          body="اربط جهازاً حقيقياً أو افتح المختبر من الشريط أعلاه. لن تُعرض سرعات أو جلسات قبل ذلك."
        />
      ) : null}
      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="راوترات متصلة" value={`${formatInt(s.liveOnline)} LIVE`} hint={`LAB ${formatInt(s.labOnline)} · منقطع ${formatInt(s.offline)}`} />
        <Stat label="جلسات الدخول" value={formatInt(s.liveActive)} hint={`LIVE ${formatInt(s.liveActive)} · LAB ${formatInt(s.labActive)}`} />
        <Stat label="كروت متبقية" value={formatInt(data.finance.left)} hint={`مباع ${formatInt(data.finance.sold)}`} />
        <Stat label="مبيعات اليوم" value={formatMoney(data.finance.today)} hint={`الشهر ${formatMoney(data.finance.month)}`} />
        <Stat label="مشتركو الهوتسبوت" value={formatInt(s.hotspotUsers)} />
        <Stat label="حسابات PPPoE" value={formatInt(s.pppoeUsers)} />
        <Stat label="أجهزة مسجّلة" value={formatInt(s.devices)} hint={`${formatInt(s.towers)} أبراج · ${formatInt(s.antennas)} انتينات`} />
        <Stat label="تنبيهات مفتوحة" value={formatInt(s.alerts)} hint={`${formatInt(s.faults)} عطل مرتفع`} />
      </section>
      <section className="mt-4 grid gap-3 lg:grid-cols-[1.4fr_1fr]">
        <article className="panel p-4">
          <h2 className="font-semibold">حركة محفوظة {data.trafficRouter ? `— ${data.trafficRouter}` : ""}</h2>
          {data.traffic.length < 2 ? (
            <p className="mt-6 text-sm text-muted">لا توجد سلسلة قياس. السرعة اللحظية تُقرأ من منفذ الإنترنت بعد مزامنة راوتر حقيقي.</p>
          ) : (
            <>
              <p className="mt-1 text-xs text-muted">
                {data.traffic.every((p) => p.origin === "lab")
                  ? "نمط يوم مخزّن في المختبر، وليس بثاً حياً."
                  : "عينات محفوظة من الجهاز."}
              </p>
              <div className="ltr mt-3 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data.traffic}>
                    <XAxis dataKey="hour" stroke="var(--muted)" tick={{ fontSize: 11 }} />
                    <YAxis stroke="var(--muted)" tick={{ fontSize: 11 }} width={36} />
                    <Tooltip
                      contentStyle={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 12 }}
                    />
                    <Area dataKey="down" name="تحميل" stroke="var(--cyan)" fill="var(--cyan)" fillOpacity={0.2} />
                    <Area dataKey="up" name="رفع" stroke="var(--royal)" fill="var(--royal)" fillOpacity={0.15} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </>
          )}
        </article>
        <article className="panel p-4">
          <h2 className="font-semibold">التنبيهات</h2>
          <div className="mt-3 space-y-3">
            {data.alerts.length === 0 ? <p className="text-sm text-muted">لا تنبيهات مفتوحة.</p> : null}
            {data.alerts.map((alert) => (
              <div key={alert.id}>
                <p className="text-sm font-semibold">{alert.title}</p>
                <p className="text-sm text-muted">{alert.detail}</p>
              </div>
            ))}
          </div>
        </article>
      </section>
      <section className="mt-4 grid gap-3 lg:grid-cols-2">
        <article className="panel p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">الراوترات</h2>
            <Link to="/routers" className="text-sm text-cyan-text">الإدارة</Link>
          </div>
          <div className="space-y-3">
            {data.routers.map((router) => (
              <Link key={router.id} to="/routers/$routerId" params={{ routerId: router.id }} className="block rounded-xl border border-line px-3 py-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold">{router.name}</p>
                  <span className={`badge ${router.mode === "lab" ? "badge-warn" : router.report?.accepted ? "badge-ok" : "badge-danger"}`}>
                    {router.mode === "lab" ? "LAB" : router.report?.accepted ? "LIVE" : "غير مقبول"}
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted">
                  {router.mode === "lab" ? "LAB · أرقام مخزّنة" : router.report?.accepted ? "LIVE · من الجهاز" : "لا قراءة مقبولة من الجهاز"}
                  {" · "}
                  {router.model ?? "الموديل لم يُقرأ"} · {router.rosVersion ?? "الإصدار لم يُقرأ"}
                </p>
                <p className="mt-2 text-xs tabular-nums text-muted">
                  معالج {router.cpu === null ? "غير متاح" : `${formatInt(router.cpu)}٪`} · ذاكرة {router.ram === null ? "غير متاحة" : `${formatInt(router.ram)}٪`} · حرارة {router.temperature ?? "غير متاحة"}
                </p>
              </Link>
            ))}
          </div>
        </article>
        <article className="panel p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">آخر الجلسات</h2>
            <Link to="/active" className="text-sm text-cyan-text">الكل</Link>
          </div>
          <div className="space-y-3">
            {data.sessions.length === 0 ? <p className="text-sm text-muted">لا جلسات.</p> : null}
            {data.sessions.map((session) => (
              <div key={`${session.username}-${session.ip}`} className="flex items-center justify-between gap-3 text-sm">
                <div>
                  <p className="font-medium">{session.username}</p>
                  <p className="text-xs text-muted">{statusText(session.kind)} · {session.origin === "sync" ? "LIVE" : "LAB"} · {session.tower || "بدون برج"}</p>
                </div>
                <p className="ltr text-xs tabular-nums text-muted">{session.ip}</p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-muted">
            مستحقات البائعين: {data.finance.resellerDue === null ? "لا يوجد دفتر بائعين في هذه النسخة" : formatMoney(data.finance.resellerDue)}
          </p>
        </article>
      </section>
    </div>
  );
}
