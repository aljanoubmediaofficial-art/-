import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, ROLE_LABEL, messageOf, useLoad } from "@/components/kit";
import { getWorkspace, listStaff, saveStaff, updateWorkspace } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/settings")({ component: SettingsPage });

function SettingsPage() {
  const workspace = useLoad(useCallback(() => getWorkspace(), []));
  const staff = useLoad(useCallback(() => listStaff(), []));
  const [name, setName] = useState("");
  const [area, setArea] = useState("");
  const [theme, setTheme] = useState("dark");
  const [person, setPerson] = useState({ name: "", role: "tech", phone: "", active: true });

  useEffect(() => {
    if (workspace.data && !name) {
      setName(workspace.data.tenant.name);
      setArea(workspace.data.tenant.area);
    }
  }, [workspace.data, name]);

  useEffect(() => {
    setTheme(document.documentElement.dataset.theme === "light" ? "light" : "dark");
  }, []);

  function applyTheme(next: string) {
    setTheme(next);
    document.documentElement.dataset.theme = next === "light" ? "light" : "dark";
    localStorage.setItem("alzher-theme", next);
  }

  async function saveNetwork(event: React.FormEvent) {
    event.preventDefault();
    try {
      await updateWorkspace({ data: { name, area, logo: workspace.data?.tenant.logo ?? null } });
      toast.success("حُفظت بيانات الشبكة");
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function onLogo(file: File | undefined) {
    if (!file) return;
    const data = await file.arrayBuffer();
    const bytes = new Uint8Array(data);
    let binary = "";
    bytes.forEach((byte) => {
      binary += String.fromCharCode(byte);
    });
    const mime = file.type === "image/jpeg" ? "image/jpeg" : "image/png";
    try {
      await updateWorkspace({
        data: { name: name || workspace.data?.tenant.name || "شبكة", area, logo: `data:${mime};base64,${btoa(binary)}` },
      });
      toast.success("رُفع الشعار");
      window.location.reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function addStaff(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveStaff({ data: person });
      toast.success("أُضيف الموظف. الدخول ما زال لحساب المالك فقط.");
      setPerson({ name: "", role: "tech", phone: "", active: true });
      await staff.reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead title="الإعدادات" />
      <form className="panel grid gap-3 p-4" onSubmit={(e) => void saveNetwork(e)}>
        <Field label="اسم الشبكة"><input className="field" value={name} onChange={(e) => setName(e.target.value)} required /></Field>
        <Field label="النطاق"><input className="field" value={area} onChange={(e) => setArea(e.target.value)} /></Field>
        <Field label="الشعار الرسمي PNG أو JPEG">
          <input className="field" type="file" accept="image/png,image/jpeg" onChange={(e) => void onLogo(e.target.files?.[0])} />
        </Field>
        <p className="text-xs text-muted">لا يُستبدل شعارك بعلامة مولّدة. إن لم يُرفع، تبقى الكلمة «الزهر» نصاً.</p>
        <button className="btn btn-primary" type="submit">حفظ</button>
      </form>
      <section className="panel mt-4 p-4">
        <h2 className="font-semibold">المظهر</h2>
        <div className="mt-3 flex gap-2">
          <button type="button" className={`btn ${theme === "dark" ? "btn-primary" : "btn-ghost"}`} onClick={() => applyTheme("dark")}>داكن</button>
          <button type="button" className={`btn ${theme === "light" ? "btn-primary" : "btn-ghost"}`} onClick={() => applyTheme("light")}>فاتح</button>
        </div>
      </section>
      <section className="panel mt-4 p-4">
        <h2 className="font-semibold">الموظفون</h2>
        <p className="mt-1 text-sm text-muted">الحساب الذي دخل هو المالك. سجل الموظف هنا لا يفتح له دخولاً مستقلاً بعد.</p>
        <div className="mt-3 space-y-2">
          {(staff.data?.staff ?? []).map((member) => (
            <p key={member.id} className="text-sm">{member.name} · {ROLE_LABEL[member.role] ?? member.role} · {member.phone}</p>
          ))}
        </div>
        <form className="mt-4 grid gap-3" onSubmit={(e) => void addStaff(e)}>
          <Field label="الاسم"><input className="field" value={person.name} onChange={(e) => setPerson({ ...person, name: e.target.value })} required /></Field>
          <Field label="الدور">
            <select className="field" value={person.role} onChange={(e) => setPerson({ ...person, role: e.target.value })}>
              {Object.entries(ROLE_LABEL).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
            </select>
          </Field>
          <Field label="الهاتف"><input className="field ltr" value={person.phone} onChange={(e) => setPerson({ ...person, phone: e.target.value })} /></Field>
          <button className="btn btn-ghost" type="submit">إضافة</button>
        </form>
      </section>
      <section className="mt-4 text-sm text-muted">
        <p>جدار الحماية وDHCP وVPN ليست في هذه النسخة حتى لا تُفتح شاشات بلا تنفيذ.</p>
        <p className="mt-2">واتساب وتيليجرام وخريطة المواقع تُستكمل بعد مسار الربط هذا.</p>
      </section>
    </div>
  );
}
