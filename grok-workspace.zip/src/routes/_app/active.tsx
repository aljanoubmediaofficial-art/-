import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import { Empty, PageHead, messageOf, statusText, useLoad } from "@/components/kit";
import { disconnectSession, listSessions } from "@/lib/noc/api";
import { formatBytes, formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/active")({ component: ActivePage });

function ActivePage() {
  const load = useCallback(() => listSessions(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("");
  const [pending, setPending] = useState("");
  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    return (data ?? []).filter((row) => {
      if (kind && row.kind !== kind) return false;
      if (!query) return true;
      return [row.username, row.ip, row.mac, row.router].join(" ").toLowerCase().includes(query);
    });
  }, [data, q, kind]);

  async function cut(id: string) {
    setPending(id);
    try {
      const result = await disconnectSession({ data: { id } });
      toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setPending("");
    }
  }

  function exportCsv() {
    const header = "user,ip,mac,kind,source,router,tower\n";
    const body = rows
      .map((row) => [row.username, row.ip, row.mac, row.kind, row.source, row.router, row.tower].join(","))
      .join("\n");
    const blob = new Blob([`\uFEFF${header}${body}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sessions.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHead kicker="جلسات الدخول فقط" title="المتصلون">
        <button type="button" className="btn btn-ghost" onClick={exportCsv} disabled={!rows.length}>
          تصدير
        </button>
      </PageHead>
      <p className="mb-4 text-sm text-muted">
        القائمة لجلسات الهوتسبوت وPPPoE. عقد DHCP وARP لا تُحسب مستخدماً نشطاً ولا تظهر هنا.
      </p>
      <div className="mb-4 grid gap-3 sm:grid-cols-[1fr_10rem]">
        <input className="field" placeholder="اسم أو IP أو MAC" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="field" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">الكل</option>
          <option value="hotspot">هوتسبوت</option>
          <option value="pppoe">PPPoE</option>
        </select>
      </div>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      {!loading && rows.length === 0 ? <Empty title="لا جلسات" body="لا توجد جلسة دخول مطابقة. زامن راوتراً حقيقياً أو ابقِ المختبر ظاهراً." /> : null}
      <div className="space-y-3">
        {rows.map((row) => (
          <article key={row.id} className="panel p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{row.username}</p>
                <p className="text-sm text-muted">
                  {statusText(row.kind)} · {row.source === "authenticated" ? "جلسة مصادقة" : row.source} · {row.router}
                  {row.mode === "lab" ? " · مختبر" : ""}
                </p>
              </div>
              <button type="button" className="btn btn-danger" disabled={pending === row.id} onClick={() => void cut(row.id)}>
                فصل
              </button>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <div><dt className="text-muted">IP</dt><dd className="ltr tabular-nums">{row.ip || "—"}</dd></div>
              <div><dt className="text-muted">MAC</dt><dd className="ltr tabular-nums">{row.mac || "—"}</dd></div>
              <div><dt className="text-muted">البرج</dt><dd>{row.tower || "غير مربوط"}</dd></div>
              <div><dt className="text-muted">الانتينا</dt><dd>{row.antenna || "غير محدد"}</dd></div>
              <div><dt className="text-muted">البداية</dt><dd>{formatWhen(row.startedAt)}</dd></div>
              <div><dt className="text-muted">الاستهلاك</dt><dd className="tabular-nums">{formatBytes(row.bytesIn + row.bytesOut)}</dd></div>
              <div><dt className="text-muted">السرعة</dt><dd>{row.down && row.up ? `${row.down} / ${row.up}` : "غير مقاسة"}</dd></div>
              <div><dt className="text-muted">البروفايل</dt><dd>{row.profile || "—"}</dd></div>
            </dl>
          </article>
        ))}
      </div>
    </div>
  );
}
