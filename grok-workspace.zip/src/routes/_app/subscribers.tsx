import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusBadge, statusText, useLoad } from "@/components/kit";
import { formatMoney } from "@/lib/format";
import { listPayments, recordPayment, saveSubscriber } from "@/lib/noc/desk";
import { listSubscribers, renewSubscriber } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/subscribers")({ component: SubscribersPage });

function SubscribersPage() {
  const load = useCallback(async () => {
    const [people, payments] = await Promise.all([listSubscribers(), listPayments()]);
    return { people, payments };
  }, []);
  const { data, error, loading, reload } = useLoad(load);
  const [open, setOpen] = useState(false);
  const [payFor, setPayFor] = useState<string | null>(null);
  const [amount, setAmount] = useState(3000);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
    tower: "",
    antenna: "",
    service: "PPPoE",
    account: "",
    plan: "",
    endsOn: "",
  });

  async function renew(id: string, days: number) {
    try {
      const result = await renewSubscriber({ data: { id, days } });
      toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await saveSubscriber({ data: form });
      toast.success(`أُضيف العميل ${result.code}`);
      setOpen(false);
      setForm({ name: "", phone: "", address: "", tower: "", antenna: "", service: "PPPoE", account: "", plan: "", endsOn: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function pay(event: React.FormEvent) {
    event.preventDefault();
    if (!payFor) return;
    try {
      const result = await recordPayment({ data: { subscriberId: payFor, amount, note: "دفعة اشتراك" } });
      toast.success(result.message);
      setPayFor(null);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="اشتراك الخدمة المستمرة" title="العملاء">
        <button type="button" className="btn btn-primary" onClick={() => setOpen((v) => !v)}>{open ? "إغلاق" : "عميل جديد"}</button>
      </PageHead>
      {open ? (
        <form className="panel mb-4 grid gap-3 p-4 sm:grid-cols-2" onSubmit={(e) => void add(e)}>
          <Field label="الاسم"><input className="field" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="الهاتف"><input className="field ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label="العنوان"><input className="field" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
          <Field label="الخدمة">
            <select className="field" value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })}>
              <option>PPPoE</option>
              <option>Hotspot</option>
            </select>
          </Field>
          <Field label="البرج"><input className="field" value={form.tower} onChange={(e) => setForm({ ...form, tower: e.target.value })} /></Field>
          <Field label="الانتينا"><input className="field" value={form.antenna} onChange={(e) => setForm({ ...form, antenna: e.target.value })} /></Field>
          <Field label="الحساب"><input className="field ltr" value={form.account} onChange={(e) => setForm({ ...form, account: e.target.value })} /></Field>
          <Field label="الباقة"><input className="field" value={form.plan} onChange={(e) => setForm({ ...form, plan: e.target.value })} /></Field>
          <Field label="ينتهي"><input className="field ltr" required placeholder="2026-12-01" value={form.endsOn} onChange={(e) => setForm({ ...form, endsOn: e.target.value })} /></Field>
          <button className="btn btn-primary sm:col-span-2" type="submit">حفظ العميل</button>
        </form>
      ) : null}
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {(data?.people ?? []).map((person) => {
          const paid = (data?.payments ?? []).filter((row) => row.subscriberId === person.id);
          return (
            <article key={person.id} className="panel p-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="font-semibold">{person.name}</h2>
                <span className={`badge ${statusBadge(person.status)}`}>{statusText(person.status)}</span>
              </div>
              <p className="mt-1 text-sm text-muted">{person.code} · {person.phone} · {person.address}</p>
              <p className="text-sm text-muted">{person.tower} · {person.antenna} · {person.plan} · {person.account}</p>
              <p className="mt-1 text-sm">من <span className="ltr">{person.startedOn}</span> إلى <span className="ltr">{person.endsOn}</span></p>
              {paid.length > 0 ? <p className="mt-1 text-xs text-muted">آخر دفعة {formatMoney(paid[0]?.amount)} في {paid[0]?.day}</p> : null}
              <div className="mt-3 flex flex-wrap gap-2">
                {[30, 7, 1].map((days) => (
                  <button key={days} type="button" className="btn btn-ghost" onClick={() => void renew(person.id, days)}>
                    {days === 30 ? "شهر" : days === 7 ? "أسبوع" : "يوم"}
                  </button>
                ))}
                <button type="button" className="btn btn-ghost" onClick={() => setPayFor(payFor === person.id ? null : person.id)}>دفعة</button>
              </div>
              {payFor === person.id ? (
                <form className="mt-3 flex flex-wrap items-end gap-2" onSubmit={(e) => void pay(e)}>
                  <Field label="المبلغ">
                    <input className="field ltr" type="number" min={1} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
                  </Field>
                  <button className="btn btn-primary" type="submit">تسجيل</button>
                </form>
              ) : null}
            </article>
          );
        })}
      </div>
    </div>
  );
}
