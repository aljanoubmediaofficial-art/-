import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import { Field, Modal, PageHead, messageOf, useLoad } from "@/components/kit";
import { generateVouchers, listProfiles, listRouters, listTemplates, listVouchers, sellVouchers, setVoucherStatus, voucherCodes } from "@/lib/noc/api";
import { formatMoney } from "@/lib/format";

export const Route = createFileRoute("/_app/vouchers")({ component: VouchersPage });

function VouchersPage() {
  const load = useCallback(() => listVouchers(), []);
  const { data, error, loading, reload } = useLoad(load);
  const routers = useLoad(useCallback(() => listRouters(), []));
  const profiles = useLoad(useCallback(() => listProfiles(), []));
  const templates = useLoad(useCallback(() => listTemplates(), []));
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const [reveal, setReveal] = useState(false);
  const [sheet, setSheet] = useState<{ username: string; password: string; price: number; validity: string; profile: string; qr?: string }[]>([]);
  const [form, setForm] = useState({
    routerId: "",
    profile: "",
    price: 200,
    cardType: "same" as "user" | "same" | "different",
    count: 10,
    length: 5,
    charset: "digits" as "digits" | "letters" | "mixed",
    prefix: "ZN",
    validity: "١ يوم",
    recordSale: false,
  });
  const template = templates.data?.[0];
  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    return (data?.vouchers ?? []).filter((row) => !query || row.username.toLowerCase().includes(query) || row.profile.toLowerCase().includes(query));
  }, [data, q]);

  async function generate(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await generateVouchers({
        data: {
          ...form,
          routerId: form.routerId || routers.data?.routers[0]?.id || "",
          price: Number(form.price),
          count: Number(form.count),
          length: Number(form.length),
        },
      });
      toast.success(result.message);
      setOpen(false);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function sell() {
    try {
      const result = await sellVouchers({ data: { ids: picked } });
      toast.success(result.message);
      setPicked([]);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function printCards() {
    const cards = rows.filter((row) => picked.includes(row.id));
    const target = cards.length ? cards : rows.slice(0, 12);
    try {
      const codes = template?.showQr ? await voucherCodes({ data: { ids: target.map((row) => row.id) } }) : [];
      setSheet(
        target.map((row) => ({
          username: row.username,
          password: row.password,
          price: row.price,
          validity: row.validity,
          profile: row.profile,
          qr: codes.find((code) => code.id === row.id)?.qr,
        })),
      );
      setTimeout(() => window.print(), 200);
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  function csv() {
    const header = reveal ? "user,password,profile,price,status\n" : "user,profile,price,status\n";
    const body = rows
      .map((row) => (reveal ? [row.username, row.password, row.profile, row.price, row.status] : [row.username, row.profile, row.price, row.status]).join(","))
      .join("\n");
    const blob = new Blob([`\uFEFF${header}${body}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "vouchers.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHead kicker="التوليد على الراوتر إن كان حقيقياً" title="الكروت">
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>توليد</button>
      </PageHead>
      <div className="mb-4 flex flex-wrap gap-2">
        <input className="field min-w-0 flex-1" placeholder="بحث" value={q} onChange={(e) => setQ(e.target.value)} />
        <button type="button" className="btn btn-ghost" onClick={() => void sell()} disabled={!picked.length}>تسجيل بيع</button>
        <button type="button" className="btn btn-ghost" onClick={() => void printCards()}>طباعة</button>
        <button type="button" className="btn btn-ghost" onClick={csv}>تصدير</button>
      </div>
      <label className="mb-4 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={reveal} onChange={(e) => setReveal(e.target.checked)} />
        إظهار كلمات المرور في الشاشة والتصدير
      </label>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="mb-4 space-y-2">
        {(data?.batches ?? []).slice(0, 4).map((batch) => (
          <p key={batch.id} className="text-sm text-muted">
            دفعة {batch.prefix || "بدون بادئة"} · {batch.qty} · {batch.profile} · {batch.origin === "lab" ? "مختبر" : "حقيقي"}
          </p>
        ))}
      </div>
      <div className="space-y-2">
        {rows.map((row) => (
          <label key={row.id} className="panel flex items-center gap-3 p-3 text-sm">
            <input
              type="checkbox"
              checked={picked.includes(row.id)}
              onChange={(e) => setPicked(e.target.checked ? [...picked, row.id] : picked.filter((id) => id !== row.id))}
            />
            <div className="min-w-0 flex-1">
              <p className="font-semibold ltr text-start">{row.username}</p>
              <p className="text-muted">{row.profile} · {formatMoney(row.price)} · {row.status === "new" ? "جديد" : row.status === "sold" ? "مباع" : "معطّل"} · {row.origin === "lab" ? "مختبر" : "حقيقي"}</p>
              {reveal ? <p className="ltr text-xs">{row.password}</p> : null}
            </div>
            {row.origin === "lab" && row.status !== "sold" ? (
              <button
                type="button"
                className="btn btn-ghost min-h-10"
                onClick={(e) => {
                  e.preventDefault();
                  void setVoucherStatus({ data: { id: row.id, status: row.status === "disabled" ? "new" : "disabled" } })
                    .then(() => reload())
                    .catch((err: unknown) => toast.error(messageOf(err)));
                }}
              >
                {row.status === "disabled" ? "إعادة" : "تعطيل"}
              </button>
            ) : null}
          </label>
        ))}
      </div>
      <Modal open={open} title="توليد دفعة" onClose={() => setOpen(false)}>
        <form className="grid gap-3" onSubmit={(e) => void generate(e)}>
          <Field label="الراوتر">
            <select className="field" value={form.routerId} onChange={(e) => setForm({ ...form, routerId: e.target.value })}>
              {(routers.data?.routers ?? []).map((router) => (
                <option key={router.id} value={router.id}>{router.name}</option>
              ))}
            </select>
          </Field>
          <Field label="البروفايل">
            <input className="field" list="profile-names" value={form.profile} onChange={(e) => setForm({ ...form, profile: e.target.value })} />
            <datalist id="profile-names">
              {(profiles.data ?? []).filter((profile) => profile.kind === "hotspot").map((profile) => (
                <option key={profile.id} value={profile.name} />
              ))}
            </datalist>
          </Field>
          <Field label="النوع">
            <select className="field" value={form.cardType} onChange={(e) => setForm({ ...form, cardType: e.target.value as typeof form.cardType })}>
              <option value="user">اسم فقط</option>
              <option value="same">اسم وكلمة متطابقان</option>
              <option value="different">اسم وكلمة مختلفان</option>
            </select>
          </Field>
          <Field label="العدد"><input className="field ltr" type="number" min={1} max={100} value={form.count} onChange={(e) => setForm({ ...form, count: Number(e.target.value) })} /></Field>
          <Field label="طول الرمز"><input className="field ltr" type="number" min={4} max={10} value={form.length} onChange={(e) => setForm({ ...form, length: Number(e.target.value) })} /></Field>
          <Field label="الأحرف">
            <select className="field" value={form.charset} onChange={(e) => setForm({ ...form, charset: e.target.value as typeof form.charset })}>
              <option value="digits">أرقام</option>
              <option value="letters">حروف</option>
              <option value="mixed">مختلط</option>
            </select>
          </Field>
          <Field label="بادئة"><input className="field ltr" value={form.prefix} onChange={(e) => setForm({ ...form, prefix: e.target.value })} /></Field>
          <Field label="السعر"><input className="field ltr" type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} /></Field>
          <Field label="الصلاحية"><input className="field" value={form.validity} onChange={(e) => setForm({ ...form, validity: e.target.value })} /></Field>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.recordSale} onChange={(e) => setForm({ ...form, recordSale: e.target.checked })} />تسجيل القيمة كمبيعات</label>
          <button className="btn btn-primary" type="submit">توليد</button>
        </form>
      </Modal>
      <section id="print-sheet" className="mt-6 hidden print:block">
        <div className="grid grid-cols-2 gap-3">
          {sheet.map((card) => (
            <article key={card.username} className="border border-line p-3 text-ink">
              <p className="font-semibold">الزهر نت</p>
              {template?.showUser !== false ? <p className="ltr">{card.username}</p> : null}
              {template?.showPass !== false && card.password !== card.username ? <p className="ltr">{card.password}</p> : null}
              {template?.showPrice !== false ? <p>{formatMoney(card.price)}</p> : null}
              {template?.showValidity !== false ? <p>{card.validity}</p> : null}
              {template?.showProfile ? <p>{card.profile}</p> : null}
              {card.qr ? <img src={card.qr} alt="" className="mt-2 h-16 w-16" /> : null}
              <p className="text-xs">{template?.footer}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
