import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusText, useLoad } from "@/components/kit";
import { formatInt, formatMoney } from "@/lib/format";
import { listInventory, saveInventory } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/inventory")({ component: InventoryPage });

const KINDS = [
  ["router", "راوتر"],
  ["antenna", "انتينا"],
  ["modem", "مودم"],
  ["switch", "سويتش"],
  ["cable", "كيبل"],
  ["power", "طاقة"],
  ["other", "أخرى"],
] as const;

function InventoryPage() {
  const load = useCallback(() => listInventory(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({
    name: "",
    kind: "router",
    serial: "",
    model: "",
    qty: 1,
    buyPrice: 0,
    location: "",
    state: "stock",
    warranty: "",
    boughtOn: "",
  });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveInventory({ data: form });
      toast.success("سُجّلت القطعة");
      setForm({ ...form, name: "", serial: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  const kindName = (kind: string) => KINDS.find((item) => item[0] === kind)?.[1] ?? kind;

  return (
    <div>
      <PageHead kicker="الرقم التسلسلي والموقع" title="المخزون" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel grid gap-3 p-4 sm:grid-cols-2" onSubmit={(e) => void add(e)}>
        <Field label="الاسم"><input className="field" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="النوع">
          <select className="field" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            {KINDS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </Field>
        <Field label="الموديل"><input className="field ltr" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></Field>
        <Field label="التسلسل"><input className="field ltr" value={form.serial} onChange={(e) => setForm({ ...form, serial: e.target.value })} /></Field>
        <Field label="الكمية"><input className="field ltr" type="number" min={1} value={form.qty} onChange={(e) => setForm({ ...form, qty: Number(e.target.value) })} /></Field>
        <Field label="سعر الشراء"><input className="field ltr" type="number" min={0} value={form.buyPrice} onChange={(e) => setForm({ ...form, buyPrice: Number(e.target.value) })} /></Field>
        <Field label="الموقع"><input className="field" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></Field>
        <Field label="الحالة">
          <select className="field" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })}>
            <option value="stock">مخزن</option>
            <option value="installed">مركّب</option>
            <option value="spare">احتياط</option>
            <option value="faulty">عطل</option>
          </select>
        </Field>
        <Field label="الضمان"><input className="field" value={form.warranty} onChange={(e) => setForm({ ...form, warranty: e.target.value })} /></Field>
        <Field label="تاريخ الشراء"><input className="field ltr" placeholder="2026-11-05" value={form.boughtOn} onChange={(e) => setForm({ ...form, boughtOn: e.target.value })} /></Field>
        <button className="btn btn-primary sm:col-span-2" type="submit">إضافة</button>
      </form>
      <div className="mt-4 space-y-3">
        {(data ?? []).map((item) => (
          <article key={item.id} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{item.name}</h2>
              <span className="badge">{statusText(item.state)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{kindName(item.kind)} · {item.model || "بدون موديل"} · {item.serial || "بدون تسلسل"}</p>
            <p className="text-sm text-muted">{item.location || "بدون موقع"} · كمية {formatInt(item.qty)} · {formatMoney(item.buyPrice)}</p>
            <p className="text-xs text-muted">{item.warranty || "ضمان غير مسجّل"} · شراء {item.boughtOn || "غير مؤرخ"}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
