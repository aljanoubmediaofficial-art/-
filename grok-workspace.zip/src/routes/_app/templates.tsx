import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, useLoad } from "@/components/kit";
import { listTemplates, saveTemplate } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/templates")({ component: TemplatesPage });

function TemplatesPage() {
  const load = useCallback(() => listTemplates(), []);
  const { data, error, loading, reload } = useLoad(load);
  const current = data?.[0];
  const [name, setName] = useState("");
  const [footer, setFooter] = useState("");
  const [flags, setFlags] = useState({
    showUser: true,
    showPass: true,
    showPrice: true,
    showValidity: true,
    showProfile: true,
    showQr: true,
  });
  const ready = current && name === "" ? current : null;
  const view = {
    name: name || current?.name || "كرت جديد",
    footer: footer || current?.footer || "",
    ...(name === "" && current ? current : flags),
  };

  async function save() {
    try {
      await saveTemplate({
        data: {
          id: current?.id,
          name: view.name,
          accent: "cyan",
          showUser: view.showUser,
          showPass: view.showPass,
          showPrice: view.showPrice,
          showValidity: view.showValidity,
          showProfile: view.showProfile,
          showQr: view.showQr,
          footer: view.footer,
        },
      });
      toast.success("حُفظ القالب");
      setName("");
      setFooter("");
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  const toggle = (key: keyof typeof flags) =>
    setFlags((prev) => {
      const base = current && name === "" ? { ...current } : prev;
      return { ...base, [key]: !base[key] };
    });

  return (
    <div>
      <PageHead kicker="حقول الكرت لا مواضع حرة" title="قالب الطباعة" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="grid gap-3">
          <Field label="اسم القالب"><input className="field" value={name || current?.name || ""} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="تذييل"><input className="field" value={footer || current?.footer || ""} onChange={(e) => setFooter(e.target.value)} /></Field>
          {(["showUser", "showPass", "showPrice", "showValidity", "showProfile", "showQr"] as const).map((key) => (
            <label key={key} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={Boolean(view[key])} onChange={() => toggle(key)} />
              {label(key)}
            </label>
          ))}
          <p className="text-xs text-muted">رمز QR يحمل اسم المستخدم فقط، ولا يضع كلمة المرور في رابط.</p>
          <button type="button" className="btn btn-primary" onClick={() => void save()}>حفظ القالب</button>
        </div>
        <article className="panel p-5">
          <p className="text-xs text-cyan-text">معاينة</p>
          <h2 className="mt-2 text-xl font-semibold">{view.name}</h2>
          {view.showUser ? <p className="ltr mt-3">ZN10421</p> : null}
          {view.showPass ? <p className="ltr">ZN10421</p> : null}
          {view.showPrice ? <p className="mt-2">200 ر.ي</p> : null}
          {view.showValidity ? <p>١ يوم</p> : null}
          {view.showProfile ? <p>يوم-٢ميجا</p> : null}
          {view.showQr ? <div className="mt-3 h-16 w-16 rounded-lg border border-line" aria-hidden="true" /> : null}
          <p className="mt-3 text-sm text-muted">{view.footer}</p>
          {ready ? null : null}
        </article>
      </div>
    </div>
  );
}

function label(key: string) {
  const map: Record<string, string> = {
    showUser: "اسم المستخدم",
    showPass: "كلمة المرور",
    showPrice: "السعر",
    showValidity: "الصلاحية",
    showProfile: "البروفايل",
    showQr: "رمز المستخدم",
  };
  return map[key] ?? key;
}
