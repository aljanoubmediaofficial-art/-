import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, Modal, PageHead, messageOf, statusBadge, statusText, useLoad } from "@/components/kit";
import { formatWhen } from "@/lib/format";
import { connectRouter, listRouters, saveRouter } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/routers")({ component: RoutersPage });

const empty = {
  name: "",
  host: "",
  port: 8729,
  connType: "api-ssl" as "api" | "api-ssl",
  apiUser: "",
  password: "",
  rosHint: "",
  site: "",
  tower: "",
  notes: "",
  wanInterface: "",
};

function RoutersPage() {
  const load = useCallback(() => listRouters(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [pending, setPending] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [trustFor, setTrustFor] = useState<{ id: string; fingerprint: string } | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    try {
      const name = form.name.trim() || form.host.trim();
      const saved = await saveRouter({ data: { ...form, name, port: Number(form.port) } });
      toast.success("حُفظ الراوتر. جارٍ أول اتصال.");
      setOpen(false);
      setForm(empty);
      await reload();
      if (form.host.trim()) await connect(saved.id);
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setPending(false);
    }
  }

  async function connect(id: string, fingerprint?: string) {
    setBusyId(id);
    try {
      const probe = await connectRouter({ data: { id, trust: fingerprint } });
      if (probe.needsTrust) {
        setTrustFor({ id, fingerprint: probe.fingerprint });
        toast.message("طابق البصمة. لم تُرسل كلمة المرور بعد.");
      } else if (probe.lab) {
        toast.message(probe.message);
      } else if (!probe.ok) {
        toast.error(probe.message);
      } else if (!probe.accepted) {
        toast.message(probe.message);
      } else {
        setTrustFor(null);
        toast.success(probe.message);
      }
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setBusyId(null);
    }
  }

  const routers = data?.routers ?? [];
  const live = routers.filter((router) => router.mode !== "lab");
  const lab = routers.filter((router) => router.mode === "lab");

  return (
    <div>
      <PageHead kicker="جلسة محفوظة، اتصال من الخادم" title="اتصال الراوترات">
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>راوتر جديد</button>
      </PageHead>
      <article className="panel mb-4 p-4 text-sm">
        <p className="font-semibold">مثل العناوين المحفوظة في WinBox، لا مثل البحث بالبث</p>
        <p className="mt-2 text-muted">
          اضغط «اتصال» على راوتر محفوظ. كلمة المرور تبقى في المنصة ولا تُعاد كتابتها. الاكتشاف التلقائي داخل الشبكة غير متاح من المتصفح، لأن البث المحلي لا يصل إلى خادم المنصة.
        </p>
        <p className="mt-2 text-muted">
          عنوان مثل 10.x أو 192.168.x يفشل من هذه النسخة إذا كان الخادم خارج شبكة الزهر نت. يلزم نفق أو عنوان يصل إليه الخادم، مع API-SSL على 8729.
        </p>
        <p className="mt-2">الحد: {data ? `${data.license.liveRouters} / ${data.license.routerLimit}` : "…"} راوتر حقيقي. المختبر لا يُحتسب ولا يُجرى له اتصال.</p>
      </article>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="mb-3 text-danger">{error}</p> : null}
      <h2 className="mb-3 font-semibold">محفوظ للاتصال</h2>
      {live.length === 0 ? (
        <p className="panel mb-4 px-4 py-6 text-sm text-muted">لا راوتر حقيقي بعد. أضف CCR2116 بعنوان يصل إليه الخادم، ثم اضغط اتصال.</p>
      ) : null}
      <div className="space-y-3">
        {live.map((router) => (
          <article key={router.id} className="panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-semibold">{router.name}</p>
                <p className="ltr mt-1 text-sm text-muted">{router.connType} · {router.host || "بدون عنوان"}:{router.port} · {router.apiUser || "بدون مستخدم"}</p>
              </div>
              <span className={`badge ${router.report?.accepted ? "badge-ok" : statusBadge(router.status)}`}>
                {router.report?.accepted ? "LIVE" : router.report ? "غير مقبول" : statusText(router.status)}
              </span>
            </div>
            <p className="mt-2 text-sm text-muted">
              {router.model ? `${router.model} · ` : ""}
              {router.rosVersion ? `RouterOS ${router.rosVersion} · ` : "لم تُقرأ نسخة بعد · "}
              آخر قراءة {formatWhen(router.lastSeen)}
              {router.hasSecret ? "" : " · لا كلمة مرور محفوظة"}
            </p>
            {router.lastError ? <p className="mt-2 text-sm text-danger">{router.lastError}</p> : null}
            {trustFor?.id === router.id ? (
              <div className="mt-3 rounded-xl border border-line p-3">
                <p className="text-sm">بصمة الشهادة. طابقها مع الراوتر قبل إرسال الدخول.</p>
                <p className="ltr mt-2 break-all font-mono text-xs">{trustFor.fingerprint}</p>
                <button type="button" className="btn btn-primary mt-3" disabled={busyId === router.id} onClick={() => void connect(router.id, trustFor.fingerprint)}>
                  أثق بهذه البصمة وأتصل
                </button>
              </div>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" className="btn btn-primary" disabled={busyId === router.id || !router.host} onClick={() => void connect(router.id)}>
                {busyId === router.id ? "جارٍ الاتصال…" : "اتصال"}
              </button>
              <Link to="/routers/$routerId" params={{ routerId: router.id }} className="btn btn-ghost">التفاصيل والقراءات</Link>
            </div>
          </article>
        ))}
      </div>
      {lab.length > 0 ? (
        <>
          <h2 className="mb-3 mt-6 font-semibold">مختبر، بلا اتصال</h2>
          <div className="space-y-3">
            {lab.map((router) => (
              <Link key={router.id} to="/routers/$routerId" params={{ routerId: router.id }} className="panel block p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold">{router.name}</p>
                  <span className="badge badge-warn">LAB</span>
                </div>
                <p className="mt-1 text-sm text-muted">أرقام مخزّنة. زر الاتصال لا يُرسل شيئًا إلى جهاز.</p>
              </Link>
            ))}
          </div>
        </>
      ) : null}
      <Modal open={open} title="حفظ راوتر للاتصال" onClose={() => setOpen(false)}>
        <form className="grid gap-3" onSubmit={(e) => void submit(e)}>
          <Field label="الاسم في القائمة"><input className="field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="CCR2116" /></Field>
          <Field label="العنوان الذي يصل إليه الخادم">
            <input className="field ltr" required value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} placeholder="عنوان عام أو طرف النفق" />
          </Field>
          <Field label="مستخدم API"><input className="field ltr" required value={form.apiUser} onChange={(e) => setForm({ ...form, apiUser: e.target.value })} /></Field>
          <Field label="كلمة المرور"><input className="field ltr" required type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
          <Field label="منفذ الإنترنت للقياس"><input className="field ltr" value={form.wanInterface} onChange={(e) => setForm({ ...form, wanInterface: e.target.value })} placeholder="sfp-sfpplus1" /></Field>
          <details className="text-sm">
            <summary className="cursor-pointer text-muted">خيارات إضافية</summary>
            <div className="mt-3 grid gap-3">
              <Field label="نوع الاتصال">
                <select className="field" value={form.connType} onChange={(e) => setForm({ ...form, connType: e.target.value as "api" | "api-ssl", port: e.target.value === "api" ? 8728 : 8729 })}>
                  <option value="api-ssl">API-SSL 8729</option>
                  <option value="api">API 8728 غير مشفّر</option>
                </select>
              </Field>
              <Field label="الموقع"><input className="field" value={form.site} onChange={(e) => setForm({ ...form, site: e.target.value })} /></Field>
              <Field label="البرج"><input className="field" value={form.tower} onChange={(e) => setForm({ ...form, tower: e.target.value })} /></Field>
              <Field label="ملاحظة"><input className="field" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            </div>
          </details>
          <button className="btn btn-primary" disabled={pending} type="submit">{pending ? "جارٍ الحفظ…" : "حفظ واتصال"}</button>
        </form>
      </Modal>
    </div>
  );
}
