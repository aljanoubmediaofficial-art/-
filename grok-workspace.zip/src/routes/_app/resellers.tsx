import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, useLoad } from "@/components/kit";
import { formatMoney, formatWhen } from "@/lib/format";
import { listResellers, reverseWallet, saveReseller, walletMove } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/resellers")({ component: ResellersPage });

const KIND: Record<string, string> = {
  topup: "شحن",
  withdraw: "سحب",
  sale: "بيع",
  commission: "عمولة",
  reverse: "عكس",
};

function ResellersPage() {
  const load = useCallback(() => listResellers(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ name: "", phone: "", commissionPct: 10, notes: "" });
  const [move, setMove] = useState({ resellerId: "", kind: "topup" as "topup" | "withdraw" | "sale" | "commission", amount: 1000, note: "" });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveReseller({ data: form });
      toast.success("أُضيف البائع");
      setForm({ name: "", phone: "", commissionPct: 10, notes: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function post(event: React.FormEvent) {
    event.preventDefault();
    try {
      await walletMove({ data: move });
      toast.success("سُجّل القيد");
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function undo(id: string) {
    try {
      await reverseWallet({ data: { id } });
      toast.success("عُكس القيد بقيد جديد");
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="دفتر لا يُعدَّل بصمت" title="البائعون والمحافظ" />
      <p className="mb-4 text-sm text-muted">الشحن يزيد الرصيد، والبيع والسحب ينقصانه. التصحيح يتم بعكس القيد لا بحذفه.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="grid gap-3 lg:grid-cols-2">
        <form className="panel grid gap-3 p-4" onSubmit={(e) => void add(e)}>
          <h2 className="font-semibold">بائع جديد</h2>
          <Field label="الاسم"><input className="field" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="الهاتف"><input className="field ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label="نسبة العمولة"><input className="field ltr" type="number" min={0} max={80} value={form.commissionPct} onChange={(e) => setForm({ ...form, commissionPct: Number(e.target.value) })} /></Field>
          <Field label="ملاحظات"><input className="field" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
          <button className="btn btn-primary" type="submit">حفظ البائع</button>
        </form>
        <form className="panel grid gap-3 p-4" onSubmit={(e) => void post(e)}>
          <h2 className="font-semibold">قيد محفظة</h2>
          <Field label="البائع">
            <select className="field" required value={move.resellerId} onChange={(e) => setMove({ ...move, resellerId: e.target.value })}>
              <option value="">اختر</option>
              {(data?.resellers ?? []).map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}
            </select>
          </Field>
          <Field label="النوع">
            <select className="field" value={move.kind} onChange={(e) => setMove({ ...move, kind: e.target.value as typeof move.kind })}>
              <option value="topup">شحن رصيد</option>
              <option value="sale">خصم بيع</option>
              <option value="commission">عمولة</option>
              <option value="withdraw">سحب / تسوية</option>
            </select>
          </Field>
          <Field label="المبلغ"><input className="field ltr" type="number" min={1} value={move.amount} onChange={(e) => setMove({ ...move, amount: Number(e.target.value) })} /></Field>
          <Field label="بيان"><input className="field" value={move.note} onChange={(e) => setMove({ ...move, note: e.target.value })} /></Field>
          <button className="btn btn-primary" type="submit">تسجيل القيد</button>
        </form>
      </div>
      <div className="mt-4 space-y-3">
        {(data?.resellers ?? []).map((person) => (
          <article key={person.id} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{person.name}</h2>
              <span className={`badge ${person.active ? "badge-ok" : "badge-danger"}`}>{person.active ? "نشط" : "موقوف"}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{person.phone || "بدون هاتف"} · عمولة {person.commissionPct}٪</p>
            <p className="mt-2 text-lg font-semibold tabular-nums">{formatMoney(person.balance)}</p>
            {person.notes ? <p className="text-sm text-muted">{person.notes}</p> : null}
          </article>
        ))}
      </div>
      <h2 className="mb-3 mt-6 font-semibold">آخر القيود</h2>
      <div className="space-y-2">
        {(data?.entries ?? []).map((entry) => {
          const owner = data?.resellers.find((person) => person.id === entry.resellerId)?.name ?? "بائع";
          return (
            <div key={entry.id} className="panel flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
              <div>
                <p className="font-medium">{owner} · {KIND[entry.kind] ?? entry.kind}</p>
                <p className="text-muted">{entry.note || "بدون بيان"} · {formatWhen(entry.createdAt)}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="tabular-nums">{formatMoney(entry.amount)}</span>
                {entry.kind !== "reverse" && !data?.entries.some((item) => item.reversesId === entry.id) ? (
                  <button type="button" className="btn btn-ghost min-h-10" onClick={() => void undo(entry.id)}>عكس</button>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
