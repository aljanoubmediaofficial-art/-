import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusText, useLoad } from "@/components/kit";
import { formatWhen } from "@/lib/format";
import { closeTicket, listTickets, saveTicket } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/support")({ component: SupportPage });

function SupportPage() {
  const load = useCallback(() => listTickets(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ subject: "", body: "" });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveTicket({ data: form });
      toast.success("سُجّلت التذكرة في حسابك");
      setForm({ subject: "", body: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function close(id: string) {
    try {
      await closeTicket({ data: { id } });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="سجل محلي داخل حساب الشبكة" title="الدعم" />
      <p className="mb-4 text-sm text-muted">التذكرة تُحفظ عندك وتظهر في سجل العمليات. لا تُرسل إلى بريد خارجي من هذه النسخة.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel grid gap-3 p-4" onSubmit={(e) => void add(e)}>
        <Field label="الموضوع"><input className="field" required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></Field>
        <Field label="التفاصيل"><textarea className="field min-h-24" required value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></Field>
        <button className="btn btn-primary" type="submit">فتح تذكرة</button>
      </form>
      <div className="mt-4 space-y-3">
        {(data ?? []).map((ticket) => (
          <article key={ticket.id} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{ticket.subject}</h2>
              <span className="badge">{statusText(ticket.status)}</span>
            </div>
            <p className="mt-2 text-sm">{ticket.body}</p>
            <p className="mt-1 text-xs text-muted">{formatWhen(ticket.createdAt)}</p>
            {ticket.status !== "closed" ? (
              <button type="button" className="btn btn-ghost mt-3" onClick={() => void close(ticket.id)}>إغلاق</button>
            ) : null}
          </article>
        ))}
      </div>
    </div>
  );
}
