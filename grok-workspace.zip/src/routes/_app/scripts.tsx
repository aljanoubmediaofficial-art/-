import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, useLoad } from "@/components/kit";
import { listRouters, listScripts, runScript, saveScript } from "@/lib/noc/api";
import { formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/scripts")({ component: ScriptsPage });

function ScriptsPage() {
  const load = useCallback(() => listScripts(), []);
  const { data, error, loading, reload } = useLoad(load);
  const routers = useLoad(useCallback(() => listRouters(), []));
  const [routerId, setRouterId] = useState("");
  const [name, setName] = useState("");
  const [body, setBody] = useState("");

  async function run(id: string) {
    try {
      const result = await runScript({ data: { id, routerId: routerId || routers.data?.routers[0]?.id || "" } });
      if (result.ok) toast.success(result.message);
      else toast.message(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await saveScript({ data: { name, body } });
      toast.success(result.message);
      setName("");
      setBody("");
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="قائمة معتمدة فقط" title="السكربتات" />
      <Field label="الراوتر المستهدف">
        <select className="field" value={routerId} onChange={(e) => setRouterId(e.target.value)}>
          {(routers.data?.routers ?? []).map((router) => (
            <option key={router.id} value={router.id}>{router.name}</option>
          ))}
        </select>
      </Field>
      {loading && !data ? <p className="mt-4 text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="mt-4 space-y-3">
        {(data?.builtin ?? []).map((script) => (
          <article key={script.id} className="panel p-4">
            <p className="font-semibold">{script.name}</p>
            <p className="text-sm text-muted">الخطورة: {script.danger}</p>
            <pre className="mt-2 whitespace-pre-wrap text-sm text-muted">{script.body}</pre>
            <button type="button" className="btn btn-primary mt-3" onClick={() => void run(script.id)}>تنفيذ بعد المراجعة</button>
          </article>
        ))}
        {(data?.drafts ?? []).map((script) => (
          <article key={script.id} className="panel p-4">
            <p className="font-semibold">{script.name}</p>
            <p className="text-sm text-warn">بانتظار المراجعة — التشغيل مرفوض</p>
            <pre className="mt-2 whitespace-pre-wrap text-sm text-muted">{script.body}</pre>
          </article>
        ))}
      </div>
      <form className="panel mt-4 grid gap-3 p-4" onSubmit={(e) => void save(e)}>
        <h2 className="font-semibold">سكربت للمراجعة</h2>
        <Field label="الاسم"><input className="field" value={name} onChange={(e) => setName(e.target.value)} required /></Field>
        <Field label="النص"><textarea className="field min-h-28" value={body} onChange={(e) => setBody(e.target.value)} required /></Field>
        <button className="btn btn-ghost" type="submit">حفظ دون تشغيل</button>
      </form>
      <section className="mt-4">
        <h2 className="mb-2 font-semibold">سجل التنفيذ</h2>
        <div className="space-y-2">
          {(data?.runs ?? []).map((runItem, index) => (
            <p key={`${runItem.createdAt}-${index}`} className="text-sm text-muted">
              {formatWhen(runItem.createdAt)} · {runItem.name} · {runItem.status} · {runItem.detail}
            </p>
          ))}
        </div>
      </section>
    </div>
  );
}
