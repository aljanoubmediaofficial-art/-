import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, useLoad } from "@/components/kit";
import { formatInt } from "@/lib/format";
import { listUm, saveUm, setUmDisabled } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/userman")({ component: UserManagerPage });

function UserManagerPage() {
  const load = useCallback(() => listUm(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ username: "", profile: "", credit: 0, limitation: "", note: "" });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await saveUm({ data: form });
      toast.success(result.message);
      setForm({ username: "", profile: "", credit: 0, limitation: "", note: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function toggle(id: string, disabled: boolean) {
    try {
      await setUmDisabled({ data: { id, disabled } });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="سجل المنصة وليس جلسة الراوتر" title="يوزر منجر" />
      <p className="mb-4 text-sm text-muted">الحسابات هنا دفتر تشغيلي. لا تُنشأ على الراوتر حتى يتوفر User Manager متوافق ويُزامَن صراحة.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel grid gap-3 p-4 sm:grid-cols-2" onSubmit={(e) => void add(e)}>
        <Field label="المستخدم"><input className="field ltr" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></Field>
        <Field label="البروفايل"><input className="field" value={form.profile} onChange={(e) => setForm({ ...form, profile: e.target.value })} /></Field>
        <Field label="الرصيد"><input className="field ltr" type="number" min={0} value={form.credit} onChange={(e) => setForm({ ...form, credit: Number(e.target.value) })} /></Field>
        <Field label="الحد"><input className="field" value={form.limitation} onChange={(e) => setForm({ ...form, limitation: e.target.value })} /></Field>
        <Field label="ملاحظة"><input className="field sm:col-span-2" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></Field>
        <button className="btn btn-primary sm:col-span-2" type="submit">حفظ الحساب</button>
      </form>
      <div className="mt-4 space-y-3">
        {(data ?? []).map((user) => (
          <article key={user.id} className="panel flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <h2 className="font-semibold">{user.username}</h2>
              <p className="text-sm text-muted">{user.profile || "بدون بروفايل"} · رصيد {formatInt(user.credit)} · {user.limitation || "بدون حد"}</p>
              {user.note ? <p className="text-sm text-muted">{user.note}</p> : null}
            </div>
            <button type="button" className="btn btn-ghost" onClick={() => void toggle(user.id, !user.disabled)}>
              {user.disabled ? "تفعيل" : "تعطيل"}
            </button>
          </article>
        ))}
      </div>
    </div>
  );
}
