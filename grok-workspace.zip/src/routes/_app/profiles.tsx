import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, Modal, PageHead, messageOf, useLoad } from "@/components/kit";
import { listProfiles, saveProfile } from "@/lib/noc/api";
import { formatMoney } from "@/lib/format";

export const Route = createFileRoute("/_app/profiles")({ component: ProfilesPage });

function ProfilesPage() {
  const load = useCallback(() => listProfiles(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [edit, setEdit] = useState<null | {
    id: string;
    name: string;
    price: number;
    rateDown: string;
    rateUp: string;
    validity: string;
    sharedUsers: number;
    dataLimit: string;
    before: string;
  }>(null);
  const [preview, setPreview] = useState(false);

  async function apply() {
    if (!edit) return;
    try {
      const result = await saveProfile({
        data: {
          id: edit.id,
          price: Number(edit.price),
          rateDown: edit.rateDown,
          rateUp: edit.rateUp,
          validity: edit.validity,
          sharedUsers: Number(edit.sharedUsers),
          dataLimit: edit.dataLimit,
        },
      });
      toast.success(result.message);
      setEdit(null);
      setPreview(false);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="تعديل الحد فقط" title="البروفايلات والسرعات" />
      <p className="mb-4 text-sm text-muted">لا تُنشأ Simple Queue جديدة من هنا حتى لا تتعارض القواعد. القيمة المرسلة هي rate-limit بالشكل تحميل/رفع.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {(data ?? []).map((profile) => (
          <article key={profile.id} className="panel p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{profile.name}</p>
                <p className="text-sm text-muted">{profile.kind} · {profile.router} · {profile.mode === "lab" ? "مختبر" : "حقيقي"}</p>
              </div>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() =>
                  setEdit({
                    id: profile.id,
                    name: profile.name,
                    price: profile.price,
                    rateDown: profile.rateDown,
                    rateUp: profile.rateUp,
                    validity: profile.validity,
                    sharedUsers: profile.sharedUsers,
                    dataLimit: profile.dataLimit,
                    before: `${profile.rateDown}/${profile.rateUp}`,
                  })
                }
              >
                تعديل
              </button>
            </div>
            <p className="mt-2 text-sm tabular-nums">{profile.rateDown || "—"} / {profile.rateUp || "—"} · {formatMoney(profile.price)} · مشاركة {profile.sharedUsers}</p>
          </article>
        ))}
      </div>
      <Modal open={Boolean(edit)} title={edit?.name ?? ""} onClose={() => { setEdit(null); setPreview(false); }}>
        {edit ? (
          <div className="grid gap-3">
            <Field label="السعر"><input className="field ltr" type="number" value={edit.price} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} /></Field>
            <Field label="التحميل"><input className="field ltr" value={edit.rateDown} onChange={(e) => setEdit({ ...edit, rateDown: e.target.value })} /></Field>
            <Field label="الرفع"><input className="field ltr" value={edit.rateUp} onChange={(e) => setEdit({ ...edit, rateUp: e.target.value })} /></Field>
            <Field label="الصلاحية"><input className="field" value={edit.validity} onChange={(e) => setEdit({ ...edit, validity: e.target.value })} /></Field>
            <Field label="المشاركة"><input className="field ltr" type="number" value={edit.sharedUsers} onChange={(e) => setEdit({ ...edit, sharedUsers: Number(e.target.value) })} /></Field>
            <Field label="حد البيانات"><input className="field" value={edit.dataLimit} onChange={(e) => setEdit({ ...edit, dataLimit: e.target.value })} /></Field>
            {preview ? (
              <p className="rounded-xl bg-surface-2 p-3 text-sm">
                من <span className="ltr">{edit.before}</span> إلى <span className="ltr">{edit.rateDown}/{edit.rateUp}</span>
              </p>
            ) : null}
            <div className="grid grid-cols-2 gap-2">
              <button type="button" className="btn btn-ghost" onClick={() => setPreview(true)}>معاينة</button>
              <button type="button" className="btn btn-primary" onClick={() => void apply()} disabled={!preview}>تطبيق</button>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
