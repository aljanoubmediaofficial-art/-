import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { toast } from "sonner";
import { PageHead, messageOf, useLoad } from "@/components/kit";
import { ackAlert, listAlerts } from "@/lib/noc/api";
import { formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/alerts")({ component: AlertsPage });

function AlertsPage() {
  const load = useCallback(() => listAlerts(), []);
  const { data, error, loading, reload } = useLoad(load);
  return (
    <div>
      <PageHead title="التنبيهات" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {(data ?? []).map((alert) => (
          <article key={alert.id} className="panel p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{alert.title}</p>
                <p className="text-sm text-muted">{alert.detail}</p>
                <p className="mt-1 text-xs text-muted">{formatWhen(alert.createdAt)} · {alert.origin === "lab" ? "مختبر" : "تشغيل"} · {alert.severity === "danger" ? "مرتفع" : "تحذير"}</p>
              </div>
              {alert.acked ? <span className="badge">أُغلق</span> : (
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={() => void ackAlert({ data: { id: alert.id } }).then(() => reload()).catch((err: unknown) => toast.error(messageOf(err)))}
                >
                  إغلاق
                </button>
              )}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
