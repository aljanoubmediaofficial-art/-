import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { PageHead, statusBadge, useLoad } from "@/components/kit";
import { formatWhen } from "@/lib/format";
import { diagnose } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/diagnose")({ component: DiagnosePage });

function DiagnosePage() {
  const load = useCallback(() => diagnose(), []);
  const { data, error, loading, reload } = useLoad(load);
  return (
    <div>
      <PageHead kicker="أدلة من السجل لا سبب مؤكد" title="البحث عن المشاكل">
        <button type="button" className="btn btn-primary" onClick={() => void reload()}>إعادة الفحص</button>
      </PageHead>
      <p className="mb-4 text-sm text-muted">
        الفحص يقرأ الراوترات والتنبيهات والاشتراكات والمصادر المخزّنة. لا يشغّل ping على الإنترنت ولا يغيّر الإعدادات.
        {data ? ` آخر فحص ${formatWhen(data.generatedAt)}. راوترات حقيقية: ${data.liveRouters}.` : ""}
      </p>
      {loading && !data ? <p className="text-muted">جاري الفحص…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {(data?.findings ?? []).map((item) => (
          <article key={`${item.title}-${item.evidence}`} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{item.title}</h2>
              <span className={`badge ${statusBadge(item.severity === "ok" ? "online" : item.severity)}`}>
                {item.severity === "danger" ? "مرتفع" : item.severity === "warn" ? "تحذير" : "سليم"}
              </span>
            </div>
            <p className="mt-2 text-sm">{item.evidence}</p>
            <p className="mt-2 text-sm text-muted">{item.action}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
