import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { PageHead, useLoad } from "@/components/kit";
import { listAudit } from "@/lib/noc/api";
import { formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/audit")({ component: AuditPage });

function AuditPage() {
  const load = useCallback(() => listAudit(), []);
  const { data, error, loading } = useLoad(load);
  return (
    <div>
      <PageHead kicker="لا يُحذف ولا يُعدَّل" title="سجل العمليات" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-2">
        {(data ?? []).map((row, index) => (
          <article key={`${row.createdAt}-${index}`} className="panel px-4 py-3 text-sm">
            <p className="font-semibold">{row.action}</p>
            <p className="text-muted">{row.detail || row.target}</p>
            <p className="text-xs text-muted">{formatWhen(row.createdAt)}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
