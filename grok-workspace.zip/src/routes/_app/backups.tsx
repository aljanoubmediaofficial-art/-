import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { PageHead, messageOf, useLoad } from "@/components/kit";
import { createBackup, downloadBackup, explainRestore, listBackups, listRouters } from "@/lib/noc/api";
import { formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/backups")({ component: BackupsPage });

function BackupsPage() {
  const load = useCallback(() => listBackups(), []);
  const { data, error, loading, reload } = useLoad(load);
  const routers = useLoad(useCallback(() => listRouters(), []));
  const [routerId, setRouterId] = useState("");

  async function make() {
    try {
      const result = await createBackup({ data: { routerId: routerId || routers.data?.routers[0]?.id || "" } });
      toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function download(id: string, name: string) {
    try {
      const file = await downloadBackup({ data: { id } });
      const blob = new Blob([file.body], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = file.filename || `${name}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="ملف المختبر مشفّر" title="النسخ الاحتياطي" />
      <div className="mb-4 grid gap-3 sm:grid-cols-[1fr_auto]">
        <select className="field" value={routerId} onChange={(e) => setRouterId(e.target.value)}>
          {(routers.data?.routers ?? []).map((router) => (
            <option key={router.id} value={router.id}>{router.name}</option>
          ))}
        </select>
        <button type="button" className="btn btn-primary" onClick={() => void make()}>إنشاء</button>
      </div>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {(data ?? []).map((backup) => (
          <article key={backup.id} className="panel p-4 text-sm">
            <p className="font-semibold">{backup.name}</p>
            <p className="text-muted">{backup.router} · {backup.detail} · {formatWhen(backup.createdAt)}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {backup.downloadable ? (
                <button type="button" className="btn btn-ghost" onClick={() => void download(backup.id, backup.name)}>تنزيل</button>
              ) : null}
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => void explainRestore({ data: { id: backup.id } }).then((result) => toast.message(result.message)).catch((err: unknown) => toast.error(messageOf(err)))}
              >
                فحص الاستعادة
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
