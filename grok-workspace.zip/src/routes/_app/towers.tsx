import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusBadge, statusText, useLoad } from "@/components/kit";
import { saveAntenna, saveTower } from "@/lib/noc/desk";
import { listTopology } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/towers")({ component: TowersPage });

function TowersPage() {
  const load = useCallback(() => listTopology(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [tower, setTower] = useState({ name: "", site: "", lat: "", lng: "", routerId: "", power: "", notes: "" });
  const [antenna, setAntenna] = useState({ towerId: "", name: "", model: "", ip: "", frequency: "", channel: "" });

  const nameOf = (kind: string, id: string) => {
    if (!data) return id;
    if (kind === "router") return data.routers.find((item) => item.id === id)?.name ?? id;
    if (kind === "tower") return data.towers.find((item) => item.id === id)?.name ?? id;
    if (kind === "antenna") return data.antennas.find((item) => item.id === id)?.name ?? id;
    if (kind === "source") return data.sources.find((item) => item.id === id)?.name ?? id;
    return id;
  };

  async function addTower(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveTower({ data: tower });
      toast.success("أُضيف البرج");
      setTower({ name: "", site: "", lat: "", lng: "", routerId: "", power: "", notes: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function addAntenna(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveAntenna({ data: antenna });
      toast.success("أُضيفت الانتينا ووُبطت بالبرج");
      setAntenna({ ...antenna, name: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="علاقات مسجّلة فقط" title="الأبراج والانتينات" />
      <p className="mb-4 text-sm text-muted">هذا مخطط ربط منطقي. الإحداثيات النصية ليست خريطة، ولا يُرسم رابط لم يُسجَّل.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="grid gap-3 lg:grid-cols-2">
        <form className="panel grid gap-3 p-4" onSubmit={(e) => void addTower(e)}>
          <h2 className="font-semibold">برج جديد</h2>
          <Field label="الاسم"><input className="field" required value={tower.name} onChange={(e) => setTower({ ...tower, name: e.target.value })} /></Field>
          <Field label="الموقع"><input className="field" value={tower.site} onChange={(e) => setTower({ ...tower, site: e.target.value })} /></Field>
          <Field label="الراوتر">
            <select className="field" value={tower.routerId} onChange={(e) => setTower({ ...tower, routerId: e.target.value })}>
              <option value="">بدون ربط</option>
              {(data?.routers ?? []).map((router) => <option key={router.id} value={router.id}>{router.name}</option>)}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="خط العرض"><input className="field ltr" value={tower.lat} onChange={(e) => setTower({ ...tower, lat: e.target.value })} /></Field>
            <Field label="خط الطول"><input className="field ltr" value={tower.lng} onChange={(e) => setTower({ ...tower, lng: e.target.value })} /></Field>
          </div>
          <Field label="الطاقة"><input className="field" value={tower.power} onChange={(e) => setTower({ ...tower, power: e.target.value })} /></Field>
          <button className="btn btn-primary" type="submit">حفظ البرج</button>
        </form>
        <form className="panel grid gap-3 p-4" onSubmit={(e) => void addAntenna(e)}>
          <h2 className="font-semibold">انتينا</h2>
          <Field label="البرج">
            <select className="field" required value={antenna.towerId} onChange={(e) => setAntenna({ ...antenna, towerId: e.target.value })}>
              <option value="">اختر</option>
              {(data?.towers ?? []).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
            </select>
          </Field>
          <Field label="الاسم"><input className="field" required value={antenna.name} onChange={(e) => setAntenna({ ...antenna, name: e.target.value })} /></Field>
          <Field label="الموديل"><input className="field" value={antenna.model} onChange={(e) => setAntenna({ ...antenna, model: e.target.value })} /></Field>
          <Field label="IP"><input className="field ltr" value={antenna.ip} onChange={(e) => setAntenna({ ...antenna, ip: e.target.value })} /></Field>
          <Field label="التردد"><input className="field ltr" value={antenna.frequency} onChange={(e) => setAntenna({ ...antenna, frequency: e.target.value })} /></Field>
          <button className="btn btn-primary" type="submit">حفظ الانتينا</button>
        </form>
      </div>
      <div className="mt-4 space-y-3">
        {(data?.links ?? []).map((link, index) => (
          <div key={`${link.fromId}-${link.toId}-${index}`} className="panel px-4 py-3 text-sm">
            {nameOf(link.fromKind, link.fromId)} ← {nameOf(link.toKind, link.toId)}
          </div>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {(data?.towers ?? []).map((item) => (
          <article key={item.id} className="panel p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">{item.name}</h2>
              <span className={`badge ${statusBadge(item.status)}`}>{statusText(item.status)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{item.site} · طاقة: {item.power || "غير مسجّلة"}</p>
            <p className="text-sm text-muted">إحداثيات: {item.lat && item.lng ? `${item.lat} , ${item.lng}` : "غير مسجّلة"}</p>
            <div className="mt-3 space-y-2">
              {(data?.antennas ?? []).filter((row) => row.towerId === item.id).map((row) => (
                <div key={row.id} className="rounded-xl bg-surface-2 px-3 py-2 text-sm">
                  <p className="font-medium">{row.name}</p>
                  <p className="text-muted">
                    {row.model || "موديل غير معروف"} · {row.frequency || "تردد غير مسجّل"} · عملاء {row.clients ?? "—"} · إشارة {row.signal === null ? "غير متاحة" : `${row.signal} dBm`} · CCQ {row.ccq === null ? "غير متاح" : `${row.ccq}٪`}
                  </p>
                </div>
              ))}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
