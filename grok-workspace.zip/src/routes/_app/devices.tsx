import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { PageHead, statusBadge, statusText, useLoad } from "@/components/kit";
import { listDevices } from "@/lib/noc/api";
import { formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/devices")({ component: DevicesPage });

function DevicesPage() {
  const load = useCallback(() => listDevices(), []);
  const { data, error, loading } = useLoad(load);
  const [id, setId] = useState<string | null>(null);
  const selected = (data ?? []).find((device) => device.id === id) ?? null;
  return (
    <div>
      <PageHead kicker="ما ظهر من الجيران واللاسلكي" title="الأجهزة" />
      <p className="mb-4 text-sm text-muted">القيمة غير المتاحة تبقى فارغة. لا تُعرض صفراً كأن الجهاز أبلغ بها.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-2">
        {(data ?? []).map((device) => (
          <button key={device.id} type="button" className="panel w-full p-4 text-start" onClick={() => setId(device.id)}>
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold">{device.name}</p>
              <span className={`badge ${statusBadge(device.status)}`}>{statusText(device.status)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{device.kind} · {device.vendor || "شركة غير معروفة"} · {device.source}</p>
          </button>
        ))}
      </div>
      {selected ? (
        <article className="panel mt-4 p-4 text-sm">
          <h2 className="font-semibold">{selected.name}</h2>
          <p className="mt-2">الموديل: {selected.model || "غير معروف"}</p>
          <p className="ltr">IP {selected.ip || "—"} · MAC {selected.mac || "—"}</p>
          <p>الإشارة: {selected.signal === null ? "غير متاحة" : `${selected.signal} dBm`}</p>
          <p>الضجيج: {selected.noise === null ? "غير متاح" : `${selected.noise} dBm`}</p>
          <p>CCQ: {selected.ccq === null ? "غير متاح" : `${selected.ccq}٪`}</p>
          <p>آخر ظهور: {formatWhen(selected.lastSeen)}</p>
          <p>البرج: {selected.tower || "غير مربوط"}</p>
          <p className="text-muted">المصدر: {selected.source} · {selected.origin === "lab" ? "سجل مختبر" : "مزامنة"}</p>
        </article>
      ) : null}
    </div>
  );
}
