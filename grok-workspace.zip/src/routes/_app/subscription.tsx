import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { PageHead, useLoad } from "@/components/kit";
import { getWorkspace } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/subscription")({ component: SubscriptionPage });

const PLANS: Record<string, string> = {
  trial: "تجريبية",
  month: "شهرية",
  quarter: "ربع سنوية",
  half: "نصف سنوية",
  year: "سنوية",
  custom: "مخصصة",
};

function SubscriptionPage() {
  const load = useCallback(() => getWorkspace(), []);
  const { data, error, loading } = useLoad(load);
  const license = data?.license;
  return (
    <div>
      <PageHead kicker="ترخيص هذه الشبكة" title="الاشتراك" />
      <p className="mb-4 text-sm text-muted">
        هذه شاشة ترخيص الحساب الحالي. لوحة كل عملاء المنصة لا تُعرض هنا حتى لا تختلط بيانات الشبكات.
      </p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      {license ? (
        <article className="panel space-y-2 p-4 text-sm">
          <p>الباقة: {PLANS[license.plan] ?? license.plan}</p>
          <p>الحالة: {license.status === "active" ? "فعّالة" : "موقوفة"}</p>
          <p>البداية: <span className="ltr">{license.startedOn}</span></p>
          <p>تنتهي التجربة / التجديد: <span className="ltr">{license.renewsOn}</span></p>
          <p>الراوترات الحقيقية: {license.liveRouters} من {license.routerLimit}</p>
          <p>المستخدمون الإداريون حتى: {license.staffLimit}</p>
          <p>مساحة النسخ: {license.backupMb} م.ب</p>
          <p className="text-muted">عند تعذر التحقق لا تُغلق شاشة المراقبة. إيقاف الباقة يوقف أوامر التعديل فقط.</p>
        </article>
      ) : null}
    </div>
  );
}
