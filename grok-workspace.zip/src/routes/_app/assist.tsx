import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHead, messageOf, statusBadge } from "@/components/kit";
import { assist } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/assist")({ component: AssistPage });

const PRESETS = ["لماذا المعالج مرتفع؟", "ما الراوترات المنقطعة؟", "من تأخر اشتراكه؟", "هل الإشارة ضعيفة؟"];

type Report = Awaited<ReturnType<typeof assist>>;

function AssistPage() {
  const [question, setQuestion] = useState(PRESETS[0]);
  const [report, setReport] = useState<Report | null>(null);
  const [busy, setBusy] = useState(false);

  async function ask(text: string) {
    setBusy(true);
    try {
      const next = await assist({ data: { question: text } });
      setReport(next);
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHead kicker="يقرأ سجلاتك فقط" title="مساعد الزهر" />
      <p className="mb-4 text-sm text-muted">لا يطبّق تغييراً على الشبكة. إن لم تكفِ الأدلة يقول ذلك صراحة.</p>
      <div className="mb-3 flex flex-wrap gap-2">
        {PRESETS.map((item) => (
          <button key={item} type="button" className="btn btn-ghost" onClick={() => { setQuestion(item); void ask(item); }}>
            {item}
          </button>
        ))}
      </div>
      <form className="panel grid gap-3 p-4" onSubmit={(e) => { e.preventDefault(); void ask(question); }}>
        <textarea className="field min-h-24" value={question} onChange={(e) => setQuestion(e.target.value)} />
        <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? "يحلل…" : "حلّل"}</button>
      </form>
      {report ? (
        <div className="mt-4 space-y-3">
          <p className="text-sm text-muted">{report.note}</p>
          {report.findings.map((item) => (
            <article key={`${item.title}-${item.evidence}`} className="panel p-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="font-semibold">{item.title}</h2>
                <span className={`badge ${statusBadge(item.severity === "ok" ? "online" : item.severity)}`}>
                  {item.severity === "danger" ? "مرتفع" : item.severity === "warn" ? "تحذير" : "ملاحظة"}
                </span>
              </div>
              <p className="mt-2 text-sm">{item.evidence}</p>
              <p className="mt-2 text-sm text-muted">{item.action}</p>
            </article>
          ))}
        </div>
      ) : null}
    </div>
  );
}
