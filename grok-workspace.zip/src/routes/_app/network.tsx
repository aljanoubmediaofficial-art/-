import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, useLoad } from "@/components/kit";
import { listNetwork, saveNetNote } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/network")({ component: NetworkPage });

const AREAS = [
  ["firewall", "جدار ناري"],
  ["nat", "NAT"],
  ["dhcp", "DHCP"],
  ["dns", "DNS"],
  ["queue", "السرعات"],
  ["route", "التوجيه"],
  ["vlan", "VLAN"],
  ["bridge", "Bridge"],
  ["vpn", "VPN"],
] as const;

function NetworkPage() {
  const load = useCallback(() => listNetwork(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ area: "firewall", name: "", detail: "" });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await saveNetNote({ data: form });
      toast.success(result.message);
      setForm({ ...form, name: "", detail: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  const label = (area: string) => AREAS.find((item) => item[0] === area)?.[1] ?? area;

  return (
    <div>
      <PageHead kicker="قراءة وسجل، بلا تطبيق صامت" title="أدوات الشبكة" />
      <p className="mb-4 text-sm text-muted">الواجهات الظاهرة أتت من آخر مزامنة أو من المختبر. الملاحظة لا تُرسل أمراً إلى الراوتر.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-2">
        {(data?.interfaces ?? []).map((item) => (
          <article key={`${item.router}-${item.name}`} className="panel px-4 py-3 text-sm">
            <p className="font-medium">{item.router} · {item.name}</p>
            <p className="text-muted">{item.kind || "نوع غير معروف"} · {item.running ? "يعمل" : "متوقف"} · {item.comment || "بدون تعليق"} · {item.origin === "lab" ? "مختبر" : "سجل"}</p>
          </article>
        ))}
        {data && data.interfaces.length === 0 ? <p className="text-sm text-muted">لا واجهات مسجّلة.</p> : null}
      </div>
      <form className="panel mt-4 grid gap-3 p-4" onSubmit={(e) => void add(e)}>
        <h2 className="font-semibold">ملاحظة إعداد</h2>
        <Field label="القسم">
          <select className="field" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })}>
            {AREAS.map(([value, name]) => <option key={value} value={value}>{name}</option>)}
          </select>
        </Field>
        <Field label="الاسم"><input className="field" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="التفصيل"><textarea className="field min-h-20" value={form.detail} onChange={(e) => setForm({ ...form, detail: e.target.value })} /></Field>
        <button className="btn btn-primary" type="submit">حفظ الملاحظة</button>
      </form>
      <div className="mt-4 space-y-2">
        {(data?.notes ?? []).map((note) => (
          <article key={note.id} className="panel px-4 py-3 text-sm">
            <p className="font-medium">{label(note.area)} · {note.name}</p>
            <p className="text-muted">{note.detail}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
