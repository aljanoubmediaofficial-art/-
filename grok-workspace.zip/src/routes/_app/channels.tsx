import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusText, useLoad } from "@/components/kit";
import { formatWhen } from "@/lib/format";
import { holdWhatsapp, listChannels, saveChannels, testTelegram } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/channels")({ component: ChannelsPage });

function ChannelsPage() {
  const load = useCallback(() => listChannels(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ token: "", chat: "", waPhone: "", waNote: "" });
  const [msg, setMsg] = useState({ to: "", body: "" });
  const [ready, setReady] = useState(false);

  const chat = ready ? form.chat : (data?.chat ?? "");
  const waPhone = ready ? form.waPhone : (data?.waPhone ?? "");
  const waNote = ready ? form.waNote : (data?.waNote ?? "");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveChannels({ data: { token: form.token, chat, waPhone, waNote } });
      toast.success("حُفظت القنوات. التوكن مشفّر ولا يُعرض مرة أخرى.");
      setForm({ ...form, token: "" });
      setReady(true);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function ping(send: boolean) {
    try {
      const result = await testTelegram({ data: { send } });
      toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function hold(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await holdWhatsapp({ data: msg });
      toast.success(result.message);
      setMsg({ to: "", body: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="تيليجرام يُختبر فعلياً" title="القنوات" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel grid gap-3 p-4" onSubmit={(e) => void save(e)}>
        <p className="text-sm text-muted">
          {data?.hasToken ? `توكن محفوظ${data.botName ? ` · ${data.botName}` : ""}. اترك الخانة فارغة للإبقاء عليه.` : "لا يوجد توكن محفوظ."}
        </p>
        <Field label="توكن البوت">
          <input className="field ltr" type="password" autoComplete="off" value={form.token} onChange={(e) => setForm({ ...form, token: e.target.value })} placeholder="123456:ABC..." />
        </Field>
        <Field label="معرّف المحادثة">
          <input className="field ltr" value={chat} onChange={(e) => { setReady(true); setForm({ ...form, chat: e.target.value }); }} />
        </Field>
        <Field label="هاتف واتساب للأعمال">
          <input className="field ltr" value={waPhone} onChange={(e) => { setReady(true); setForm({ ...form, waPhone: e.target.value }); }} />
        </Field>
        <Field label="قالب واتساب المعتمد">
          <textarea className="field min-h-20" value={waNote} onChange={(e) => { setReady(true); setForm({ ...form, waNote: e.target.value }); }} />
        </Field>
        <div className="flex flex-wrap gap-2">
          <button className="btn btn-primary" type="submit">حفظ</button>
          <button className="btn btn-ghost" type="button" onClick={() => void ping(false)}>فحص البوت</button>
          <button className="btn btn-ghost" type="button" onClick={() => void ping(true)}>إرسال اختبار</button>
        </div>
      </form>
      <form className="panel mt-4 grid gap-3 p-4" onSubmit={(e) => void hold(e)}>
        <h2 className="font-semibold">رسالة واتساب محجوزة</h2>
        <p className="text-sm text-muted">تُحفظ في السجل بحالة «لم تُرسل». لا يُزعم الإرسال دون مزود.</p>
        <Field label="إلى"><input className="field ltr" required value={msg.to} onChange={(e) => setMsg({ ...msg, to: e.target.value })} /></Field>
        <Field label="النص"><textarea className="field min-h-20" required value={msg.body} onChange={(e) => setMsg({ ...msg, body: e.target.value })} /></Field>
        <button className="btn btn-primary" type="submit">حجز الرسالة</button>
      </form>
      <div className="mt-4 space-y-2">
        {(data?.outbox ?? []).map((item) => (
          <article key={item.id} className="panel px-4 py-3 text-sm">
            <p className="font-medium">{item.channel === "telegram" ? "تيليجرام" : "واتساب"} · {item.to} · {statusText(item.status)}</p>
            <p className="text-muted">{item.body}</p>
            <p className="text-xs text-muted">{item.detail} · {formatWhen(item.createdAt)}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
