import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusBadge, statusText, useLoad } from "@/components/kit";
import { formatInt, formatMoney } from "@/lib/format";
import { saveSource } from "@/lib/noc/desk";
import { listTopology } from "@/lib/noc/api";

export const Route = createFileRoute("/_app/sources")({ component: SourcesPage });

function SourcesPage() {
  const load = useCallback(() => listTopology(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({
    name: "",
    kind: "Starlink",
    iface: "",
    contracted: "",
    cost: null as number | null,
    routerId: "",
    note: "",
  });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveSource({ data: form });
      toast.success("أُضيف المصدر. حالته تبقى غير مفحوصة حتى تُقاس.");
      setForm({ name: "", kind: "Starlink", iface: "", contracted: "", cost: null, routerId: "", note: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="قياس الخط لا لوحة المزود" title="مصادر الإنترنت" />
      <p className="mb-4 text-sm text-muted">ستارلينك يُراقب كمنفذ وبنج وفقد. لا تُقرأ بيانات تطبيق ستارلينك نفسه، ولا يُعرض قياس غير موجود على أنه صفر.</p>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel mb-4 grid gap-3 p-4 sm:grid-cols-2" onSubmit={(e) => void add(e)}>
        <Field label="الاسم"><input className="field" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="النوع">
          <select className="field" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            <option value="Starlink">ستارلينك</option>
            <option value="Fiber">فايبر</option>
            <option value="Wireless">لاسلكي</option>
            <option value="DSL">DSL</option>
            <option value="Other">آخر</option>
          </select>
        </Field>
        <Field label="المنفذ"><input className="field ltr" value={form.iface} onChange={(e) => setForm({ ...form, iface: e.target.value })} /></Field>
        <Field label="السرعة المتعاقد عليها"><input className="field ltr" value={form.contracted} onChange={(e) => setForm({ ...form, contracted: e.target.value })} placeholder="200/30" /></Field>
        <Field label="التكلفة"><input className="field ltr" type="number" min={0} value={form.cost ?? ""} onChange={(e) => setForm({ ...form, cost: e.target.value === "" ? null : Number(e.target.value) })} /></Field>
        <Field label="الراوتر">
          <select className="field" value={form.routerId} onChange={(e) => setForm({ ...form, routerId: e.target.value })}>
            <option value="">بدون ربط</option>
            {(data?.routers ?? []).map((router) => <option key={router.id} value={router.id}>{router.name}</option>)}
          </select>
        </Field>
        <Field label="ملاحظة"><input className="field sm:col-span-2" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></Field>
        <button className="btn btn-primary sm:col-span-2" type="submit">إضافة المصدر</button>
      </form>
      <div className="space-y-3">
        {(data?.sources ?? []).map((source) => (
          <article key={source.id} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{source.name}</h2>
              <span className={`badge ${statusBadge(source.status)}`}>{statusText(source.status)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{source.kind} · {source.iface || "منفذ غير محدد"} · تعاقد {source.contracted || "—"}</p>
            <p className="mt-2 text-sm tabular-nums">
              تأخير {source.latencyMs === null ? "غير مقاس" : `${formatInt(source.latencyMs)} ms`} · فقد {source.loss ?? "غير مقاس"} · تحميل {source.downloadMbps === null ? "غير مقاس" : formatInt(source.downloadMbps)} · رفع {source.uploadMbps === null ? "غير مقاس" : formatInt(source.uploadMbps)}
            </p>
            <p className="mt-1 text-sm">التكلفة: {source.cost === null ? "غير مسجّلة" : formatMoney(source.cost)}</p>
            {source.note ? <p className="mt-2 text-xs text-muted">{source.note}</p> : null}
          </article>
        ))}
      </div>
    </div>
  );
}
