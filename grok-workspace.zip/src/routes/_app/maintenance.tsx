import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusBadge, statusText, useLoad } from "@/components/kit";
import { formatWhen } from "@/lib/format";
import { listJobs, saveJob, setJobStatus } from "@/lib/noc/desk";

export const Route = createFileRoute("/_app/maintenance")({ component: MaintenancePage });

const NEXT = ["open", "assigned", "done", "closed"] as const;

function MaintenancePage() {
  const load = useCallback(() => listJobs(), []);
  const { data, error, loading, reload } = useLoad(load);
  const [form, setForm] = useState({ title: "", site: "", tower: "", assignee: "", notes: "" });

  async function add(event: React.FormEvent) {
    event.preventDefault();
    try {
      await saveJob({ data: form });
      toast.success("فُتح البلاغ");
      setForm({ title: "", site: "", tower: "", assignee: "", notes: "" });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function move(id: string, status: (typeof NEXT)[number]) {
    try {
      await setJobStatus({ data: { id, status } });
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker="البلاغ حتى الإغلاق" title="الصيانة والفنيون" />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <form className="panel grid gap-3 p-4 sm:grid-cols-2" onSubmit={(e) => void add(e)}>
        <Field label="عنوان العطل"><input className="field" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
        <Field label="الموقع"><input className="field" value={form.site} onChange={(e) => setForm({ ...form, site: e.target.value })} /></Field>
        <Field label="البرج أو الانتينا"><input className="field" value={form.tower} onChange={(e) => setForm({ ...form, tower: e.target.value })} /></Field>
        <Field label="الفني"><input className="field" value={form.assignee} onChange={(e) => setForm({ ...form, assignee: e.target.value })} /></Field>
        <Field label="الملاحظات"><textarea className="field min-h-20 sm:col-span-2" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
        <button className="btn btn-primary sm:col-span-2" type="submit">فتح بلاغ</button>
      </form>
      <div className="mt-4 space-y-3">
        {(data ?? []).map((job) => (
          <article key={job.id} className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">{job.title}</h2>
              <span className={`badge ${statusBadge(job.status)}`}>{statusText(job.status)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{job.site || "بدون موقع"} · {job.tower || "بدون برج"} · {job.assignee || "غير معيّن"}</p>
            {job.notes ? <p className="mt-2 text-sm">{job.notes}</p> : null}
            <p className="mt-1 text-xs text-muted">{formatWhen(job.createdAt)}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {NEXT.map((status) => (
                <button key={status} type="button" className="btn btn-ghost" disabled={job.status === status} onClick={() => void move(job.id, status)}>
                  {statusText(status)}
                </button>
              ))}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
