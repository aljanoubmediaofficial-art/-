import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { Field, PageHead, messageOf, statusText, useLoad } from "@/components/kit";
import { connectRouter, deleteRouter, getRouter, rebootRouter } from "@/lib/noc/api";
import { formatBytes, formatInt, formatWhen } from "@/lib/format";

export const Route = createFileRoute("/_app/routers/$routerId")({ component: RouterPage });

function RouterPage() {
  const { routerId } = Route.useParams();
  const load = useCallback(() => getRouter({ data: { id: routerId } }), [routerId]);
  const { data, error, loading, reload } = useLoad(load);
  const [trust, setTrust] = useState("");
  const [confirmName, setConfirmName] = useState("");
  const [pending, setPending] = useState(false);

  async function probe(fingerprint?: string) {
    setPending(true);
    try {
      const result = await connectRouter({ data: { id: routerId, trust: fingerprint } });
      if (result.needsTrust) {
        setTrust(result.fingerprint);
        toast.message("طابق البصمة قبل المتابعة");
      } else if (result.lab) toast.message(result.message);
      else if (!result.ok) toast.error(result.message);
      else if (!result.accepted) toast.message(result.message);
      else toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setPending(false);
    }
  }

  async function reboot() {
    setPending(true);
    try {
      const result = await rebootRouter({ data: { id: routerId, confirmName } });
      toast.success(result.message);
      setConfirmName("");
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setPending(false);
    }
  }

  async function remove() {
    if (!window.confirm("حذف ربط هذا الراوتر من المنصة؟")) return;
    try {
      await deleteRouter({ data: { id: routerId } });
      window.location.href = "/routers";
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  if (loading && !data) return <p className="text-muted">جاري التحميل…</p>;
  if (error && !data) return <p className="text-danger">{error}</p>;
  if (!data) return null;
  const router = data.router;
  return (
    <div>
      <PageHead kicker={router.mode === "lab" ? "LAB" : router.report?.accepted ? "LIVE" : "بانتظار قراءة مقبولة"} title={router.name}>
        <span className={`badge ${router.mode === "lab" ? "badge-warn" : router.report?.accepted ? "badge-ok" : "badge-danger"}`}>
          {router.mode === "lab" ? "LAB" : router.report?.accepted ? "LIVE" : "غير مقبول"}
        </span>
      </PageHead>
      <Acceptance router={router} />
      <section className="grid gap-3 md:grid-cols-2">
        <article className="panel p-4 text-sm">
          <Row k="الهوية" v={router.identity ?? "لم تُقرأ"} />
          <Row k="الموديل" v={router.model ?? "لم يُقرأ"} />
          <Row k="اللوحة" v={router.board ?? "لم تُقرأ"} />
          <Row k="RouterOS المقروء" v={router.rosVersion ?? "لم يُقرأ"} />
          <Row k="تلميح المالك" v={router.rosHint || "—"} />
          <Row k="التشغيل" v={router.uptime ?? "—"} />
          <Row k="المعالج" v={router.cpu === null ? "غير متاح" : `${formatInt(router.cpu)}٪`} />
          <Row k="الذاكرة" v={router.ram === null ? "غير متاحة" : `${formatInt(router.ram)}٪`} />
          <Row k="التخزين" v={router.storage === null ? "غير متاح" : `${formatInt(router.storage)}٪`} />
          <Row k="الحرارة" v={router.temperature ?? "غير مدعومة على هذه القراءة"} />
          <Row k="الجهد" v={router.voltage ?? "غير مدعوم على هذه القراءة"} />
          <Row k="آخر ظهور" v={formatWhen(router.lastSeen)} />
          <Row k="السرعة اللحظية" v={router.downloadMbps === null ? "حدّد منفذ الإنترنت ثم زامن" : `${formatInt(router.downloadMbps)} / ${formatInt(router.uploadMbps)} Mbps`} />
        </article>
        <article className="panel space-y-3 p-4">
          <p className="text-sm text-muted">{router.host ? `${router.connType} · ${router.host}:${router.port}` : "بدون عنوان اتصال"}</p>
          {router.lastError ? <p className="text-sm text-danger">{router.lastError}</p> : null}
          <button type="button" className="btn btn-primary w-full" disabled={pending} onClick={() => void probe()}>مزامنة / فحص</button>
          {trust ? (
            <div className="rounded-xl border border-line p-3">
              <p className="text-sm">بصمة SHA-256. لم تُرسل كلمة المرور بعد.</p>
              <p className="ltr mt-2 break-all font-mono text-xs">{trust}</p>
              <button type="button" className="btn btn-primary mt-3 w-full" disabled={pending} onClick={() => void probe(trust)}>
                أثق بهذه البصمة وأكمل
              </button>
            </div>
          ) : null}
          <Field label="اكتب اسم الراوتر لإعادة التشغيل">
            <input className="field" value={confirmName} onChange={(e) => setConfirmName(e.target.value)} />
          </Field>
          <button type="button" className="btn btn-danger w-full" disabled={pending} onClick={() => void reboot()}>إعادة التشغيل</button>
          <button type="button" className="btn btn-ghost w-full" onClick={() => void remove()}>حذف الربط</button>
        </article>
      </section>
      <section className="mt-4">
        <h2 className="mb-3 font-semibold">الواجهات</h2>
        {data.interfaces.length === 0 ? <p className="text-sm text-muted">لا واجهات مقروءة.</p> : null}
        <div className="space-y-2">
          {data.interfaces.map((iface) => (
            <div key={iface.name} className="panel flex items-center justify-between px-4 py-3 text-sm">
              <span className="ltr">{iface.name}</span>
              <span className="text-muted">{iface.kind} · {iface.running ? "يعمل" : "متوقف"} · {iface.origin === "sync" ? "LIVE" : "LAB"}</span>
            </div>
          ))}
        </div>
      </section>
      <section className="mt-4">
        <h2 className="mb-3 font-semibold">جلسات هذا الراوتر</h2>
        <div className="space-y-2">
          {data.sessions.map((session) => (
            <div key={session.id} className="panel px-4 py-3 text-sm">
              <p className="font-medium">{session.username}</p>
              <p className="text-muted">{statusText(session.kind)} · {session.ip} · {formatBytes(session.bytesIn + session.bytesOut)}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Acceptance({ router }: { router: { mode: string; report: { at: string; accepted: boolean; error: string; checks: Array<{ id: string; label: string; ok: boolean; value: string; error: string }> } | null; lastSync: string | null } }) {
  if (router.mode === "lab") {
    return (
      <article className="panel mb-4 p-4 text-sm">
        <p className="font-semibold">المصدر: LAB</p>
        <p className="mt-2 text-muted">هذه الأرقام مخزّنة للتجربة. لا يوجد اتصال، ولا يُحتسب هذا تقرير قبول للمرحلة الأولى.</p>
      </article>
    );
  }
  if (!router.report) {
    return (
      <article className="panel mb-4 p-4 text-sm">
        <p className="font-semibold">لا يوجد تقرير اختبار</p>
        <p className="mt-2 text-muted">حفظ الراوتر ليس نجاح اتصال. اضغط مزامنة. لا تُعرض أرقام بديلة قبل رجوعها من الجهاز.</p>
      </article>
    );
  }
  const report = router.report;
  return (
    <article className="panel mb-4 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-semibold">تقرير الاختبار · LIVE</p>
        <span className={`badge ${report.accepted ? "badge-ok" : "badge-danger"}`}>{report.accepted ? "مقبول" : "غير مقبول"}</span>
      </div>
      <p className="mt-2 text-sm text-muted">وقت المحاولة {formatWhen(report.at)}{report.error ? ` · ${report.error}` : ""}</p>
      {!report.accepted && router.lastSync && router.lastSync !== report.at ? (
        <p className="mt-2 text-sm text-muted">آخر قراءة ناجحة كانت {formatWhen(router.lastSync)} وليست نتيجة هذه المحاولة.</p>
      ) : null}
      <div className="mt-3 space-y-2">
        {report.checks.map((check) => (
          <div key={check.id} className="rounded-xl border border-line px-3 py-2 text-sm">
            <div className="flex items-center justify-between gap-2">
              <span>{check.label}</span>
              <span className={`badge ${check.ok ? "badge-ok" : "badge-danger"}`}>{check.ok ? "نجح" : "فشل"}</span>
            </div>
            {check.value ? <p className="mt-1 break-words text-muted">{check.value}</p> : null}
            {check.error ? <p className="mt-1 text-danger">{check.error}</p> : null}
          </div>
        ))}
      </div>
    </article>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-2 last:border-0">
      <span className="text-muted">{k}</span>
      <span className="text-end tabular-nums">{v}</span>
    </div>
  );
}
