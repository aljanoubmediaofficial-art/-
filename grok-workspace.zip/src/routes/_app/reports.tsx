import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { PageHead, useLoad } from "@/components/kit";
import { getReports } from "@/lib/noc/api";
import { formatInt, formatMoney } from "@/lib/format";

export const Route = createFileRoute("/_app/reports")({ component: ReportsPage });

function ReportsPage() {
  const load = useCallback(() => getReports(), []);
  const { data, error, loading } = useLoad(load);
  function csv() {
    if (!data) return;
    const body = data.days.map((day) => `${day.day},${day.qty},${day.amount}`).join("\n");
    const blob = new Blob([`\uFEFFday,qty,amount\n${body}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sales.csv";
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div>
      <PageHead title="التقارير">
        <button type="button" className="btn btn-ghost" onClick={csv}>تصدير المبيعات</button>
      </PageHead>
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      {data ? (
        <>
          <section className="mb-4 grid grid-cols-3 gap-3">
            <article className="panel p-4"><p className="text-sm text-muted">جلسات</p><p className="text-2xl tabular-nums">{formatInt(data.tech.sessions)}</p></article>
            <article className="panel p-4"><p className="text-sm text-muted">راوترات متصلة</p><p className="text-2xl tabular-nums">{formatInt(data.tech.online)}</p></article>
            <article className="panel p-4"><p className="text-sm text-muted">تنبيهات</p><p className="text-2xl tabular-nums">{formatInt(data.tech.alerts)}</p></article>
          </section>
          <p className="mb-3 text-sm text-muted">
            مصدر المبيعات: {data.origins.map((item) => `${item.origin === "lab" ? "مختبر" : "تشغيل"} ${formatMoney(item.amount)}`).join(" · ") || "لا مبيعات"}
          </p>
          <div className="space-y-2">
            {data.days.map((day) => (
              <div key={day.day} className="panel flex items-center justify-between px-4 py-3 text-sm">
                <span className="ltr">{day.day}</span>
                <span className="tabular-nums">{formatInt(day.qty)} كرت · {formatMoney(day.amount)}</span>
              </div>
            ))}
          </div>
        </>
      ) : null}
    </div>
  );
}
