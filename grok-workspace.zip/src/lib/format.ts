const latn = new Intl.NumberFormat("ar-YE-u-nu-latn");

export function formatInt(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return latn.format(n);
}

export function formatMoney(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return `${latn.format(n)} ر.ي`;
}

export function formatWhen(iso: string | null | undefined): string {
  if (!iso) return "لا يوجد";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return new Intl.DateTimeFormat("ar-YE-u-nu-latn", {
    timeZone: "Asia/Aden",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(d);
}

export function formatBytes(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  const digits = i === 0 ? 0 : 1;
  return `${v.toFixed(digits)} ${units[i]}`;
}

export function adenDay(date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Aden",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function addDays(day: string, days: number): string {
  const [y, m, d] = day.split("-").map(Number);
  const dt = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}
