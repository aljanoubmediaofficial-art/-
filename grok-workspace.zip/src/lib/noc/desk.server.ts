import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID } from "node:crypto";
import { getSql, type Sql } from "@/lib/db";
import { adenDay } from "@/lib/format";

type Row = Record<string, unknown>;

function id(): string {
  return randomUUID();
}

function text(v: unknown, fallback = ""): string {
  if (v === null || v === undefined) return fallback;
  return String(v);
}

function num(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function flag(v: unknown): boolean {
  return v === true || v === "t" || v === "true" || v === 1;
}

async function dek(sql: Sql): Promise<Buffer> {
  const env = process.env.ROUTER_KEY;
  if (env && env.trim()) return createHash("sha256").update(env).digest();
  const rows = await sql<Row>`select key_b64 from platform_keys where id = 'dek'`;
  const existing = rows[0]?.key_b64;
  if (typeof existing === "string") return Buffer.from(existing, "base64");
  const fresh = randomBytes(32).toString("base64");
  await sql`insert into platform_keys (id, key_b64) values ('dek', ${fresh}) on conflict (id) do nothing`;
  const again = await sql<Row>`select key_b64 from platform_keys where id = 'dek'`;
  return Buffer.from(text(again[0]?.key_b64), "base64");
}

async function seal(sql: Sql, plain: string): Promise<string> {
  const key = await dek(sql);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64")}.${tag.toString("base64")}.${enc.toString("base64")}`;
}

async function open(sql: Sql, packed: string | null): Promise<string> {
  if (!packed) return "";
  const [ivB, tagB, dataB] = packed.split(".");
  if (!ivB || !tagB || !dataB) return "";
  try {
    const key = await dek(sql);
    const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB, "base64"));
    decipher.setAuthTag(Buffer.from(tagB, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

async function ctx(userId: string) {
  const sql = await getSql();
  const rows = await sql<Row>`select id, name from tenants where owner_user_id = ${userId}`;
  const tenantId = text(rows[0]?.id);
  if (!tenantId) throw new Error("افتح مركز القيادة أولاً حتى تُنشأ الشبكة");
  const license = await sql<Row>`select status from licenses where tenant_id = ${tenantId}`;
  return { sql, tenantId, name: text(rows[0]?.name), suspended: text(license[0]?.status) === "suspended" };
}

function assertWritable(suspended: boolean) {
  if (suspended) throw new Error("الحساب موقوف. تبقى المراقبة، وتتوقف أوامر التعديل.");
}

async function audit(sql: Sql, tenantId: string, userId: string, action: string, target: string, detail: string) {
  await sql`insert into audit_logs (id, tenant_id, user_id, action, target, detail)
    values (${id()}, ${tenantId}, ${userId}, ${action}, ${target}, ${detail})`;
}

export async function listResellers(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const people = await sql<Row>`select * from resellers where tenant_id = ${tenantId} order by name`;
  const entries = await sql<Row>`select * from wallet_entries where tenant_id = ${tenantId} order by created_at desc limit 80`;
  const sums = await sql<Row>`select reseller_id, coalesce(sum(amount), 0)::int as balance from wallet_entries where tenant_id = ${tenantId} group by reseller_id`;
  const balance = new Map(sums.map((row) => [text(row.reseller_id), num(row.balance) ?? 0]));
  return {
    resellers: people.map((row) => ({
      id: text(row.id),
      name: text(row.name),
      phone: text(row.phone),
      commissionPct: num(row.commission_pct) ?? 0,
      active: flag(row.active),
      notes: text(row.notes),
      balance: balance.get(text(row.id)) ?? 0,
    })),
    entries: entries.map((row) => ({
      id: text(row.id),
      resellerId: text(row.reseller_id),
      kind: text(row.kind),
      amount: num(row.amount) ?? 0,
      note: text(row.note),
      reversesId: text(row.reverses_id),
      createdAt: text(row.created_at),
    })),
  };
}

export async function saveReseller(
  userId: string,
  input: { name: string; phone: string; commissionPct: number; notes: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rowId = id();
  await sql`insert into resellers (id, tenant_id, name, phone, commission_pct, notes)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.phone}, ${input.commissionPct}, ${input.notes})`;
  await audit(sql, tenantId, userId, "إضافة بائع", rowId, input.name);
  return { id: rowId };
}

export async function walletMove(
  userId: string,
  input: { resellerId: string; kind: "topup" | "withdraw" | "sale" | "commission"; amount: number; note: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  if (input.amount <= 0) throw new Error("المبلغ يجب أن يكون أكبر من صفر");
  const owner = await sql<Row>`select id, name from resellers where id = ${input.resellerId} and tenant_id = ${tenantId}`;
  if (!owner[0]) throw new Error("البائع غير موجود");
  const signed = input.kind === "withdraw" || input.kind === "sale" ? -input.amount : input.amount;
  const rowId = id();
  await sql`insert into wallet_entries (id, tenant_id, reseller_id, kind, amount, note)
    values (${rowId}, ${tenantId}, ${input.resellerId}, ${input.kind}, ${signed}, ${input.note})`;
  await audit(sql, tenantId, userId, "قيد محفظة", rowId, `${text(owner[0].name)} ${input.kind} ${signed}`);
  return { id: rowId };
}

export async function reverseWallet(userId: string, entryId: string) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rows = await sql<Row>`select * from wallet_entries where id = ${entryId} and tenant_id = ${tenantId}`;
  const row = rows[0];
  if (!row) throw new Error("القيد غير موجود");
  if (text(row.kind) === "reverse") throw new Error("لا يُعكس قيد عكسي");
  const prior = await sql<Row>`select id from wallet_entries where tenant_id = ${tenantId} and reverses_id = ${entryId}`;
  if (prior[0]) throw new Error("عُكس هذا القيد مسبقاً");
  const amount = -(num(row.amount) ?? 0);
  const rowId = id();
  await sql`insert into wallet_entries (id, tenant_id, reseller_id, kind, amount, note, reverses_id)
    values (${rowId}, ${tenantId}, ${text(row.reseller_id)}, 'reverse', ${amount}, ${`عكس: ${text(row.note)}`}, ${entryId})`;
  await audit(sql, tenantId, userId, "عكس قيد", rowId, entryId);
  return { id: rowId };
}

export async function listUm(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select * from um_users where tenant_id = ${tenantId} order by username`;
  return rows.map((row) => ({
    id: text(row.id),
    username: text(row.username),
    profile: text(row.profile_name),
    credit: num(row.credit) ?? 0,
    limitation: text(row.limitation),
    disabled: flag(row.disabled),
    note: text(row.note),
  }));
}

export async function saveUm(
  userId: string,
  input: { username: string; profile: string; credit: number; limitation: string; note: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rowId = id();
  await sql`insert into um_users (id, tenant_id, username, profile_name, credit, limitation, note)
    values (${rowId}, ${tenantId}, ${input.username}, ${input.profile}, ${input.credit}, ${input.limitation}, ${input.note})`;
  await audit(sql, tenantId, userId, "مستخدم يوزر منجر", rowId, input.username);
  return { id: rowId, message: "حُفظ في سجل المنصة. لم يُرسل إلى الراوتر حتى تربط User Manager وتزامنه." };
}

export async function setUmDisabled(userId: string, rowId: string, disabled: boolean) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  await sql`update um_users set disabled = ${disabled} where id = ${rowId} and tenant_id = ${tenantId}`;
  await audit(sql, tenantId, userId, disabled ? "تعطيل يوزر منجر" : "تفعيل يوزر منجر", rowId, "");
  return { ok: true };
}

export async function listJobs(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select * from jobs where tenant_id = ${tenantId} order by created_at desc`;
  return rows.map((row) => ({
    id: text(row.id),
    title: text(row.title),
    site: text(row.site),
    tower: text(row.tower),
    assignee: text(row.assignee),
    status: text(row.status),
    notes: text(row.notes),
    createdAt: text(row.created_at),
  }));
}

export async function saveJob(
  userId: string,
  input: { title: string; site: string; tower: string; assignee: string; notes: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rowId = id();
  const status = input.assignee.trim() ? "assigned" : "open";
  await sql`insert into jobs (id, tenant_id, title, site, tower, assignee, status, notes)
    values (${rowId}, ${tenantId}, ${input.title}, ${input.site}, ${input.tower}, ${input.assignee}, ${status}, ${input.notes})`;
  await audit(sql, tenantId, userId, "بلاغ صيانة", rowId, input.title);
  return { id: rowId };
}

export async function setJobStatus(userId: string, jobId: string, status: "open" | "assigned" | "done" | "closed") {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  await sql`update jobs set status = ${status} where id = ${jobId} and tenant_id = ${tenantId}`;
  await audit(sql, tenantId, userId, "حالة بلاغ", jobId, status);
  return { ok: true };
}

export async function listInventory(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select * from inventory where tenant_id = ${tenantId} order by name`;
  return rows.map((row) => ({
    id: text(row.id),
    name: text(row.name),
    kind: text(row.kind),
    serial: text(row.serial),
    model: text(row.model),
    qty: num(row.qty) ?? 0,
    buyPrice: num(row.buy_price) ?? 0,
    location: text(row.location),
    state: text(row.state),
    warranty: text(row.warranty),
    boughtOn: text(row.bought_on),
  }));
}

export async function saveInventory(
  userId: string,
  input: {
    name: string;
    kind: string;
    serial: string;
    model: string;
    qty: number;
    buyPrice: number;
    location: string;
    state: string;
    warranty: string;
    boughtOn: string;
  },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const kinds = new Set(["router", "antenna", "modem", "switch", "cable", "power", "other"]);
  const states = new Set(["stock", "installed", "faulty", "spare"]);
  if (!kinds.has(input.kind) || !states.has(input.state)) throw new Error("نوع القطعة أو حالتها غير معروف");
  const rowId = id();
  await sql`insert into inventory (id, tenant_id, name, kind, serial, model, qty, buy_price, location, state, warranty, bought_on)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.kind}, ${input.serial}, ${input.model}, ${input.qty}, ${input.buyPrice}, ${input.location}, ${input.state}, ${input.warranty}, ${input.boughtOn})`;
  await audit(sql, tenantId, userId, "إضافة مخزون", rowId, input.name);
  return { id: rowId };
}

export async function listChannels(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select tg_chat, tg_bot_name, tg_token_cipher, wa_phone, wa_note from channels where tenant_id = ${tenantId}`;
  const outbox = await sql<Row>`select id, channel, to_addr, body, status, detail, created_at from outbox where tenant_id = ${tenantId} order by created_at desc limit 30`;
  const row = rows[0];
  return {
    chat: text(row?.tg_chat),
    botName: text(row?.tg_bot_name),
    hasToken: Boolean(row?.tg_token_cipher),
    waPhone: text(row?.wa_phone),
    waNote: text(row?.wa_note),
    outbox: outbox.map((item) => ({
      id: text(item.id),
      channel: text(item.channel),
      to: text(item.to_addr),
      body: text(item.body),
      status: text(item.status),
      detail: text(item.detail),
      createdAt: text(item.created_at),
    })),
  };
}

export async function saveChannels(
  userId: string,
  input: { token: string; chat: string; waPhone: string; waNote: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const existing = await sql<Row>`select tg_token_cipher from channels where tenant_id = ${tenantId}`;
  let cipher = text(existing[0]?.tg_token_cipher) || null;
  if (input.token.trim()) {
    if (!/^\d{6,}:[A-Za-z0-9_-]{20,}$/.test(input.token.trim())) {
      throw new Error("صيغة توكن البوت غير صالحة");
    }
    cipher = await seal(sql, input.token.trim());
  }
  await sql`insert into channels (tenant_id, tg_token_cipher, tg_chat, wa_phone, wa_note)
    values (${tenantId}, ${cipher}, ${input.chat.trim()}, ${input.waPhone.trim()}, ${input.waNote.trim()})
    on conflict (tenant_id) do update set
      tg_token_cipher = excluded.tg_token_cipher,
      tg_chat = excluded.tg_chat,
      wa_phone = excluded.wa_phone,
      wa_note = excluded.wa_note`;
  await audit(sql, tenantId, userId, "حفظ قنوات الإشعار", tenantId, input.chat ? "تيليجرام" : "بدون محادثة");
  return { ok: true };
}

async function telegram(token: string, method: string, body?: Record<string, string>) {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: body ? "POST" : "GET",
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(8000),
  });
  const payload = (await response.json()) as { ok?: boolean; description?: string; result?: { username?: string } };
  if (!payload.ok) throw new Error(payload.description || "رفض تيليجرام الطلب");
  return payload;
}

export async function testTelegram(userId: string, send: boolean) {
  const { sql, tenantId, name } = await ctx(userId);
  const rows = await sql<Row>`select tg_token_cipher, tg_chat from channels where tenant_id = ${tenantId}`;
  const token = await open(sql, text(rows[0]?.tg_token_cipher) || null);
  if (!token) throw new Error("احفظ توكن البوت أولاً");
  const me = await telegram(token, "getMe");
  const botName = me.result?.username ? `@${me.result.username}` : "";
  await sql`update channels set tg_bot_name = ${botName} where tenant_id = ${tenantId}`;
  if (!send) {
    await audit(sql, tenantId, userId, "فحص بوت", tenantId, botName);
    return { ok: true, message: botName ? `البوت ${botName} صالح` : "البوت صالح" };
  }
  const chat = text(rows[0]?.tg_chat);
  if (!chat) throw new Error("أدخل معرّف المحادثة قبل الإرسال");
  await telegram(token, "sendMessage", {
    chat_id: chat,
    text: `اختبار من الزهر MikroTik — ${name}. هذه رسالة حقيقية من المنصة.`,
  });
  const rowId = id();
  await sql`insert into outbox (id, tenant_id, channel, to_addr, body, status, detail)
    values (${rowId}, ${tenantId}, 'telegram', ${chat}, ${"رسالة اختبار"}, 'sent', ${botName})`;
  await audit(sql, tenantId, userId, "اختبار تيليجرام", chat, botName);
  return { ok: true, message: `أُرسلت رسالة الاختبار إلى ${chat}` };
}

export async function holdWhatsapp(userId: string, input: { to: string; body: string }) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rowId = id();
  await sql`insert into outbox (id, tenant_id, channel, to_addr, body, status, detail)
    values (${rowId}, ${tenantId}, 'whatsapp', ${input.to}, ${input.body}, 'held', ${"محجوزة. لا يوجد مزود واتساب موصول، ولم تُرسل."})`;
  await audit(sql, tenantId, userId, "حجز رسالة واتساب", rowId, input.to);
  return { id: rowId, message: "حُجزت الرسالة في السجل ولم تُرسل. اربط مزود واتساب لاحقاً للإرسال الفعلي." };
}

export async function listTickets(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select * from tickets where tenant_id = ${tenantId} order by created_at desc`;
  return rows.map((row) => ({
    id: text(row.id),
    subject: text(row.subject),
    body: text(row.body),
    status: text(row.status),
    createdAt: text(row.created_at),
  }));
}

export async function saveTicket(userId: string, input: { subject: string; body: string }) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const rowId = id();
  await sql`insert into tickets (id, tenant_id, subject, body) values (${rowId}, ${tenantId}, ${input.subject}, ${input.body})`;
  await audit(sql, tenantId, userId, "تذكرة دعم", rowId, input.subject);
  return { id: rowId };
}

export async function closeTicket(userId: string, ticketId: string) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  await sql`update tickets set status = 'closed' where id = ${ticketId} and tenant_id = ${tenantId}`;
  await audit(sql, tenantId, userId, "إغلاق تذكرة", ticketId, "");
  return { ok: true };
}

export async function listNetwork(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const ifaces = await sql<Row>`select i.name, i.kind, i.running, i.comment, i.origin, r.name as router
    from interfaces i join routers r on r.id = i.router_id
    where i.tenant_id = ${tenantId} order by r.name, i.name`;
  const notes = await sql<Row>`select * from net_notes where tenant_id = ${tenantId} order by area, name`;
  return {
    interfaces: ifaces.map((row) => ({
      name: text(row.name),
      kind: text(row.kind),
      running: flag(row.running),
      comment: text(row.comment),
      origin: text(row.origin),
      router: text(row.router),
    })),
    notes: notes.map((row) => ({
      id: text(row.id),
      area: text(row.area),
      name: text(row.name),
      detail: text(row.detail),
    })),
  };
}

export async function saveNetNote(userId: string, input: { area: string; name: string; detail: string }) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const areas = new Set(["firewall", "nat", "dhcp", "dns", "queue", "route", "vlan", "bridge", "vpn"]);
  if (!areas.has(input.area)) throw new Error("القسم غير معروف");
  const rowId = id();
  await sql`insert into net_notes (id, tenant_id, area, name, detail)
    values (${rowId}, ${tenantId}, ${input.area}, ${input.name}, ${input.detail})`;
  await audit(sql, tenantId, userId, "ملاحظة شبكة", rowId, `${input.area} ${input.name}`);
  return { id: rowId, message: "سُجّلت كملاحظة تشغيل. لم تُطبَّق على الراوتر." };
}

type Finding = { severity: "ok" | "warn" | "danger"; title: string; evidence: string; action: string };

export async function diagnose(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const routers = await sql<Row>`select name, mode, status, cpu, ram, last_error from routers where tenant_id = ${tenantId}`;
  const alerts = await sql<Row>`select count(*)::int as n from alerts where tenant_id = ${tenantId} and acked = false`;
  const due = await sql<Row>`select count(*)::int as n from subscribers where tenant_id = ${tenantId} and (status = 'due' or ends_on < ${adenDay()})`;
  const weak = await sql<Row>`select name, signal from antennas where tenant_id = ${tenantId} and signal is not null and signal < -70`;
  const sources = await sql<Row>`select name, status, latency_ms from sources where tenant_id = ${tenantId}`;
  const live = routers.filter((row) => text(row.mode) === "live").length;
  const findings: Finding[] = [];
  if (routers.length === 0) {
    findings.push({
      severity: "warn",
      title: "لا راوترات في السجل",
      evidence: "جدول الراوترات فارغ لهذا الحساب.",
      action: "أضف راوتراً أو افتح المختبر إن أردت تجربة الواجهة.",
    });
  }
  if (live === 0 && routers.length > 0) {
    findings.push({
      severity: "warn",
      title: "لا توجد قراءة حية",
      evidence: "كل الراوترات الحالية معلّمة كمختبر أو لم يُفحص اتصالها.",
      action: "اربط عنوان API-SSL حقيقياً قبل اعتبار الأرقام حالة الشبكة.",
    });
  }
  for (const router of routers) {
    if (text(router.status) === "offline") {
      findings.push({
        severity: "danger",
        title: `انقطاع ${text(router.name)}`,
        evidence: text(router.last_error) || "الحالة المخزّنة: منقطع.",
        action: "تحقق من الطاقة والمنفذ 8729 والنفق قبل إعادة التشغيل.",
      });
    }
    const cpu = num(router.cpu);
    if (cpu !== null && cpu >= 80) {
      findings.push({
        severity: "warn",
        title: `معالج ${text(router.name)} مرتفع`,
        evidence: `آخر قراءة مخزّنة ${cpu}٪.`,
        action: "راجع الجلسات والفايرول. لا تُغلق شيئاً من هذا الفحص.",
      });
    }
    const ram = num(router.ram);
    if (ram !== null && ram >= 85) {
      findings.push({
        severity: "warn",
        title: `ذاكرة ${text(router.name)} مرتفعة`,
        evidence: `آخر قراءة مخزّنة ${ram}٪.`,
        action: "راجع عدد الجلسات والكاش قبل زيادة العتاد.",
      });
    }
  }
  const openAlerts = num(alerts[0]?.n) ?? 0;
  if (openAlerts > 0) {
    findings.push({
      severity: "warn",
      title: "تنبيهات غير مغلقة",
      evidence: `${openAlerts} تنبيهاً ما زال مفتوحاً.`,
      action: "راجع مركز التنبيهات وأغلق ما عولج.",
    });
  }
  const late = num(due[0]?.n) ?? 0;
  if (late > 0) {
    findings.push({
      severity: "warn",
      title: "اشتراكات متأخرة",
      evidence: `${late} عميلاً تاريخ انتهائه فات أو حالته متأخر.`,
      action: "جدّد من شاشة العملاء أو علّق الخدمة يدوياً. الفحص لا يفصل أحداً.",
    });
  }
  for (const antenna of weak) {
    findings.push({
      severity: "warn",
      title: `إشارة ضعيفة: ${text(antenna.name)}`,
      evidence: `${num(antenna.signal)} dBm في السجل. ليست قياساً لحظياً إلا إذا زامنت الجهاز.`,
      action: "عاين التوجيه والتردد في الموقع.",
    });
  }
  for (const source of sources) {
    const latency = num(source.latency_ms);
    if (text(source.status) === "offline" || (latency !== null && latency > 150)) {
      findings.push({
        severity: text(source.status) === "offline" ? "danger" : "warn",
        title: `مصدر ${text(source.name)}`,
        evidence: text(source.status) === "offline" ? "الحالة المخزّنة: منقطع." : `تأخير مخزّن ${latency} ms.`,
        action: "لا يُغيّر هذا الفحص التوجيه أو PCC.",
      });
    }
  }
  if (findings.length === 0) {
    findings.push({
      severity: "ok",
      title: "لا مؤشر خطر في السجلات",
      evidence: "الراوترات المسجّلة ليست منقطعة، ولا تنبيهات مفتوحة، ولا اشتراك متأخر.",
      action: "هذا لا يثبت أن الخط سليم الآن إذا كانت القراءة قديمة.",
    });
  }
  return { generatedAt: new Date().toISOString(), liveRouters: live, findings };
}

export async function assist(userId: string, question: string) {
  const report = await diagnose(userId);
  const q = question.trim();
  const folded = q.toLowerCase();
  const keys = [
    ["معالج", "cpu", "معالج"],
    ["ذاكرة", "ram", "ذاكرة"],
    ["انقطاع", "offline", "انقطاع"],
    ["اشتراك", "عميل", "اشتراك"],
    ["إشارة", "انتينا", "إشارة"],
    ["ستار", "فايبر", "مصدر"],
    ["dns", "دي ان اس", "مصدر"],
  ] as const;
  const hit = keys.find((group) => group.slice(0, 2).some((word) => folded.includes(word) || q.includes(word)));
  const related = hit
    ? report.findings.filter((item) => item.title.includes(hit[2]) || item.evidence.includes(hit[2]))
    : report.findings;
  const used = related.length > 0 ? related : report.findings;
  return {
    question: q || "فحص عام",
    note: "تحليل على السجلات المخزّنة في حسابك. لا يطبّق تغييراً ولا يتصل بنموذج خارجي.",
    findings: used.slice(0, 6),
    generatedAt: report.generatedAt,
  };
}

export async function saveSubscriber(
  userId: string,
  input: {
    name: string;
    phone: string;
    address: string;
    tower: string;
    antenna: string;
    service: string;
    account: string;
    plan: string;
    endsOn: string;
  },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.endsOn)) throw new Error("تاريخ الانتهاء بصيغة سنة-شهر-يوم");
  const rowId = id();
  const code = `ZN-${String(Date.now()).slice(-6)}`;
  const status = input.endsOn < adenDay() ? "due" : "active";
  await sql`insert into subscribers (
    id, tenant_id, name, phone, address, code, tower, antenna, service, account, plan_name, started_on, ends_on, status, origin
  ) values (
    ${rowId}, ${tenantId}, ${input.name}, ${input.phone}, ${input.address}, ${code}, ${input.tower}, ${input.antenna},
    ${input.service}, ${input.account}, ${input.plan}, ${adenDay()}, ${input.endsOn}, ${status}, 'desk'
  )`;
  await audit(sql, tenantId, userId, "إضافة عميل", rowId, input.name);
  return { id: rowId, code };
}

export async function recordPayment(userId: string, input: { subscriberId: string; amount: number; note: string }) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  if (input.amount <= 0) throw new Error("المبلغ غير صالح");
  const person = await sql<Row>`select name from subscribers where id = ${input.subscriberId} and tenant_id = ${tenantId}`;
  if (!person[0]) throw new Error("العميل غير موجود");
  const rowId = id();
  const day = adenDay();
  await sql`insert into payments (id, tenant_id, subscriber_id, amount, note, day)
    values (${rowId}, ${tenantId}, ${input.subscriberId}, ${input.amount}, ${input.note}, ${day})`;
  await sql`insert into sales (id, tenant_id, day, amount, qty, note, origin)
    values (${id()}, ${tenantId}, ${day}, ${input.amount}, 1, ${`دفعة ${text(person[0].name)}`}, 'desk')`;
  await audit(sql, tenantId, userId, "دفعة عميل", rowId, `${text(person[0].name)} ${input.amount}`);
  return { id: rowId, message: "سُجّلت الدفعة في دفتر المبيعات" };
}

export async function listPayments(userId: string) {
  const { sql, tenantId } = await ctx(userId);
  const rows = await sql<Row>`select p.subscriber_id, p.amount, p.note, p.day from payments p
    where p.tenant_id = ${tenantId} order by p.created_at desc limit 40`;
  return rows.map((row) => ({
    subscriberId: text(row.subscriber_id),
    amount: num(row.amount) ?? 0,
    note: text(row.note),
    day: text(row.day),
  }));
}

export async function saveTower(
  userId: string,
  input: { name: string; site: string; lat: string; lng: string; routerId: string; power: string; notes: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  if (input.routerId) {
    const router = await sql<Row>`select id from routers where id = ${input.routerId} and tenant_id = ${tenantId}`;
    if (!router[0]) throw new Error("الراوتر غير موجود");
  }
  const rowId = id();
  await sql`insert into towers (id, tenant_id, name, site, lat, lng, router_id, power_note, notes, status, origin)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.site}, ${input.lat || null}, ${input.lng || null}, ${input.routerId || null}, ${input.power}, ${input.notes}, 'unknown', 'desk')`;
  if (input.routerId) {
    await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
      values (${id()}, ${tenantId}, 'router', ${input.routerId}, 'tower', ${rowId}, 'desk')`;
  }
  await audit(sql, tenantId, userId, "إضافة برج", rowId, input.name);
  return { id: rowId };
}

export async function saveAntenna(
  userId: string,
  input: { towerId: string; name: string; model: string; ip: string; frequency: string; channel: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const tower = await sql<Row>`select id from towers where id = ${input.towerId} and tenant_id = ${tenantId}`;
  if (!tower[0]) throw new Error("البرج غير موجود");
  const rowId = id();
  await sql`insert into antennas (id, tenant_id, tower_id, name, kind, model, ip, frequency, channel, status, origin)
    values (${rowId}, ${tenantId}, ${input.towerId}, ${input.name}, 'sector', ${input.model}, ${input.ip}, ${input.frequency}, ${input.channel}, 'unknown', 'desk')`;
  await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
    values (${id()}, ${tenantId}, 'tower', ${input.towerId}, 'antenna', ${rowId}, 'desk')`;
  await audit(sql, tenantId, userId, "إضافة انتينا", rowId, input.name);
  return { id: rowId };
}

export async function saveSource(
  userId: string,
  input: { name: string; kind: string; iface: string; contracted: string; cost: number | null; routerId: string; note: string },
) {
  const { sql, tenantId, suspended } = await ctx(userId);
  assertWritable(suspended);
  const kinds = new Set(["Starlink", "Fiber", "Wireless", "DSL", "Other"]);
  if (!kinds.has(input.kind)) throw new Error("نوع المصدر غير معروف");
  if (input.routerId) {
    const router = await sql<Row>`select id from routers where id = ${input.routerId} and tenant_id = ${tenantId}`;
    if (!router[0]) throw new Error("الراوتر غير موجود");
  }
  const rowId = id();
  await sql`insert into sources (id, tenant_id, name, kind, iface, contracted, cost, status, note, origin)
    values (${rowId}, ${tenantId}, ${input.name}, ${input.kind}, ${input.iface}, ${input.contracted}, ${input.cost}, 'unknown', ${input.note}, 'desk')`;
  if (input.routerId) {
    await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
      values (${id()}, ${tenantId}, 'source', ${rowId}, 'router', ${input.routerId}, 'desk')`;
  }
  await audit(sql, tenantId, userId, "إضافة مصدر إنترنت", rowId, input.name);
  return { id: rowId };
}
