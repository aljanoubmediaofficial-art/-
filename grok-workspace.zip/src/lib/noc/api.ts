import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";

async function eng() {
  return import("./engine.server");
}

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).getWorkspace(context.userId));

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).getDashboard(context.userId));

export const listRouters = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listRouters(context.userId));

export const getRouter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).getRouter(context.userId, data.id));

const routerInput = z.object({
  id: z.string().optional(),
  name: z.string().min(2).max(80),
  host: z.string().max(253),
  port: z.number().int().min(1).max(65535),
  connType: z.enum(["api", "api-ssl"]),
  apiUser: z.string().max(64),
  password: z.string().max(128).optional(),
  rosHint: z.string().max(40),
  site: z.string().max(80),
  tower: z.string().max(80),
  notes: z.string().max(400),
  wanInterface: z.string().max(64),
});

export const saveRouter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => routerInput.parse(input))
  .handler(async ({ context, data }) => (await eng()).saveRouter(context.userId, data));

export const connectRouter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), trust: z.string().max(128).optional() }).parse(input),
  )
  .handler(async ({ context, data }) =>
    (await eng()).connectRouter(context.userId, data.id, data.trust),
  );

export const deleteRouter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).deleteRouter(context.userId, data.id));

export const rebootRouter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), confirmName: z.string().max(80) }).parse(input),
  )
  .handler(async ({ context, data }) =>
    (await eng()).rebootRouter(context.userId, data.id, data.confirmName),
  );

export const listSessions = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listSessions(context.userId));

export const disconnectSession = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).disconnectSession(context.userId, data.id));

export const listHotspot = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listHotspot(context.userId));

export const listPppoe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listPppoe(context.userId));

const serviceUser = z.object({
  id: z.string().optional(),
  routerId: z.string(),
  username: z.string().min(2).max(32),
  password: z.string().max(64),
  profile: z.string().max(64),
  mac: z.string().max(32).optional(),
  remoteAddress: z.string().max(64).optional(),
  comment: z.string().max(160),
  disabled: z.boolean(),
  expiresOn: z.string().max(20),
});

export const saveHotspot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => serviceUser.parse(input))
  .handler(async ({ context, data }) => (await eng()).saveHotspot(context.userId, data));

export const savePppoe = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => serviceUser.parse(input))
  .handler(async ({ context, data }) => (await eng()).savePppoe(context.userId, data));

export const setUserDisabled = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({ kind: z.enum(["hotspot", "pppoe"]), id: z.string(), disabled: z.boolean() })
      .parse(input),
  )
  .handler(async ({ context, data }) =>
    (await eng()).setUserDisabled(context.userId, data.kind, data.id, data.disabled),
  );

export const listProfiles = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listProfiles(context.userId));

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string(),
        price: z.number().int().min(0).max(1_000_000),
        rateDown: z.string().max(20),
        rateUp: z.string().max(20),
        validity: z.string().max(40),
        sharedUsers: z.number().int().min(1).max(50),
        dataLimit: z.string().max(40),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).saveProfile(context.userId, data));

export const listVouchers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listVouchers(context.userId));

export const generateVouchers = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        routerId: z.string(),
        profile: z.string().max(64),
        price: z.number().int().min(0).max(1_000_000),
        cardType: z.enum(["user", "same", "different"]),
        count: z.number().int().min(1).max(100),
        length: z.number().int().min(4).max(10),
        charset: z.enum(["digits", "letters", "mixed"]),
        prefix: z.string().max(8),
        validity: z.string().max(40),
        recordSale: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).generateVouchers(context.userId, data));

export const sellVouchers = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ ids: z.array(z.string()).max(100) }).parse(input))
  .handler(async ({ context, data }) => (await eng()).sellVouchers(context.userId, data.ids));

export const setVoucherStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), status: z.enum(["new", "disabled"]) }).parse(input),
  )
  .handler(async ({ context, data }) =>
    (await eng()).setVoucherStatus(context.userId, data.id, data.status),
  );

export const voucherCodes = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ ids: z.array(z.string()).max(60) }).parse(input))
  .handler(async ({ context, data }) => (await eng()).voucherCodes(context.userId, data.ids));

export const listTemplates = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listTemplates(context.userId));

export const saveTemplate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string().optional(),
        name: z.string().min(2).max(40),
        accent: z.string().max(20),
        showUser: z.boolean(),
        showPass: z.boolean(),
        showPrice: z.boolean(),
        showValidity: z.boolean(),
        showProfile: z.boolean(),
        showQr: z.boolean(),
        footer: z.string().max(80),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).saveTemplate(context.userId, data));

export const listDevices = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listDevices(context.userId));

export const listTopology = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listTopology(context.userId));

export const listAlerts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listAlerts(context.userId));

export const ackAlert = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).ackAlert(context.userId, data.id));

export const listBackups = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listBackups(context.userId));

export const createBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ routerId: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).createBackup(context.userId, data.routerId));

export const downloadBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).downloadBackup(context.userId, data.id));

export const explainRestore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).explainRestore(context.userId, data.id));

export const getReports = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).getReports(context.userId));

export const listAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listAudit(context.userId));

export const listScripts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listScripts(context.userId));

export const saveScript = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ name: z.string().min(2).max(60), body: z.string().min(1).max(4000) }).parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).saveScript(context.userId, data.name, data.body));

export const runScript = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string(), routerId: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await eng()).runScript(context.userId, data.id, data.routerId));

export const listSubscribers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listSubscribers(context.userId));

export const renewSubscriber = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), days: z.number().int() }).parse(input),
  )
  .handler(async ({ context, data }) =>
    (await eng()).renewSubscriber(context.userId, data.id, data.days),
  );

export const listStaff = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await eng()).listStaff(context.userId));

export const saveStaff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string().optional(),
        name: z.string().min(2).max(60),
        role: z.string().max(20),
        phone: z.string().max(20),
        active: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).saveStaff(context.userId, data));

export const updateWorkspace = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(80),
        area: z.string().max(80),
        logo: z.string().max(180_000).nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await eng()).updateWorkspace(context.userId, data));

export const setLab = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ action: z.enum(["clear", "restore"]) }).parse(input))
  .handler(async ({ context, data }) => (await eng()).setLab(context.userId, data.action));
