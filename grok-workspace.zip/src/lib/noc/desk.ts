import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";

async function desk() {
  return import("./desk.server");
}

export const listResellers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listResellers(context.userId));

export const saveReseller = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(60),
        phone: z.string().max(20),
        commissionPct: z.number().int().min(0).max(80),
        notes: z.string().max(200),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveReseller(context.userId, data));

export const walletMove = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        resellerId: z.string(),
        kind: z.enum(["topup", "withdraw", "sale", "commission"]),
        amount: z.number().int().min(1).max(5_000_000),
        note: z.string().max(160),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).walletMove(context.userId, data));

export const reverseWallet = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await desk()).reverseWallet(context.userId, data.id));

export const listUm = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listUm(context.userId));

export const saveUm = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        username: z.string().min(2).max(32),
        profile: z.string().max(64),
        credit: z.number().int().min(0).max(1_000_000),
        limitation: z.string().max(80),
        note: z.string().max(160),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveUm(context.userId, data));

export const setUmDisabled = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string(), disabled: z.boolean() }).parse(input))
  .handler(async ({ context, data }) => (await desk()).setUmDisabled(context.userId, data.id, data.disabled));

export const listJobs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listJobs(context.userId));

export const saveJob = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        title: z.string().min(2).max(80),
        site: z.string().max(80),
        tower: z.string().max(80),
        assignee: z.string().max(60),
        notes: z.string().max(400),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveJob(context.userId, data));

export const setJobStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), status: z.enum(["open", "assigned", "done", "closed"]) }).parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).setJobStatus(context.userId, data.id, data.status));

export const listInventory = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listInventory(context.userId));

export const saveInventory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(80),
        kind: z.string().max(20),
        serial: z.string().max(40),
        model: z.string().max(40),
        qty: z.number().int().min(1).max(10000),
        buyPrice: z.number().int().min(0).max(50_000_000),
        location: z.string().max(80),
        state: z.string().max(20),
        warranty: z.string().max(40),
        boughtOn: z.string().max(20),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveInventory(context.userId, data));

export const listChannels = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listChannels(context.userId));

export const saveChannels = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        token: z.string().max(120),
        chat: z.string().max(40),
        waPhone: z.string().max(20),
        waNote: z.string().max(400),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveChannels(context.userId, data));

export const testTelegram = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ send: z.boolean() }).parse(input))
  .handler(async ({ context, data }) => (await desk()).testTelegram(context.userId, data.send));

export const holdWhatsapp = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ to: z.string().min(6).max(20), body: z.string().min(2).max(400) }).parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).holdWhatsapp(context.userId, data));

export const listTickets = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listTickets(context.userId));

export const saveTicket = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ subject: z.string().min(2).max(80), body: z.string().min(2).max(800) }).parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveTicket(context.userId, data));

export const closeTicket = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => (await desk()).closeTicket(context.userId, data.id));

export const listNetwork = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listNetwork(context.userId));

export const saveNetNote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ area: z.string().max(20), name: z.string().min(2).max(80), detail: z.string().max(400) }).parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveNetNote(context.userId, data));

export const diagnose = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).diagnose(context.userId));

export const assist = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ question: z.string().max(300) }).parse(input))
  .handler(async ({ context, data }) => (await desk()).assist(context.userId, data.question));

export const saveSubscriber = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(80),
        phone: z.string().max(20),
        address: z.string().max(80),
        tower: z.string().max(80),
        antenna: z.string().max(80),
        service: z.string().max(20),
        account: z.string().max(40),
        plan: z.string().max(40),
        endsOn: z.string().max(20),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveSubscriber(context.userId, data));

export const recordPayment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        subscriberId: z.string(),
        amount: z.number().int().min(1).max(5_000_000),
        note: z.string().max(160),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).recordPayment(context.userId, data));

export const listPayments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => (await desk()).listPayments(context.userId));

export const saveTower = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(80),
        site: z.string().max(80),
        lat: z.string().max(20),
        lng: z.string().max(20),
        routerId: z.string().max(80),
        power: z.string().max(80),
        notes: z.string().max(200),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveTower(context.userId, data));

export const saveAntenna = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        towerId: z.string(),
        name: z.string().min(2).max(80),
        model: z.string().max(40),
        ip: z.string().max(40),
        frequency: z.string().max(20),
        channel: z.string().max(20),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveAntenna(context.userId, data));

export const saveSource = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(2).max(80),
        kind: z.string().max(20),
        iface: z.string().max(40),
        contracted: z.string().max(40),
        cost: z.number().int().min(0).max(50_000_000).nullable(),
        routerId: z.string().max(80),
        note: z.string().max(200),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => (await desk()).saveSource(context.userId, data));
