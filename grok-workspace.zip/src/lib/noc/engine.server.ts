// Recovered from the last server bundle after a bad edit wiped the TypeScript source.
// @ts-nocheck
import { getSql, type Sql } from "@/lib/db";
import { addDays, adenDay } from "@/lib/format";
import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID } from "node:crypto";
import net from "node:net";
import tls from "node:tls";

var BUILTIN = [{
	id: "builtin:read",
	name: "قراءة موارد الراوتر",
	danger: "منخفض",
	body: "/system/resource/print\n/system/identity/print\n/system/routerboard/print",
	builtin: true
}, {
	id: "builtin:expire",
	name: "تعطيل هوتسبوت المنتهي",
	danger: "متوسط",
	body: "يعطّل حسابات الهوتسبوت التي انتهى تاريخها في المنصة. لا يحذف الحساب ولا يغيّر غيره.",
	builtin: true
}];
function id() {
	return randomUUID();
}
function num(v) {
	if (v === null || v === void 0 || v === "") return null;
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : null;
}
function str(v) {
	if (v === null || v === void 0 || v === "") return null;
	return String(v);
}
function text(v, fallback = "") {
	if (v === null || v === void 0) return fallback;
	return String(v);
}
function flag(v) {
	return v === true || v === "t" || v === "true" || v === 1;
}
function safeToken(value, label) {
	if (/[\r\n\0=]/.test(value)) throw new Error(`${label} يحتوي محارف غير مسموحة`);
	return value;
}
function assertHost(host, port) {
	const h = host.trim().toLowerCase();
	if (!h || h.length > 253) throw new Error("عنوان الاتصال غير صالح");
	if (h === "localhost" || h.endsWith(".localhost") || h === "::1") throw new Error("هذا العنوان محظور");
	const ip = h.replace(/^\[|\]$/g, "");
	if (/^(0\.|127\.|169\.254\.|255\.|224\.|240\.)/.test(ip) || ip === "0.0.0.0" || ip.startsWith("fe80:") || ip.startsWith("fc") || ip.startsWith("fd")) throw new Error("هذا العنوان محظور لأسباب أمنية");
	if (port !== 8728 && port !== 8729) throw new Error("المنفذ المسموح للاتصال هو 8728 أو 8729 فقط");
}
function privateHost(host) {
	return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host.trim());
}
async function db() {
	return getSql();
}
async function dek(sql) {
	const env = process.env.ROUTER_KEY;
	if (env && env.trim()) return createHash("sha256").update(env).digest();
	const existing = (await sql`select key_b64 from platform_keys where id = 'dek'`)[0]?.key_b64;
	if (typeof existing === "string") return Buffer.from(existing, "base64");
	await sql`insert into platform_keys (id, key_b64) values ('dek', ${randomBytes(32).toString("base64")}) on conflict (id) do nothing`;
	const again = await sql`select key_b64 from platform_keys where id = 'dek'`;
	return Buffer.from(text(again[0]?.key_b64), "base64");
}
async function seal(sql, plain) {
	const key = await dek(sql);
	const iv = randomBytes(12);
	const cipher = createCipheriv("aes-256-gcm", key, iv);
	const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
	const tag = cipher.getAuthTag();
	return `${iv.toString("base64")}.${tag.toString("base64")}.${enc.toString("base64")}`;
}
async function open(sql, packed) {
	if (!packed) return "";
	const [ivB, tagB, dataB] = packed.split(".");
	if (!ivB || !tagB || !dataB) return "";
	try {
		const key = await dek(sql);
		const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB, "base64"));
		decipher.setAuthTag(Buffer.from(tagB, "base64"));
		return Buffer.concat([decipher.update(Buffer.from(dataB, "base64")), decipher.final()]).toString("utf8");
	} catch {
		return "";
	}
}
async function audit(sql, tenantId, userId, action, target, detail) {
	await sql`insert into audit_logs (id, tenant_id, user_id, action, target, detail)
    values (${id()}, ${tenantId}, ${userId}, ${action}, ${target}, ${detail})`;
}
async function ensure(userId) {
	const sql = await db();
	let rows = await sql`select id, name, area, logo_data from tenants where owner_user_id = ${userId}`;
	if (!rows[0]) {
		const tid = id();
		const today = adenDay();
		await sql`insert into tenants (id, owner_user_id, name, area)
      values (${tid}, ${userId}, ${"شبكة الزهر نت"}, ${"الحبيلين وردفان"})
      on conflict (owner_user_id) do nothing`;
		rows = await sql`select id, name, area, logo_data from tenants where owner_user_id = ${userId}`;
		const tenantId = text(rows[0]?.id);
		await sql`insert into licenses (tenant_id, plan, status, router_limit, staff_limit, backup_mb, started_on, renews_on)
      values (${tenantId}, 'trial', 'active', 3, 5, 200, ${today}, ${addDays(today, 14)})
      on conflict (tenant_id) do nothing`;
		await audit(sql, tenantId, userId, "إنشاء الشبكة", tenantId, "أُنشئ حساب الشبكة مع تجربة ١٤ يوماً");
	}
	const tenantId = text(rows[0]?.id);
	await seedLab(sql, tenantId);
	return {
		sql,
		tenant: {
			id: tenantId,
			name: text(rows[0]?.name),
			area: text(rows[0]?.area),
			logo: str(rows[0]?.logo_data),
			userId
		}
	};
}
async function licenseOf(sql, tenantId) {
	const row = (await sql`select plan, status, router_limit, staff_limit, backup_mb, started_on, renews_on
    from licenses where tenant_id = ${tenantId}`)[0];
	const live = await sql`select count(*)::int as n from routers where tenant_id = ${tenantId} and mode = 'live'`;
	return {
		plan: text(row?.plan, "trial"),
		status: text(row?.status, "active"),
		routerLimit: num(row?.router_limit) ?? 3,
		staffLimit: num(row?.staff_limit) ?? 5,
		backupMb: num(row?.backup_mb) ?? 200,
		startedOn: text(row?.started_on),
		renewsOn: text(row?.renews_on),
		liveRouters: num(live[0]?.n) ?? 0
	};
}
function assertWritable(status) {
	if (status === "suspended") throw new Error("الحساب موقوف. تبقى المراقبة والنسخ المتوفرة، وتتوقف أوامر التعديل.");
}
function acceptReport(raw) {
	if (!raw) return null;
	try {
		const parsed = JSON.parse(raw);
		if (!parsed || parsed.source !== "live" || !Array.isArray(parsed.checks)) return null;
		return parsed;
	} catch {
		return null;
	}
}
function failedReport(at, message) {
	const labels = [
		["identity", "هوية الراوتر"],
		["version", "إصدار RouterOS"],
		["board", "اسم اللوحة"],
		["cpu", "حمل المعالج"],
		["memory", "الذاكرة والقرص"],
		["interfaces", "الواجهات وحالتها"],
		["hotspot", "جلسات Hotspot النشطة"],
		["pppoe", "جلسات PPPoE النشطة"],
		["traffic", "حركة منفذ الإنترنت"],
		["status", "وقت التحديث وحالة الاتصال"]
	];
	return {
		source: "live",
		at,
		accepted: false,
		error: message,
		checks: labels.map(([id, label]) => ({ id, label, ok: false, value: "", error: message }))
	};
}
function bytesLabel(n) {
	const units = ["B", "KB", "MB", "GB", "TB"];
	let v = n;
	let i = 0;
	while (v >= 1024 && i < units.length - 1) {
		v /= 1024;
		i += 1;
	}
	return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
function bpsLabel(n) {
	const units = ["bps", "Kbps", "Mbps", "Gbps"];
	let v = n;
	let i = 0;
	while (v >= 1000 && i < units.length - 1) {
		v /= 1000;
		i += 1;
	}
	return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
function memoryLine(free, total) {
	const f = Number(free);
	const t = Number(total);
	if (!Number.isFinite(f) || !Number.isFinite(t) || t <= 0) return { ok: false, used: null, text: "" };
	const used = Math.max(0, Math.min(100, Math.round((t - f) / t * 100)));
	return { ok: true, used, text: `المستخدم ${bytesLabel(t - f)} من ${bytesLabel(t)} · حر ${bytesLabel(f)} · ${used}٪` };
}
function mapRouter(row) {
	return {
		id: text(row.id),
		name: text(row.name),
		host: text(row.host),
		port: num(row.port) ?? 8729,
		connType: text(row.conn_type) === "api" ? "api" : "api-ssl",
		apiUser: text(row.api_user),
		hasSecret: Boolean(row.secret_cipher),
		fingerprint: str(row.fingerprint),
		rosHint: text(row.ros_hint),
		rosVersion: str(row.ros_version),
		model: str(row.model),
		board: str(row.board),
		identity: str(row.identity),
		site: text(row.site),
		tower: text(row.tower),
		notes: text(row.notes),
		wanInterface: text(row.wan_interface),
		mode: text(row.mode) === "lab" ? "lab" : "live",
		status: text(row.status, "unknown"),
		cpu: num(row.cpu),
		ram: num(row.ram),
		storage: num(row.storage),
		ramBytes: str(row.ram_bytes),
		hddBytes: str(row.hdd_bytes),
		hotspotActive: num(row.hotspot_active),
		pppoeActive: num(row.pppoe_active),
		rxBps: str(row.rx_bps),
		txBps: str(row.tx_bps),
		temperature: str(row.temperature),
		voltage: str(row.voltage),
		uptime: str(row.uptime),
		downloadMbps: num(row.download_mbps),
		uploadMbps: num(row.upload_mbps),
		lastSeen: str(row.last_seen),
		lastSync: str(row.last_sync),
		lastAttempt: str(row.last_attempt),
		lastError: str(row.last_error),
		report: acceptReport(str(row.sync_report))
	};
}
async function seedLab(sql, tenantId) {
	if ((await sql`select id from routers where tenant_id = ${tenantId} and mode = 'lab' limit 1`)[0]) return;
	const ccr = `${tenantId}:lab:ccr`;
	const rb = `${tenantId}:lab:rb`;
	const off = `${tenantId}:lab:off`;
	const t1 = `${tenantId}:lab:t1`;
	const t2 = `${tenantId}:lab:t2`;
	const routers = [
		[
			ccr,
			"CCR المركز",
			"10.0.0.1",
			"CCR2116-12G-4S+",
			"hEX-CCR",
			"zahr-core",
			"الحبيلين",
			"مركز الشبكة",
			"sfp-sfpplus1",
			"online",
			11,
			38,
			22,
			"54 C",
			"24.1 V",
			"41d 06:12:09",
			186,
			34
		],
		[
			rb,
			"RB ردفان",
			"10.10.1.1",
			"RB1100AHx4",
			"RB1100AHx4",
			"zahr-radfan",
			"ردفان",
			"برج ردفان",
			"ether1",
			"online",
			78,
			64,
			41,
			null,
			"24.0 V",
			"12d 02:44:18",
			92,
			18
		],
		[
			off,
			"RB الموسطة",
			"10.10.8.1",
			"RB4011iGS+",
			"RB4011iGS+",
			"zahr-wasat",
			"الموسطة",
			"برج الموسطة",
			"ether1",
			"offline",
			null,
			null,
			null,
			null,
			null,
			null,
			null,
			null
		]
	];
	for (const r of routers) await sql`insert into routers (
      id, tenant_id, name, host, port, conn_type, api_user, ros_version, model, board, identity,
      site, tower, wan_interface, mode, status, cpu, ram, storage, temperature, voltage, uptime,
      download_mbps, upload_mbps, last_seen, last_error, notes
    ) values (
      ${r[0]}, ${tenantId}, ${r[1]}, ${r[2]}, 8729, 'api-ssl', 'noc-read', '7.19.2', ${r[3]}, ${r[4]}, ${r[5]},
      ${r[6]}, ${r[7]}, ${r[8]}, 'lab', ${r[9]}, ${r[10]}, ${r[11]}, ${r[12]}, ${r[13]}, ${r[14]}, ${r[15]},
      ${r[16]}, ${r[17]}, ${r[9] === "offline" ? null : (/* @__PURE__ */ new Date()).toISOString()},
      ${r[9] === "offline" ? "انقطع منذ آخر فحص مخزّن في المختبر" : null},
      ${"بيانات مختبر، ليست قراءة حية من جهاز"}
    )`;
	for (const f of [
		[
			"sfp-sfpplus1",
			"wan",
			true,
			"ستارلينك"
		],
		[
			"sfp-sfpplus2",
			"wan",
			true,
			"فايبر"
		],
		[
			"bridge-hotspot",
			"bridge",
			true,
			"هوتسبوت"
		],
		[
			"vlan-pppoe",
			"vlan",
			true,
			"PPPoE"
		]
	]) await sql`insert into interfaces (id, tenant_id, router_id, name, kind, running, comment, origin)
      values (${id()}, ${tenantId}, ${ccr}, ${f[0]}, ${f[1]}, ${f[2]}, ${f[3]}, 'lab')`;
	const profiles = [
		[
			ccr,
			"يوم-٢ميجا",
			"hotspot",
			200,
			"2M",
			"2M",
			"١ يوم",
			1,
			""
		],
		[
			ccr,
			"شهر-٤ميجا",
			"hotspot",
			3e3,
			"4M",
			"4M",
			"٣٠ يوم",
			1,
			""
		],
		[
			ccr,
			"منزلي-٨",
			"pppoe",
			6e3,
			"8M",
			"2M",
			"٣٠ يوم",
			1,
			""
		],
		[
			rb,
			"يوم-٢ميجا",
			"hotspot",
			200,
			"2M",
			"2M",
			"١ يوم",
			1,
			""
		]
	];
	for (const p of profiles) await sql`insert into profiles (id, tenant_id, router_id, name, kind, price, rate_down, rate_up, validity, shared_users, data_limit, origin)
      values (${id()}, ${tenantId}, ${p[0]}, ${p[1]}, ${p[2]}, ${p[3]}, ${p[4]}, ${p[5]}, ${p[6]}, ${p[7]}, ${p[8]}, 'lab')`;
	const pass = await seal(sql, "lab-hidden");
	const users = [
		[
			"ahmed.200",
			"شهر-٤ميجا",
			"4C:5E:0C:11:20:01",
			false,
			addDays(adenDay(), 12)
		],
		[
			"shop.04",
			"يوم-٢ميجا",
			"4C:5E:0C:11:20:14",
			false,
			adenDay()
		],
		[
			"guest.expired",
			"يوم-٢ميجا",
			"",
			true,
			addDays(adenDay(), -2)
		]
	];
	for (const u of users) await sql`insert into hotspot_users (id, tenant_id, router_id, username, secret_cipher, profile_name, mac, disabled, expires_on, bytes_in, bytes_out, origin)
      values (${id()}, ${tenantId}, ${ccr}, ${u[0]}, ${pass}, ${u[1]}, ${u[2]}, ${u[3]}, ${u[4]}, 120000000, 44000000, 'lab')`;
	const ppp = [
		[
			"radfan.12",
			"منزلي-٨",
			"172.16.20.12",
			false,
			addDays(adenDay(), 9)
		],
		[
			"habilayn.03",
			"منزلي-٨",
			"172.16.20.3",
			false,
			addDays(adenDay(), 2)
		],
		[
			"wasat.01",
			"منزلي-٨",
			"",
			true,
			addDays(adenDay(), -4)
		]
	];
	for (const u of ppp) await sql`insert into pppoe_users (id, tenant_id, router_id, username, secret_cipher, profile_name, remote_address, disabled, expires_on, bytes_in, bytes_out, origin)
      values (${id()}, ${tenantId}, ${ccr}, ${u[0]}, ${pass}, ${u[1]}, ${u[2]}, ${u[3]}, ${u[4]}, 800000000, 90000000, 'lab')`;
	for (const s of [
		[
			"ahmed.200",
			"10.5.0.14",
			"4C:5E:0C:11:20:01",
			"hotspot",
			"authenticated",
			"الحبيلين",
			"قطاع شمال",
			"2.4M",
			"180k",
			"شهر-٤ميجا"
		],
		[
			"shop.04",
			"10.5.0.40",
			"4C:5E:0C:11:20:14",
			"hotspot",
			"authenticated",
			"الحبيلين",
			"قطاع السوق",
			"1.1M",
			"90k",
			"يوم-٢ميجا"
		],
		[
			"kiosk.9",
			"10.5.1.9",
			"B8:69:F4:20:00:09",
			"hotspot",
			"authenticated",
			"ردفان",
			"قطاع الشرق",
			"900k",
			"70k",
			"يوم-٢ميجا"
		],
		[
			"radfan.12",
			"172.16.20.12",
			"E4:8D:8C:70:12:12",
			"pppoe",
			"authenticated",
			"ردفان",
			"قطاع الشرق",
			"6.2M",
			"1.1M",
			"منزلي-٨"
		],
		[
			"habilayn.03",
			"172.16.20.3",
			"E4:8D:8C:70:03:03",
			"pppoe",
			"authenticated",
			"الحبيلين",
			"قطاع شمال",
			"4.8M",
			"700k",
			"منزلي-٨"
		]
	]) {
		const router = s[5] === "ردفان" && s[3] === "hotspot" ? rb : ccr;
		await sql`insert into sessions (
      id, tenant_id, router_id, username, ip, mac, kind, source, tower, antenna, started_at,
      rx_rate, tx_rate, bytes_in, bytes_out, profile_name, origin
    ) values (
      ${id()}, ${tenantId}, ${router}, ${s[0]}, ${s[1]}, ${s[2]}, ${s[3]}, ${s[4]}, ${s[5]}, ${s[6]},
      ${(/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString()}, ${s[7]}, ${s[8]}, 500000000, 80000000, ${s[9]}, 'lab'
    )`;
	}
	for (const d of [
		[
			"قطاع شمال",
			"MikroTik",
			"LHG 5",
			"antenna",
			"10.10.2.2",
			"48:8F:5A:10:02:02",
			"online",
			-52,
			-98,
			86,
			"wireless"
		],
		[
			"نقطة السوق",
			"MikroTik",
			"SXTsq 5",
			"ap",
			"10.10.2.5",
			"48:8F:5A:10:02:05",
			"online",
			-61,
			-96,
			74,
			"wireless"
		],
		[
			"CPE أحمد",
			"MikroTik",
			"SXT Lite5",
			"cpe",
			"10.10.2.40",
			"4C:5E:0C:11:20:01",
			"online",
			-67,
			null,
			70,
			"wireless"
		],
		[
			"سويتش المركز",
			"MikroTik",
			"CRS328",
			"switch",
			"10.0.0.2",
			"DC:2C:6E:01:00:02",
			"online",
			null,
			null,
			null,
			"neighbor"
		],
		[
			"مودم الفايبر",
			"غير محدد",
			"",
			"modem",
			"10.0.0.3",
			"",
			"online",
			null,
			null,
			null,
			"neighbor"
		],
		[
			"قطاع الموسطة",
			"MikroTik",
			"Disc Lite5",
			"antenna",
			"10.10.8.2",
			"48:8F:5A:88:00:02",
			"offline",
			null,
			null,
			null,
			"wireless"
		]
	]) await sql`insert into devices (
      id, tenant_id, router_id, name, vendor, model, kind, ip, mac, status, signal, noise, ccq, tower, source, last_seen, origin
    ) values (
      ${id()}, ${tenantId}, ${ccr}, ${d[0]}, ${d[1]}, ${d[2]}, ${d[3]}, ${d[4]}, ${d[5]}, ${d[6]},
      ${d[7]}, ${d[8]}, ${d[9]}, ${"الحبيلين"}, ${d[10]},
      ${d[6] === "online" ? (/* @__PURE__ */ new Date()).toISOString() : null}, 'lab'
    )`;
	await sql`insert into towers (id, tenant_id, name, site, lat, lng, router_id, power_note, notes, status, origin)
    values (${t1}, ${tenantId}, ${"برج الحبيلين"}, ${"الحبيلين"}, ${"13.516"}, ${"44.866"}, ${ccr}, ${"طاقة شمسية + بطارية"}, ${"موقع مسجّل يدوياً"}, 'online', 'lab')`;
	await sql`insert into towers (id, tenant_id, name, site, lat, lng, router_id, power_note, notes, status, origin)
    values (${t2}, ${tenantId}, ${"برج ردفان"}, ${"ردفان"}, ${"13.480"}, ${"44.920"}, ${rb}, ${"كهرباء تجارية"}, ${""}, 'online', 'lab')`;
	const a1 = `${tenantId}:lab:a1`;
	const a2 = `${tenantId}:lab:a2`;
	await sql`insert into antennas (id, tenant_id, tower_id, name, kind, model, ip, frequency, channel, width, signal, ccq, clients, status, origin)
    values (${a1}, ${tenantId}, ${t1}, ${"قطاع شمال"}, 'sector', 'LHG 5', '10.10.2.2', '5800', '5805', '20MHz', -52, 86, 38, 'online', 'lab')`;
	await sql`insert into antennas (id, tenant_id, tower_id, name, kind, model, ip, frequency, channel, width, signal, ccq, clients, status, origin)
    values (${a2}, ${tenantId}, ${t2}, ${"قطاع الشرق"}, 'sector', 'SXTsq 5', '10.10.4.2', '5820', '5825', '20MHz', -58, 79, 21, 'online', 'lab')`;
	const star = `${tenantId}:lab:star`;
	const fiber = `${tenantId}:lab:fiber`;
	await sql`insert into sources (id, tenant_id, name, kind, iface, contracted, cost, status, latency_ms, loss, download_mbps, upload_mbps, note, origin)
    values (${star}, ${tenantId}, ${"ستارلينك المركز"}, 'Starlink', 'sfp-sfpplus1', '200/30', 180000, 'online', 48, '0.2%', 186, 28, ${"قياس مخزّن في المختبر، وليس من تطبيق ستارلينك"}, 'lab')`;
	await sql`insert into sources (id, tenant_id, name, kind, iface, contracted, cost, status, latency_ms, loss, download_mbps, upload_mbps, note, origin)
    values (${fiber}, ${tenantId}, ${"فايبر الاحتياط"}, 'Fiber', 'sfp-sfpplus2', '100/100', 95000, 'online', 12, '0%', 40, 22, ${"قياس مخزّن في المختبر"}, 'lab')`;
	const linkRows = [
		[
			"source",
			star,
			"router",
			ccr
		],
		[
			"source",
			fiber,
			"router",
			ccr
		],
		[
			"router",
			ccr,
			"tower",
			t1
		],
		[
			"router",
			ccr,
			"router",
			rb
		],
		[
			"router",
			rb,
			"tower",
			t2
		],
		[
			"tower",
			t1,
			"antenna",
			a1
		],
		[
			"tower",
			t2,
			"antenna",
			a2
		]
	];
	for (const l of linkRows) await sql`insert into links (id, tenant_id, from_kind, from_id, to_kind, to_id, origin)
      values (${id()}, ${tenantId}, ${l[0]}, ${l[1]}, ${l[2]}, ${l[3]}, 'lab')`;
	for (const p of [
		[
			"أحمد ناصر",
			"773001122",
			"الحبيلين",
			"ZN-1008",
			"برج الحبيلين",
			"قطاع شمال",
			"radfan.12",
			"منزلي-٨",
			9
		],
		[
			"نورة صالح",
			"771334455",
			"ردفان",
			"ZN-1014",
			"برج ردفان",
			"قطاع الشرق",
			"habilayn.03",
			"منزلي-٨",
			2
		],
		[
			"محل النور",
			"770998877",
			"الحبيلين",
			"ZN-1020",
			"برج الحبيلين",
			"قطاع السوق",
			"shop.04",
			"يوم-٢ميجا",
			0
		]
	]) await sql`insert into subscribers (
      id, tenant_id, name, phone, address, code, tower, antenna, service, account, plan_name, started_on, ends_on, status, origin
    ) values (
      ${id()}, ${tenantId}, ${p[0]}, ${p[1]}, ${p[2]}, ${p[3]}, ${p[4]}, ${p[5]}, 'PPPoE', ${p[6]}, ${p[7]},
      ${addDays(adenDay(), -20)}, ${addDays(adenDay(), p[8])}, ${p[8] <= 0 ? "due" : "active"}, 'lab'
    )`;
	const batch = `${tenantId}:lab:batch`;
	await sql`insert into voucher_batches (id, tenant_id, router_id, profile_name, price, card_type, qty, prefix, note, origin)
    values (${batch}, ${tenantId}, ${ccr}, 'يوم-٢ميجا', 200, 'same', 8, 'ZN', 'دفعة مختبر', 'lab')`;
	const cards = [
		"ZN10421",
		"ZN10422",
		"ZN10423",
		"ZN10424",
		"ZN18801",
		"ZN18802",
		"ZN18803",
		"ZN18804"
	];
	for (let i = 0; i < cards.length; i++) {
		const cipher = await seal(sql, cards[i]);
		await sql`insert into vouchers (
      id, tenant_id, batch_id, router_id, username, secret_cipher, card_type, profile_name, price, validity, status, origin
    ) values (
      ${`${tenantId}:lab:card:${i}`}, ${tenantId}, ${batch}, ${ccr}, ${cards[i]}, ${cipher}, 'same', 'يوم-٢ميجا', 200, '١ يوم',
      ${i < 3 ? "sold" : "new"}, 'lab'
    )`;
	}
	const amounts = [
		42e3,
		38e3,
		51e3,
		46e3,
		33e3,
		61e3,
		27500
	];
	for (let i = 0; i < amounts.length; i++) await sql`insert into sales (id, tenant_id, day, amount, qty, note, origin)
      values (${id()}, ${tenantId}, ${addDays(adenDay(), i - 6)}, ${amounts[i]}, ${8 + i}, 'مبيعات كروت المختبر', 'lab')`;
	await sql`insert into alerts (id, tenant_id, severity, title, detail, router_id, origin)
    values (${id()}, ${tenantId}, 'danger', ${"انقطاع راوتر"}, ${"RB الموسطة لا يجيب في آخر فحص مخزّن"}, ${off}, 'lab')`;
	await sql`insert into alerts (id, tenant_id, severity, title, detail, router_id, origin)
    values (${id()}, ${tenantId}, 'warn', ${"ارتفاع المعالج"}, ${"RB ردفان عند ٧٨٪ في القراءة المخزّنة"}, ${rb}, 'lab')`;
	for (let h = 0; h < 24; h++) {
		const down = h < 6 ? 36 + h * 4 : h >= 17 && h <= 23 ? 160 + (h - 17) * 14 : 80 + h * 2;
		await sql`insert into traffic_samples (id, tenant_id, router_id, hour, down_mbps, up_mbps, origin)
      values (${id()}, ${tenantId}, ${ccr}, ${String(h).padStart(2, "0")}, ${down}, ${Math.round(down * .18)}, 'lab')`;
	}
	await sql`insert into card_templates (
    id, tenant_id, name, accent, show_user, show_pass, show_price, show_validity, show_profile, show_qr, footer, origin
  ) values (
    ${`${tenantId}:lab:tpl`}, ${tenantId}, ${"كرت الزهر"}, 'cyan', true, true, true, true, true, true,
    ${"الدعم عبر نقطة البيع"}, 'lab'
  )`;
	await sql`insert into staff (id, tenant_id, name, role, phone, active)
    values (${`${tenantId}:staff:1`}, ${tenantId}, ${"فهد العزي"}, 'tech', '770112233', true)`;
	await sql`insert into staff (id, tenant_id, name, role, phone, active)
    values (${`${tenantId}:staff:2`}, ${tenantId}, ${"أمل محمد"}, 'accountant', '771445566', true)`;
}
async function clearLab(sql, tenantId) {
	for (const table of [
		"traffic_samples",
		"interfaces",
		"profiles",
		"hotspot_users",
		"pppoe_users",
		"sessions",
		"devices",
		"antennas",
		"links",
		"towers",
		"sources",
		"subscribers",
		"vouchers",
		"voucher_batches",
		"card_templates",
		"sales",
		"alerts",
		"backups",
		"script_runs"
	]) await sql.query(`delete from ${table} where tenant_id = $1 and origin = 'lab'`, [tenantId]);
	await sql`delete from routers where tenant_id = ${tenantId} and mode = 'lab'`;
	await sql`delete from staff where tenant_id = ${tenantId} and id like ${`${tenantId}:staff:%`}`;
}
function encodeLen(len) {
	if (len < 128) return Buffer.from([len]);
	if (len < 16384) return Buffer.from([len >> 8 & 255 | 128, len & 255]);
	if (len < 2097152) return Buffer.from([
		len >> 16 & 255 | 192,
		len >> 8 & 255,
		len & 255
	]);
	if (len < 268435456) return Buffer.from([
		len >> 24 & 255 | 224,
		len >> 16 & 255,
		len >> 8 & 255,
		len & 255
	]);
	const b = Buffer.alloc(5);
	b[0] = 240;
	b.writeUInt32BE(len, 1);
	return b;
}
function encodeSentence(words) {
	const parts = words.map((w) => {
		const body = Buffer.from(w, "utf8");
		return Buffer.concat([encodeLen(body.length), body]);
	});
	return Buffer.concat([...parts, Buffer.from([0])]);
}
var NeedTrust = class extends Error {
	fingerprint;
	constructor(fingerprint) {
		super("NEED_TRUST");
		this.fingerprint = fingerprint;
	}
};
function fingerprintOf(cert) {
	return createHash("sha256").update(cert.raw).digest("hex").toUpperCase().replace(/(.{2})(?=.)/g, "$1:");
}
async function withApi(opts, run) {
	const socket = await new Promise((resolve, reject) => {
		let settled = false;
		const finish = (err, sock) => {
			if (settled) return;
			settled = true;
			if (err || !sock) reject(err ?? /* @__PURE__ */ new Error("تعذر الاتصال"));
			else resolve(sock);
		};
		const timer = setTimeout(() => {
			sock.destroy();
			finish(/* @__PURE__ */ new Error("انتهت مهلة الاتصال (٦ ثوانٍ)"));
		}, 6e3);
		const sock = opts.tls ? tls.connect({
			host: opts.host,
			port: opts.port,
			rejectUnauthorized: false,
			servername: /[a-z]/i.test(opts.host) ? opts.host : void 0
		}, () => {
			clearTimeout(timer);
			const cert = sock.getPeerCertificate();
			if (!cert?.raw) {
				sock.destroy();
				finish(/* @__PURE__ */ new Error("لم تُعرض شهادة TLS"));
				return;
			}
			const fp = fingerprintOf(cert);
			if (!opts.fingerprint) {
				sock.destroy();
				finish(new NeedTrust(fp));
				return;
			}
			if (fp !== opts.fingerprint) {
				sock.destroy();
				finish(/* @__PURE__ */ new Error("بصمة الشهادة تغيّرت عن البصمة الموثوقة. أُوقف الربط ولم تُرسل الأوامر."));
				return;
			}
			finish(null, sock);
		}) : net.connect({
			host: opts.host,
			port: opts.port
		}, () => {
			clearTimeout(timer);
			finish(null, sock);
		});
		sock.once("error", (err) => {
			clearTimeout(timer);
			finish(/* @__PURE__ */ new Error(`تعذر الاتصال: ${err.message}`));
		});
	});
	let buf = Buffer.alloc(0);
	let ended = null;
	const waiters = [];
	const wake = (err) => {
		const w = waiters.shift();
		if (w) w(err);
	};
	socket.on("data", (chunk) => {
		buf = Buffer.concat([buf, chunk]);
		if (buf.length > 2e6) {
			socket.destroy(/* @__PURE__ */ new Error("رد الراوتر أكبر من الحد"));
			return;
		}
		wake(null);
	});
	socket.on("error", (err) => {
		ended = err;
		wake(err);
	});
	socket.on("close", () => {
		if (!ended) ended = /* @__PURE__ */ new Error("انقطع الاتصال");
		wake(ended);
	});
	async function need(n) {
		while (buf.length < n) {
			if (ended && buf.length < n) throw ended;
			await new Promise((resolve, reject) => {
				waiters.push((err) => err && buf.length < n ? reject(err) : resolve());
			});
		}
	}
	async function readLen() {
		await need(1);
		const c = buf[0] ?? 0;
		const take = (n) => {
			buf = buf.subarray(n);
		};
		if ((c & 128) === 0) {
			take(1);
			return c;
		}
		if ((c & 192) === 128) {
			await need(2);
			const len = ((c & 63) << 8) + (buf[1] ?? 0);
			take(2);
			return len;
		}
		if ((c & 224) === 192) {
			await need(3);
			const len = ((c & 31) << 16) + ((buf[1] ?? 0) << 8) + (buf[2] ?? 0);
			take(3);
			return len;
		}
		if ((c & 240) === 224) {
			await need(4);
			const len = ((c & 15) << 24) + ((buf[1] ?? 0) << 16) + ((buf[2] ?? 0) << 8) + (buf[3] ?? 0);
			take(4);
			return len;
		}
		await need(5);
		const len = buf.readUInt32BE(1);
		take(5);
		return len;
	}
	async function readSentence() {
		const words = [];
		for (;;) {
			const len = await readLen();
			if (len === 0) return words;
			await need(len);
			words.push(buf.subarray(0, len).toString("utf8"));
			buf = buf.subarray(len);
		}
	}
	async function call(words) {
		for (const w of words) safeToken(w.replace(/^=[^=]*=/, ""), "الأمر");
		socket.write(encodeSentence(words));
		const sentences = [];
		const killer = setTimeout(() => socket.destroy(/* @__PURE__ */ new Error("انتهت مهلة رد الراوتر")), 8e3);
		try {
			for (;;) {
				const sentence = await readSentence();
				if (!sentence.length) continue;
				sentences.push(sentence);
				const tag = sentence[0];
				if (tag === "!done" || tag === "!trap" || tag === "!fatal") break;
				if (sentences.length > 400) throw new Error("الرد تجاوز ٤٠٠ سجل. أُوقفت القراءة.");
			}
		} finally {
			clearTimeout(killer);
		}
		const trap = sentences.find((s) => s[0] === "!trap" || s[0] === "!fatal");
		if (trap) {
			const msg = trap.find((w) => w.startsWith("=message="))?.slice(9) ?? "رفض الراوتر الأمر";
			throw new Error(msg);
		}
		return sentences;
	}
	try {
		const ret = (await call([
			"/login",
			`=name=${opts.user}`,
			`=password=${opts.password}`
		])).flat().find((w) => w.startsWith("=ret="));
		if (ret) {
			const challenge = Buffer.from(ret.slice(5), "hex");
			const hash = createHash("md5").update(Buffer.concat([
				Buffer.from([0]),
				Buffer.from(opts.password, "utf8"),
				challenge
			])).digest("hex");
			await call([
				"/login",
				`=name=${opts.user}`,
				`=response=00${hash}`
			]);
		}
		await run(call);
	} finally {
		socket.destroy();
	}
}
function records(sentences) {
	return sentences.filter((s) => s[0] === "!re").map((s) => {
		const rec = {};
		for (const w of s) {
			if (!w.startsWith("=")) continue;
			const cut = w.indexOf("=", 1);
			if (cut > 1) rec[w.slice(1, cut)] = w.slice(cut + 1);
		}
		return rec;
	});
}
async function optional(call, words) {
	try {
		return records(await call(words));
	} catch {
		return [];
	}
}
function pct(free, total) {
	const f = Number(free);
	const t = Number(total);
	if (!Number.isFinite(f) || !Number.isFinite(t) || t <= 0) return null;
	return Math.max(0, Math.min(100, Math.round((t - f) / t * 100)));
}
async function pullRouter(sql, row, trust, userId) {
	const routerId = text(row.id);
	const tenantId = text(row.tenant_id);
	const host = text(row.host);
	const port = num(row.port) ?? 8729;
	const tlsOn = text(row.conn_type) !== "api";
	assertHost(host, port);
	const password = await open(sql, str(row.secret_cipher));
	if (!password) throw new Error("لا توجد كلمة مرور محفوظة لهذا الراوتر");
	const fingerprint = trust?.trim() || str(row.fingerprint);
	if (trust?.trim()) await sql`update routers set fingerprint = ${trust.trim()} where id = ${routerId} and tenant_id = ${tenantId}`;
	let summary = "";
	let report = null;
	await withApi({
		host,
		port,
		tls: tlsOn,
		fingerprint,
		user: text(row.api_user),
		password
	}, async (call) => {
		const identity = records(await call(["/system/identity/print"]))[0] ?? {};
		const resource = records(await call(["/system/resource/print"]))[0] ?? {};
		const board = records(await call(["/system/routerboard/print"]))[0] ?? {};
		async function read(words) {
			try {
				return { ok: true, rows: records(await call(words)), error: "" };
			} catch (error) {
				return { ok: false, rows: [], error: error instanceof Error ? error.message : "فشلت القراءة" };
			}
		}
		const ifaceRead = await read(["/interface/print"]);
		const hsRead = await read(["/ip/hotspot/active/print"]);
		const pppRead = await read(["/ppp/active/print"]);
		const hsProfiles = await optional(call, ["/ip/hotspot/user/profile/print"]);
		const pppProfiles = await optional(call, ["/ppp/profile/print"]);
		const at = (/* @__PURE__ */ new Date()).toISOString();
		const identName = identity.name ?? "";
		const version = resource.version ?? "";
		const boardName = resource["board-name"] ?? "";
		const cpuN = resource["cpu-load"] == null || resource["cpu-load"] === "" ? null : Number(resource["cpu-load"]);
		const ram = memoryLine(resource["free-memory"], resource["total-memory"]);
		const hdd = memoryLine(resource["free-hdd-space"], resource["total-hdd-space"]);
		const wan = text(row.wan_interface);
		let traffic = { ok: false, error: "منفذ الإنترنت غير محدد في بطاقة الراوتر", rx: null, tx: null, text: "" };
		if (wan) {
			const mon = await read(["/interface/monitor-traffic", `=interface=${wan}`, "=once="]);
			const sample = mon.rows[0];
			const rx = Number(sample?.["rx-bits-per-second"]);
			const tx = Number(sample?.["tx-bits-per-second"]);
			if (!mon.ok) traffic = { ok: false, error: mon.error, rx: null, tx: null, text: "" };
			else if (!sample || !Number.isFinite(rx) || !Number.isFinite(tx)) traffic = { ok: false, error: "رد مراقبة المنفذ بلا سرعة رفع أو تنزيل", rx: null, tx: null, text: "" };
			else traffic = {
				ok: true,
				error: "",
				rx: String(Math.round(rx)),
				tx: String(Math.round(tx)),
				text: `${wan} · تنزيل ${bpsLabel(rx)} · رفع ${bpsLabel(tx)}`
			};
		}
		const cpuOk = cpuN != null && Number.isFinite(cpuN);
		const checks = [
			{ id: "identity", label: "هوية الراوتر", ok: Boolean(identName), value: identName, error: identName ? "" : "لم يرجع الراوتر اسم الهوية" },
			{ id: "version", label: "إصدار RouterOS", ok: Boolean(version), value: version, error: version ? "" : "لم يرجع الراوتر رقم الإصدار" },
			{ id: "board", label: "اسم اللوحة", ok: Boolean(boardName), value: [boardName, board.model].filter(Boolean).join(" · "), error: boardName ? "" : "لم يرجع الراوتر board-name" },
			{ id: "cpu", label: "حمل المعالج", ok: cpuOk, value: cpuOk ? `${cpuN}٪` : "", error: cpuOk ? "" : "لم يرجع الراوتر cpu-load" },
			{ id: "memory", label: "الذاكرة والقرص", ok: ram.ok && hdd.ok, value: ram.ok && hdd.ok ? `RAM ${ram.text} · HDD ${hdd.text}` : "", error: ram.ok && hdd.ok ? "" : "الذاكرة أو القرص غير موجودين في قراءة الموارد" },
			{ id: "interfaces", label: "الواجهات وحالتها", ok: ifaceRead.ok && ifaceRead.rows.length > 0, value: ifaceRead.rows.map((iface) => `${iface.name ?? "?"} ${iface.running === "true" ? "يعمل" : "متوقف"}`).join(" · "), error: !ifaceRead.ok ? ifaceRead.error : ifaceRead.rows.length ? "" : "لم يرجع الراوتر أي واجهة" },
			{ id: "hotspot", label: "جلسات Hotspot النشطة", ok: hsRead.ok, value: hsRead.ok ? String(hsRead.rows.length) : "", error: hsRead.ok ? "" : hsRead.error },
			{ id: "pppoe", label: "جلسات PPPoE النشطة", ok: pppRead.ok, value: pppRead.ok ? String(pppRead.rows.length) : "", error: pppRead.ok ? "" : pppRead.error },
			{ id: "traffic", label: "حركة منفذ الإنترنت", ok: traffic.ok, value: traffic.text, error: traffic.error },
			{ id: "status", label: "وقت التحديث وحالة الاتصال", ok: true, value: `${at} · online`, error: "" }
		];
		const accepted = checks.every((item) => item.ok);
		const failed = checks.filter((item) => !item.ok).map((item) => item.label).join("، ");
		report = { source: "live", at, accepted, error: accepted ? "" : failed, checks };
		const temp = resource["cpu-temperature"] ?? board.temperature ?? null;
		const voltage = resource["voltage"] ?? board["voltage"] ?? null;
		await sql`update routers set
        status = 'online',
        ros_version = ${version || null},
        model = ${board.model ?? null},
        board = ${boardName || null},
        identity = ${identName || null},
        cpu = ${cpuOk ? cpuN : null},
        ram = ${ram.used},
        storage = ${hdd.used},
        ram_bytes = ${ram.text || null},
        hdd_bytes = ${hdd.text || null},
        hotspot_active = ${hsRead.ok ? hsRead.rows.length : null},
        pppoe_active = ${pppRead.ok ? pppRead.rows.length : null},
        rx_bps = ${traffic.rx},
        tx_bps = ${traffic.tx},
        temperature = ${temp},
        voltage = ${voltage},
        uptime = ${resource.uptime ?? null},
        download_mbps = ${traffic.ok ? Math.round(Number(traffic.rx) / 1e6) : null},
        upload_mbps = ${traffic.ok ? Math.round(Number(traffic.tx) / 1e6) : null},
        last_seen = ${at},
        last_sync = ${at},
        last_attempt = ${at},
        last_error = ${accepted ? null : `القبول لم يكتمل: ${failed}`},
        sync_report = ${JSON.stringify(report)}
        where id = ${routerId} and tenant_id = ${tenantId}`;
		if (ifaceRead.ok) {
			await sql`delete from interfaces where router_id = ${routerId} and tenant_id = ${tenantId} and origin = 'sync'`;
			for (const iface of ifaceRead.rows) await sql`insert into interfaces (id, tenant_id, router_id, name, kind, running, comment, origin)
          values (${id()}, ${tenantId}, ${routerId}, ${iface.name ?? ""}, ${iface.type ?? ""}, ${iface.running === "true"}, ${iface.comment ?? ""}, 'sync')`;
		}
		if (hsRead.ok || pppRead.ok) {
			await sql`delete from sessions where router_id = ${routerId} and tenant_id = ${tenantId} and origin = 'sync'`;
			if (hsRead.ok) for (const s of hsRead.rows) await sql`insert into sessions (
          id, tenant_id, router_id, username, ip, mac, kind, source, started_at, rx_rate, tx_rate,
          bytes_in, bytes_out, ros_id, origin, tower, antenna, profile_name
        ) values (
          ${id()}, ${tenantId}, ${routerId}, ${s.user ?? s.name ?? ""}, ${s.address ?? ""}, ${s["mac-address"] ?? ""},
          'hotspot', 'authenticated', ${at}, ${s["limit-bytes-in"] ? null : null}, null,
          ${Number(s["bytes-in"] ?? 0) || 0}, ${Number(s["bytes-out"] ?? 0) || 0}, ${s[".id"] ?? null}, 'sync', '', '', ''
        )`;
			if (pppRead.ok) for (const s of pppRead.rows) await sql`insert into sessions (
          id, tenant_id, router_id, username, ip, mac, kind, source, started_at, bytes_in, bytes_out, ros_id, origin
        ) values (
          ${id()}, ${tenantId}, ${routerId}, ${s.name ?? ""}, ${s.address ?? ""}, ${s["caller-id"] ?? ""},
          'pppoe', 'authenticated', ${at},
          ${Number(s["bytes-in"] ?? 0) || 0}, ${Number(s["bytes-out"] ?? 0) || 0}, ${s[".id"] ?? null}, 'sync'
        )`;
		}
		await sql`delete from profiles where router_id = ${routerId} and tenant_id = ${tenantId} and origin = 'sync'`;
		for (const p of hsProfiles) {
			const rate = (p["rate-limit"] ?? "").split("/");
			await sql`insert into profiles (id, tenant_id, router_id, name, kind, rate_down, rate_up, shared_users, ros_id, origin, validity, data_limit)
          values (${id()}, ${tenantId}, ${routerId}, ${p.name ?? ""}, 'hotspot', ${rate[0] ?? ""}, ${rate[1] ?? ""}, ${Number(p["shared-users"] ?? 1) || 1}, ${p[".id"] ?? null}, 'sync', '', '')`;
		}
		for (const p of pppProfiles) {
			const rate = (p["rate-limit"] ?? "").split("/");
			await sql`insert into profiles (id, tenant_id, router_id, name, kind, rate_down, rate_up, ros_id, origin, validity, data_limit)
          values (${id()}, ${tenantId}, ${routerId}, ${p.name ?? ""}, 'pppoe', ${rate[0] ?? ""}, ${rate[1] ?? ""}, ${p[".id"] ?? null}, 'sync', '', '')`;
		}
		summary = accepted
			? `قُرئ ${identName} — إصدار ${version} — هوتسبوت ${hsRead.rows.length} — PPPoE ${pppRead.rows.length}`
			: `اتصل الراوتر ولم يكتمل القبول: ${failed}`;
	});
	await audit(sql, tenantId, userId, "مزامنة راوتر", routerId, summary);
	const note = privateHost(host) ? " العنوان خاص. يصل فقط إذا كانت المنصة داخل الشبكة أو عبر نفق." : "";
	return {
		ok: true,
		lab: false,
		accepted: Boolean(report?.accepted),
		needsTrust: false,
		fingerprint: fingerprint ?? "",
		message: `${summary}${note}`
	};
}
async function markOffline(sql, row, message, userId) {
	const routerId = text(row.id);
	const tenantId = text(row.tenant_id);
	const at = (/* @__PURE__ */ new Date()).toISOString();
	await sql`update routers set status = 'offline', last_error = ${message}, last_attempt = ${at}, sync_report = ${JSON.stringify(failedReport(at, message))}
    where id = ${routerId} and tenant_id = ${tenantId}`;
	if (!(await sql`select id from alerts where tenant_id = ${tenantId} and router_id = ${routerId} and acked = false and title = 'انقطاع راوتر' limit 1`)[0]) await sql`insert into alerts (id, tenant_id, severity, title, detail, router_id, origin)
      values (${id()}, ${tenantId}, 'danger', 'انقطاع راوتر', ${message}, ${routerId}, 'live')`;
	await audit(sql, tenantId, userId, "فشل اتصال", routerId, message);
}
async function getWorkspace(userId) {
	const { sql, tenant } = await ensure(userId);
	const license = await licenseOf(sql, tenant.id);
	const flags = await sql`select
    count(*) filter (where mode = 'lab')::int as lab,
    count(*) filter (where mode = 'live')::int as live
    from routers where tenant_id = ${tenant.id}`;
	return {
		tenant: {
			id: tenant.id,
			name: tenant.name,
			area: tenant.area,
			logo: tenant.logo
		},
		license,
		hasLab: (num(flags[0]?.lab) ?? 0) > 0,
		hasLive: (num(flags[0]?.live) ?? 0) > 0,
		generatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
async function getDashboard(userId) {
	const { sql, tenant } = await ensure(userId);
	const tid = tenant.id;
	const count = async (query, params = [tid]) => {
		return num((await sql.query(query, params))[0]?.n) ?? 0;
	};
	const routers = (await sql`select * from routers where tenant_id = ${tid} order by created_at`).map(mapRouter);
	const today = adenDay();
	const month = today.slice(0, 7);
	const salesToday = await count(`select coalesce(sum(amount),0)::int as n from sales where tenant_id = $1 and day = $2`, [tid, today]);
	const salesMonth = await count(`select coalesce(sum(amount),0)::int as n from sales where tenant_id = $1 and day like $2`, [tid, `${month}%`]);
	const trafficRouter = routers.find((r) => r.mode !== "lab" && r.lastSync) ?? routers.find((r) => r.mode === "lab") ?? routers[0];
	const samples = trafficRouter ? await sql`select hour, down_mbps, up_mbps, origin from traffic_samples where tenant_id = ${tid} and router_id = ${trafficRouter.id} order by hour` : [];
	const sessions = await sql`select username, ip, kind, source, tower, profile_name, started_at, rx_rate, tx_rate, origin
    from sessions where tenant_id = ${tid} order by started_at desc limit 6`;
	const alerts = await sql`select id, severity, title, detail, acked, created_at, origin
    from alerts where tenant_id = ${tid} and acked = false order by created_at desc limit 6`;
	return {
		tenant: {
			name: tenant.name,
			area: tenant.area
		},
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		hasLab: routers.some((r) => r.mode === "lab"),
		stats: {
			routers: routers.length,
			online: routers.filter((r) => r.status === "online").length,
			offline: routers.filter((r) => r.status === "offline").length,
			liveOnline: routers.filter((r) => r.mode !== "lab" && r.status === "online" && r.report?.accepted).length,
			labOnline: routers.filter((r) => r.mode === "lab" && r.status === "online").length,
			subscribers: await count(`select count(*)::int as n from subscribers where tenant_id = $1`),
			hotspotUsers: await count(`select count(*)::int as n from hotspot_users where tenant_id = $1`),
			pppoeUsers: await count(`select count(*)::int as n from pppoe_users where tenant_id = $1`),
			active: await count(`select count(*)::int as n from sessions where tenant_id = $1`),
			hotspotActive: await count(`select count(*)::int as n from sessions where tenant_id = $1 and kind = 'hotspot'`),
			pppoeActive: await count(`select count(*)::int as n from sessions where tenant_id = $1 and kind = 'pppoe'`),
			liveActive: await count(`select count(*)::int as n from sessions where tenant_id = $1 and origin = 'sync'`),
			labActive: await count(`select count(*)::int as n from sessions where tenant_id = $1 and origin = 'lab'`),
			devices: await count(`select count(*)::int as n from devices where tenant_id = $1`),
			towers: await count(`select count(*)::int as n from towers where tenant_id = $1`),
			antennas: await count(`select count(*)::int as n from antennas where tenant_id = $1`),
			alerts: await count(`select count(*)::int as n from alerts where tenant_id = $1 and acked = false`),
			faults: await count(`select count(*)::int as n from alerts where tenant_id = $1 and acked = false and severity = 'danger'`)
		},
		finance: {
			today: salesToday,
			month: salesMonth,
			sold: await count(`select count(*)::int as n from vouchers where tenant_id = $1 and status = 'sold'`),
			left: await count(`select count(*)::int as n from vouchers where tenant_id = $1 and status = 'new'`),
			resellerDue: null
		},
		routers,
		traffic: samples.map((s) => ({
			hour: text(s.hour),
			down: num(s.down_mbps) ?? 0,
			up: num(s.up_mbps) ?? 0,
			origin: text(s.origin)
		})),
		trafficRouter: trafficRouter?.name ?? "",
		sessions: sessions.map((s) => ({
			username: text(s.username),
			ip: text(s.ip),
			kind: text(s.kind),
			source: text(s.source),
			tower: text(s.tower),
			profile: text(s.profile_name),
			startedAt: text(s.started_at),
			down: str(s.rx_rate),
			up: str(s.tx_rate),
			origin: text(s.origin)
		})),
		alerts: alerts.map((a) => ({
			id: text(a.id),
			severity: text(a.severity),
			title: text(a.title),
			detail: text(a.detail),
			origin: text(a.origin),
			createdAt: text(a.created_at)
		}))
	};
}
async function listRouters(userId) {
	const { sql, tenant } = await ensure(userId);
	const rows = await sql`select * from routers where tenant_id = ${tenant.id} order by created_at`;
	const license = await licenseOf(sql, tenant.id);
	return {
		routers: rows.map(mapRouter),
		license
	};
}
async function getRouter(userId, routerId) {
	const { sql, tenant } = await ensure(userId);
	const rows = await sql`select * from routers where id = ${routerId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("الراوتر غير موجود");
	const ifaces = await sql`select name, kind, running, comment, origin from interfaces where router_id = ${routerId} and tenant_id = ${tenant.id} order by name`;
	const sessions = await sql`select id, username, ip, mac, kind, source, started_at, bytes_in, bytes_out
    from sessions where router_id = ${routerId} and tenant_id = ${tenant.id} order by started_at desc limit 30`;
	return {
		router: mapRouter(rows[0]),
		interfaces: ifaces.map((f) => ({
			name: text(f.name),
			kind: text(f.kind),
			running: flag(f.running),
			comment: text(f.comment),
			origin: text(f.origin)
		})),
		sessions: sessions.map((s) => ({
			id: text(s.id),
			username: text(s.username),
			ip: text(s.ip),
			mac: text(s.mac),
			kind: text(s.kind),
			source: text(s.source),
			startedAt: text(s.started_at),
			bytesIn: num(s.bytes_in) ?? 0,
			bytesOut: num(s.bytes_out) ?? 0
		}))
	};
}
async function saveRouter(userId, input) {
	const { sql, tenant } = await ensure(userId);
	const license = await licenseOf(sql, tenant.id);
	assertWritable(license.status);
	const port = input.connType === "api" ? 8728 : input.port === 8728 ? 8728 : 8729;
	const conn = port === 8728 ? "api" : "api-ssl";
	if (input.host.trim()) assertHost(input.host.trim(), port);
	safeToken(input.apiUser || "x", "المستخدم");
	if (input.id) {
		if (!(await sql`select id, mode from routers where id = ${input.id} and tenant_id = ${tenant.id}`)[0]) throw new Error("الراوتر غير موجود");
		const cipher = input.password ? await seal(sql, input.password) : null;
		if (cipher) await sql`update routers set name = ${input.name}, host = ${input.host.trim()}, port = ${port}, conn_type = ${conn},
        api_user = ${input.apiUser}, secret_cipher = ${cipher}, ros_hint = ${input.rosHint}, site = ${input.site},
        tower = ${input.tower}, notes = ${input.notes}, wan_interface = ${input.wanInterface}
        where id = ${input.id} and tenant_id = ${tenant.id}`;
		else await sql`update routers set name = ${input.name}, host = ${input.host.trim()}, port = ${port}, conn_type = ${conn},
        api_user = ${input.apiUser}, ros_hint = ${input.rosHint}, site = ${input.site}, tower = ${input.tower},
        notes = ${input.notes}, wan_interface = ${input.wanInterface}
        where id = ${input.id} and tenant_id = ${tenant.id}`;
		await audit(sql, tenant.id, userId, "تعديل راوتر", input.id, input.name);
		return { id: input.id };
	}
	if (license.liveRouters >= license.routerLimit) throw new Error(`حد الراوترات الحقيقية لهذه الباقة ${license.routerLimit}. راوترات المختبر لا تُحتسب.`);
	const routerId = id();
	const cipher = input.password ? await seal(sql, input.password) : null;
	await sql`insert into routers (
    id, tenant_id, name, host, port, conn_type, api_user, secret_cipher, ros_hint, site, tower, notes, wan_interface, mode, status
  ) values (
    ${routerId}, ${tenant.id}, ${input.name}, ${input.host.trim()}, ${port}, ${conn}, ${input.apiUser}, ${cipher},
    ${input.rosHint}, ${input.site}, ${input.tower}, ${input.notes}, ${input.wanInterface}, 'live', 'unknown'
  )`;
	await audit(sql, tenant.id, userId, "إضافة راوتر", routerId, input.name);
	return { id: routerId };
}
async function connectRouter(userId, routerId, trust) {
	const { sql, tenant } = await ensure(userId);
	const rows = await sql`select * from routers where id = ${routerId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("الراوتر غير موجود");
	if (text(rows[0].mode) === "lab") return {
		ok: false,
		lab: true,
		accepted: false,
		needsTrust: false,
		fingerprint: "",
		message: "هذا راوتر مختبر. لا يُجرى اتصال، والأرقام المعروضة نسخة مخزّنة وليست قراءة حية."
	};
	try {
		return await pullRouter(sql, rows[0], trust, userId);
	} catch (error) {
		if (error instanceof NeedTrust) return {
			ok: false,
			lab: false,
			accepted: false,
			needsTrust: true,
			fingerprint: error.fingerprint,
			message: "الشهادة غير مثبتة في المنصة. طابق البصمة ثم أكّد الثقة. لم تُرسل كلمة المرور بعد."
		};
		const message = error instanceof Error ? error.message : "فشل الاتصال";
		await markOffline(sql, rows[0], message, userId);
		return {
			ok: false,
			lab: false,
			accepted: false,
			needsTrust: false,
			fingerprint: "",
			message
		};
	}
}
async function deleteRouter(userId, routerId) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const rows = await sql`select name from routers where id = ${routerId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("الراوتر غير موجود");
	for (const table of [
		"interfaces",
		"profiles",
		"hotspot_users",
		"pppoe_users",
		"sessions",
		"traffic_samples"
	]) await sql.query(`delete from ${table} where router_id = $1 and tenant_id = $2`, [routerId, tenant.id]);
	await sql`delete from routers where id = ${routerId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "حذف راوتر", routerId, text(rows[0].name));
	return { ok: true };
}
async function rebootRouter(userId, routerId, confirmName) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const rows = await sql`select * from routers where id = ${routerId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("الراوتر غير موجود");
	if (confirmName.trim() !== text(rows[0].name)) throw new Error("اسم التأكيد لا يطابق اسم الراوتر");
	if (text(rows[0].mode) !== "lab" && text(rows[0].conn_type) !== "api" && !str(rows[0].fingerprint)) throw new Error("ثبّت بصمة الشهادة من زر المزامنة قبل إعادة التشغيل");
	if (text(rows[0].mode) === "lab") {
		await sql`update routers set uptime = '0s', status = 'online' where id = ${routerId}`;
		await audit(sql, tenant.id, userId, "إعادة تشغيل مختبر", routerId, "لم يُرسل أمر إلى جهاز حقيقي");
		return {
			ok: true,
			message: "أُعيد ضبط عداد تشغيل المختبر فقط. لم يُرسل أمر إلى أي جهاز."
		};
	}
	const password = await open(sql, str(rows[0].secret_cipher));
	await withApi({
		host: text(rows[0].host),
		port: num(rows[0].port) ?? 8729,
		tls: text(rows[0].conn_type) !== "api",
		fingerprint: str(rows[0].fingerprint),
		user: text(rows[0].api_user),
		password
	}, async (call) => {
		try {
			await call(["/system/reboot"]);
		} catch (error) {
			const message = error instanceof Error ? error.message : "";
			if (!message.includes("انقطع") && !message.includes("انتهت")) throw error;
		}
	});
	await sql`update routers set status = 'unknown', uptime = null where id = ${routerId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "إعادة تشغيل", routerId, text(rows[0].name));
	return {
		ok: true,
		message: "أُرسل أمر إعادة التشغيل. ستنقطع الجلسة حتى يعود الجهاز."
	};
}
async function listSessions(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select s.id, s.username, s.ip, s.mac, s.kind, s.source, s.tower, s.antenna,
      s.started_at, s.rx_rate, s.tx_rate, s.bytes_in, s.bytes_out, s.profile_name, s.origin, r.name as router, r.mode
    from sessions s join routers r on r.id = s.router_id
    where s.tenant_id = ${tenant.id}
    order by s.started_at desc limit 400`).map((s) => ({
		id: text(s.id),
		username: text(s.username),
		ip: text(s.ip),
		mac: text(s.mac),
		kind: text(s.kind),
		source: text(s.source),
		tower: text(s.tower),
		antenna: text(s.antenna),
		startedAt: text(s.started_at),
		down: str(s.rx_rate),
		up: str(s.tx_rate),
		bytesIn: num(s.bytes_in) ?? 0,
		bytesOut: num(s.bytes_out) ?? 0,
		profile: text(s.profile_name),
		origin: text(s.origin),
		router: text(s.router),
		mode: text(s.mode)
	}));
}
async function disconnectSession(userId, sessionId) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const row = (await sql`select s.id, s.username, s.kind, s.ros_id, s.origin, s.router_id, r.mode, r.host, r.port, r.conn_type, r.api_user, r.secret_cipher, r.fingerprint, r.name as router
    from sessions s join routers r on r.id = s.router_id
    where s.id = ${sessionId} and s.tenant_id = ${tenant.id}`)[0];
	if (!row) throw new Error("الجلسة غير موجودة");
	if (text(row.mode) === "live") {
		if (!str(row.ros_id)) throw new Error("لا يوجد معرّف جلسة على الراوتر. زامن الجهاز ثم أعد المحاولة.");
		const password = await open(sql, str(row.secret_cipher));
		const path = text(row.kind) === "pppoe" ? "/ppp/active/remove" : "/ip/hotspot/active/remove";
		await withApi({
			host: text(row.host),
			port: num(row.port) ?? 8729,
			tls: text(row.conn_type) !== "api",
			fingerprint: str(row.fingerprint),
			user: text(row.api_user),
			password
		}, async (call) => {
			await call([path, `=.id=${text(row.ros_id)}`]);
		});
	}
	await sql`delete from sessions where id = ${sessionId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "فصل جلسة", sessionId, `${text(row.username)} على ${text(row.router)}${text(row.mode) === "lab" ? " — مختبر، لم يُرسل أمر لجهاز" : ""}`);
	return {
		ok: true,
		message: text(row.mode) === "lab" ? "أُزيلت جلسة المختبر. لم يُفصل أحد على جهاز حقيقي." : "فُصلت الجلسة على الراوتر."
	};
}
async function userRows(sql, table, tenantId) {
	const rows = await sql.query(`select u.*, r.name as router, r.mode from ${table} u join routers r on r.id = u.router_id where u.tenant_id = $1 order by u.created_at desc limit 400`, [tenantId]);
	const mapped = [];
	for (const row of rows) mapped.push({
		id: text(row.id),
		routerId: text(row.router_id),
		router: text(row.router),
		mode: text(row.mode),
		username: text(row.username),
		password: await open(sql, str(row.secret_cipher)),
		profile: text(row.profile_name),
		mac: text(row.mac),
		remoteAddress: text(row.remote_address),
		comment: text(row.comment),
		disabled: flag(row.disabled),
		expiresOn: str(row.expires_on),
		bytesIn: num(row.bytes_in) ?? 0,
		bytesOut: num(row.bytes_out) ?? 0,
		origin: text(row.origin)
	});
	return mapped;
}
async function listHotspot(userId) {
	const { sql, tenant } = await ensure(userId);
	return userRows(sql, "hotspot_users", tenant.id);
}
async function listPppoe(userId) {
	const { sql, tenant } = await ensure(userId);
	return userRows(sql, "pppoe_users", tenant.id);
}
async function routerFor(sql, tenantId, routerId) {
	const rows = await sql`select * from routers where id = ${routerId} and tenant_id = ${tenantId}`;
	if (!rows[0]) throw new Error("الراوتر غير موجود");
	return rows[0];
}
async function saveHotspot(userId, input) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	safeToken(input.username, "اسم المستخدم");
	safeToken(input.password || "x", "كلمة المرور");
	const router = await routerFor(sql, tenant.id, input.routerId);
	const cipher = input.password ? await seal(sql, input.password) : null;
	if (text(router.mode) === "live") {
		const password = input.password || "";
		if (!password) throw new Error("كلمة المرور مطلوبة عند الإنشاء على الراوتر");
		const stored = await open(sql, str(router.secret_cipher));
		let rosId = "";
		await withApi({
			host: text(router.host),
			port: num(router.port) ?? 8729,
			tls: text(router.conn_type) !== "api",
			fingerprint: str(router.fingerprint),
			user: text(router.api_user),
			password: stored
		}, async (call) => {
			const words = [
				"/ip/hotspot/user/add",
				`=name=${input.username}`,
				`=password=${password}`,
				`=profile=${input.profile || "default"}`,
				`=comment=${input.comment || "alzher"}`
			];
			if (input.mac) words.push(`=mac-address=${input.mac}`);
			rosId = (await call(words)).flat().find((w) => w.startsWith("=ret="))?.slice(5) ?? "";
		});
		const userIdRow = id();
		await sql`insert into hotspot_users (
      id, tenant_id, router_id, username, secret_cipher, profile_name, mac, comment, disabled, expires_on, ros_id, origin
    ) values (
      ${userIdRow}, ${tenant.id}, ${input.routerId}, ${input.username}, ${cipher}, ${input.profile}, ${input.mac ?? ""},
      ${input.comment}, ${input.disabled}, ${input.expiresOn || null}, ${rosId || null}, 'live'
    )`;
		await audit(sql, tenant.id, userId, "إضافة هوتسبوت", userIdRow, input.username);
		return {
			id: userIdRow,
			message: "أُنشئ المستخدم على الراوتر"
		};
	}
	const userIdRow = input.id ?? id();
	if (input.id) {
		if (cipher) await sql`update hotspot_users set username = ${input.username}, secret_cipher = ${cipher}, profile_name = ${input.profile},
        mac = ${input.mac ?? ""}, comment = ${input.comment}, disabled = ${input.disabled}, expires_on = ${input.expiresOn || null}
        where id = ${input.id} and tenant_id = ${tenant.id}`;
		else await sql`update hotspot_users set username = ${input.username}, profile_name = ${input.profile}, mac = ${input.mac ?? ""},
        comment = ${input.comment}, disabled = ${input.disabled}, expires_on = ${input.expiresOn || null}
        where id = ${input.id} and tenant_id = ${tenant.id}`;
	} else await sql`insert into hotspot_users (
      id, tenant_id, router_id, username, secret_cipher, profile_name, mac, comment, disabled, expires_on, origin
    ) values (
      ${userIdRow}, ${tenant.id}, ${input.routerId}, ${input.username}, ${cipher}, ${input.profile}, ${input.mac ?? ""},
      ${input.comment}, ${input.disabled}, ${input.expiresOn || null}, 'lab'
    )`;
	await audit(sql, tenant.id, userId, "حفظ هوتسبوت", userIdRow, `${input.username} — مختبر`);
	return {
		id: userIdRow,
		message: "حُفظ في المختبر ولم يُرسل إلى جهاز"
	};
}
async function savePppoe(userId, input) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	safeToken(input.username, "اسم المستخدم");
	const router = await routerFor(sql, tenant.id, input.routerId);
	const cipher = input.password ? await seal(sql, input.password) : null;
	if (text(router.mode) === "live") {
		if (!input.password) throw new Error("كلمة المرور مطلوبة");
		const stored = await open(sql, str(router.secret_cipher));
		let rosId = "";
		await withApi({
			host: text(router.host),
			port: num(router.port) ?? 8729,
			tls: text(router.conn_type) !== "api",
			fingerprint: str(router.fingerprint),
			user: text(router.api_user),
			password: stored
		}, async (call) => {
			const words = [
				"/ppp/secret/add",
				"=service=pppoe",
				`=name=${input.username}`,
				`=password=${input.password}`,
				`=profile=${input.profile || "default"}`,
				`=comment=${input.comment || "alzher"}`
			];
			if (input.remoteAddress) words.push(`=remote-address=${input.remoteAddress}`);
			rosId = (await call(words)).flat().find((w) => w.startsWith("=ret="))?.slice(5) ?? "";
		});
		const rowId = id();
		await sql`insert into pppoe_users (
      id, tenant_id, router_id, username, secret_cipher, profile_name, remote_address, comment, disabled, expires_on, ros_id, origin
    ) values (
      ${rowId}, ${tenant.id}, ${input.routerId}, ${input.username}, ${cipher}, ${input.profile}, ${input.remoteAddress ?? ""},
      ${input.comment}, false, ${input.expiresOn || null}, ${rosId || null}, 'live'
    )`;
		await audit(sql, tenant.id, userId, "إضافة PPPoE", rowId, input.username);
		return {
			id: rowId,
			message: "أُنشئ حساب PPPoE على الراوتر"
		};
	}
	const rowId = input.id ?? id();
	if (input.id) {
		await sql`update pppoe_users set username = ${input.username}, profile_name = ${input.profile},
      remote_address = ${input.remoteAddress ?? ""}, comment = ${input.comment}, disabled = ${input.disabled},
      expires_on = ${input.expiresOn || null}
      where id = ${input.id} and tenant_id = ${tenant.id}`;
		if (cipher) await sql`update pppoe_users set secret_cipher = ${cipher} where id = ${input.id} and tenant_id = ${tenant.id}`;
	} else await sql`insert into pppoe_users (
      id, tenant_id, router_id, username, secret_cipher, profile_name, remote_address, comment, disabled, expires_on, origin
    ) values (
      ${rowId}, ${tenant.id}, ${input.routerId}, ${input.username}, ${cipher}, ${input.profile}, ${input.remoteAddress ?? ""},
      ${input.comment}, ${input.disabled}, ${input.expiresOn || null}, 'lab'
    )`;
	await audit(sql, tenant.id, userId, "حفظ PPPoE", rowId, `${input.username} — مختبر`);
	return {
		id: rowId,
		message: "حُفظ في المختبر ولم يُرسل إلى جهاز"
	};
}
async function setUserDisabled(userId, kind, rowId, disabled) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const table = kind === "hotspot" ? "hotspot_users" : "pppoe_users";
	const row = (await sql.query(`select u.id, u.username, u.ros_id, r.mode from ${table} u join routers r on r.id = u.router_id where u.id = $1 and u.tenant_id = $2`, [rowId, tenant.id]))[0];
	if (!row) throw new Error("الحساب غير موجود");
	if (text(row.mode) === "live") throw new Error("تعطيل حساب على راوتر حقيقي يتم بعد مزامنة المعرّف. هذه النسخة تنفّذ الإنشاء والفصل، والتعطيـل الحي يُستكمل مع الاختبار على الجهاز حتى لا يُرسل أمر ناقص.");
	await sql.query(`update ${table} set disabled = $1 where id = $2 and tenant_id = $3`, [
		disabled,
		rowId,
		tenant.id
	]);
	await audit(sql, tenant.id, userId, disabled ? "تعطيل حساب" : "تفعيل حساب", rowId, text(row.username));
	return {
		ok: true,
		message: disabled ? "عُطّل في المختبر" : "فُعّل في المختبر"
	};
}
async function listProfiles(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select p.*, r.name as router, r.mode from profiles p join routers r on r.id = p.router_id
    where p.tenant_id = ${tenant.id} order by p.name`).map((p) => ({
		id: text(p.id),
		routerId: text(p.router_id),
		router: text(p.router),
		mode: text(p.mode),
		name: text(p.name),
		kind: text(p.kind),
		price: num(p.price) ?? 0,
		rateDown: text(p.rate_down),
		rateUp: text(p.rate_up),
		validity: text(p.validity),
		sharedUsers: num(p.shared_users) ?? 1,
		dataLimit: text(p.data_limit),
		origin: text(p.origin)
	}));
}
async function saveProfile(userId, input) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	safeToken(input.rateDown, "التحميل");
	safeToken(input.rateUp, "الرفع");
	const row = (await sql`select p.*, r.mode, r.host, r.port, r.conn_type, r.api_user, r.secret_cipher, r.fingerprint, r.name as router
    from profiles p join routers r on r.id = p.router_id
    where p.id = ${input.id} and p.tenant_id = ${tenant.id}`)[0];
	if (!row) throw new Error("البروفايل غير موجود");
	const before = `${text(row.rate_down)}/${text(row.rate_up)}`;
	const after = `${input.rateDown}/${input.rateUp}`;
	if (text(row.mode) === "live") {
		if (!str(row.ros_id)) throw new Error("البروفايل بلا معرّف على الراوتر. زامن الجهاز أولاً.");
		const path = text(row.kind) === "pppoe" ? "/ppp/profile/set" : "/ip/hotspot/user/profile/set";
		const password = await open(sql, str(row.secret_cipher));
		await withApi({
			host: text(row.host),
			port: num(row.port) ?? 8729,
			tls: text(row.conn_type) !== "api",
			fingerprint: str(row.fingerprint),
			user: text(row.api_user),
			password
		}, async (call) => {
			await call([
				path,
				`=.id=${text(row.ros_id)}`,
				`=rate-limit=${input.rateDown}/${input.rateUp}`,
				`=shared-users=${input.sharedUsers}`
			]);
		});
	}
	await sql`update profiles set price = ${input.price}, rate_down = ${input.rateDown}, rate_up = ${input.rateUp},
    validity = ${input.validity}, shared_users = ${input.sharedUsers}, data_limit = ${input.dataLimit}
    where id = ${input.id} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "تعديل بروفايل", input.id, `${text(row.name)}: ${before} → ${after}${text(row.mode) === "lab" ? " — مختبر" : " — أُرسل rate-limit"}`);
	return {
		ok: true,
		message: text(row.mode) === "lab" ? "حُفظت السرعة في المختبر. لم تُنشأ طوابير على جهاز." : `أُرسل rate-limit=${after} بدون إنشاء طوابير إضافية.`
	};
}
async function listVouchers(userId) {
	const { sql, tenant } = await ensure(userId);
	const batches = await sql`select id, profile_name, price, card_type, qty, prefix, note, created_at, origin
    from voucher_batches where tenant_id = ${tenant.id} order by created_at desc limit 40`;
	const cards = await sql`select * from vouchers where tenant_id = ${tenant.id} order by created_at desc limit 400`;
	const vouchers = [];
	for (const card of cards) vouchers.push({
		id: text(card.id),
		batchId: text(card.batch_id),
		routerId: text(card.router_id),
		username: text(card.username),
		password: await open(sql, str(card.secret_cipher)),
		cardType: text(card.card_type),
		profile: text(card.profile_name),
		price: num(card.price) ?? 0,
		validity: text(card.validity),
		status: text(card.status),
		origin: text(card.origin)
	});
	return {
		batches: batches.map((b) => ({
			id: text(b.id),
			profile: text(b.profile_name),
			price: num(b.price) ?? 0,
			cardType: text(b.card_type),
			qty: num(b.qty) ?? 0,
			prefix: text(b.prefix),
			note: text(b.note),
			createdAt: text(b.created_at),
			origin: text(b.origin)
		})),
		vouchers
	};
}
var ALPHABETS = {
	digits: "23456789",
	letters: "ABCDEFGHJKLMNPQRSTUVWXYZ",
	mixed: "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
};
function code(length, alphabet) {
	const bytes = randomBytes(length);
	let out = "";
	for (let i = 0; i < length; i++) out += alphabet[bytes[i] % alphabet.length];
	return out;
}
async function generateVouchers(userId, input) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	if (input.count < 1 || input.count > 100) throw new Error("عدد الكروت بين ١ و ١٠٠");
	safeToken(input.prefix || "Z", "البادئة");
	const router = await routerFor(sql, tenant.id, input.routerId);
	const alphabet = ALPHABETS[input.charset];
	const batchId = id();
	const made = [];
	const live = text(router.mode) === "live";
	if (live) {
		if (!await open(sql, str(router.secret_cipher))) throw new Error("اربط الراوتر وكلمة المرور قبل توليد كروت عليه");
	}
	await sql`insert into voucher_batches (id, tenant_id, router_id, profile_name, price, card_type, qty, prefix, note, origin)
    values (${batchId}, ${tenant.id}, ${input.routerId}, ${input.profile}, ${input.price}, ${input.cardType}, ${input.count}, ${input.prefix}, '', ${live ? "live" : "lab"})`;
	try {
		for (let n = 0; n < input.count; n++) {
			const username = `${input.prefix}${code(input.length, alphabet)}`;
			const password = input.cardType === "different" ? code(input.length, alphabet) : username;
			let rosId = null;
			if (live) {
				const stored = await open(sql, str(router.secret_cipher));
				await withApi({
					host: text(router.host),
					port: num(router.port) ?? 8729,
					tls: text(router.conn_type) !== "api",
					fingerprint: str(router.fingerprint),
					user: text(router.api_user),
					password: stored
				}, async (call) => {
					rosId = (await call([
						"/ip/hotspot/user/add",
						`=name=${username}`,
						`=password=${password}`,
						`=profile=${input.profile || "default"}`,
						"=comment=alzher-card"
					])).flat().find((w) => w.startsWith("=ret="))?.slice(5) ?? null;
				});
			}
			const cipher = await seal(sql, password);
			await sql`insert into vouchers (
        id, tenant_id, batch_id, router_id, username, secret_cipher, card_type, profile_name, price, validity, status, ros_id, origin
      ) values (
        ${id()}, ${tenant.id}, ${batchId}, ${input.routerId}, ${username}, ${cipher}, ${input.cardType}, ${input.profile},
        ${input.price}, ${input.validity}, 'new', ${rosId}, ${live ? "live" : "lab"}
      )`;
			made.push({
				username,
				password
			});
		}
	} catch (error) {
		await audit(sql, tenant.id, userId, "توليد كروت ناقص", batchId, `توقف بعد ${made.length}. ${error instanceof Error ? error.message : ""}`);
		throw new Error(`توقف التوليد بعد ${made.length} كرت. ${error instanceof Error ? error.message : "خطأ"}`);
	}
	if (input.recordSale && made.length) await sql`insert into sales (id, tenant_id, day, amount, qty, note, origin)
      values (${id()}, ${tenant.id}, ${adenDay()}, ${input.price * made.length}, ${made.length}, 'توليد كروت', ${live ? "live" : "lab"})`;
	await sql`update voucher_batches set qty = ${made.length} where id = ${batchId}`;
	await audit(sql, tenant.id, userId, "توليد كروت", batchId, `${made.length} ${input.profile} ${live ? "على الراوتر" : "في المختبر"}`);
	return {
		batchId,
		created: made.length,
		message: live ? "كُتبت الكروت على الراوتر" : "كُتبت الكروت في المختبر ولم تُرسل إلى جهاز"
	};
}
async function sellVouchers(userId, ids) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	if (!ids.length || ids.length > 100) throw new Error("حدد كروتاً للبيع");
	let amount = 0;
	let qty = 0;
	for (const cardId of ids) {
		const row = (await sql`select id, price, status, username from vouchers where id = ${cardId} and tenant_id = ${tenant.id}`)[0];
		if (!row || text(row.status) !== "new") continue;
		await sql`update vouchers set status = 'sold' where id = ${cardId} and tenant_id = ${tenant.id}`;
		amount += num(row.price) ?? 0;
		qty += 1;
		await audit(sql, tenant.id, userId, "بيع كرت", cardId, text(row.username));
	}
	if (!qty) throw new Error("لا توجد كروت جديدة ضمن التحديد");
	await sql`insert into sales (id, tenant_id, day, amount, qty, note, origin)
    values (${id()}, ${tenant.id}, ${adenDay()}, ${amount}, ${qty}, 'بيع كروت', 'live')`;
	return {
		ok: true,
		qty,
		amount,
		message: `سُجّل بيع ${qty} كرت`
	};
}
async function setVoucherStatus(userId, cardId, status) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const rows = await sql`select id, username, origin from vouchers where id = ${cardId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("الكرت غير موجود");
	if (text(rows[0].origin) === "live") throw new Error("تعطيل كرت على راوتر حقيقي لا يُنفَّذ قبل اختبار الأمر على الجهاز. كروت المختبر فقط تُعطَّل هنا.");
	await sql`update vouchers set status = ${status} where id = ${cardId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, status === "disabled" ? "تعطيل كرت" : "إعادة كرت", cardId, text(rows[0].username));
	return { ok: true };
}
async function voucherCodes(userId, ids) {
	const { sql, tenant } = await ensure(userId);
	const QR = await import("qrcode");
	const out = [];
	for (const cardId of ids.slice(0, 60)) {
		const rows = await sql`select id, username from vouchers where id = ${cardId} and tenant_id = ${tenant.id}`;
		if (!rows[0]) continue;
		const username = text(rows[0].username);
		const qr = await QR.toDataURL(`HZUSER:${username}`, {
			margin: 0,
			width: 180
		});
		out.push({
			id: cardId,
			username,
			qr
		});
	}
	return out;
}
async function listTemplates(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select * from card_templates where tenant_id = ${tenant.id} order by name`).map(mapTemplate);
}
function mapTemplate(row) {
	return {
		id: text(row.id),
		name: text(row.name),
		accent: text(row.accent, "cyan"),
		showUser: flag(row.show_user),
		showPass: flag(row.show_pass),
		showPrice: flag(row.show_price),
		showValidity: flag(row.show_validity),
		showProfile: flag(row.show_profile),
		showQr: flag(row.show_qr),
		footer: text(row.footer)
	};
}
async function saveTemplate(userId, input) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const rowId = input.id || id();
	if (input.id) await sql`update card_templates set name = ${input.name}, accent = ${input.accent}, show_user = ${input.showUser},
      show_pass = ${input.showPass}, show_price = ${input.showPrice}, show_validity = ${input.showValidity},
      show_profile = ${input.showProfile}, show_qr = ${input.showQr}, footer = ${input.footer}
      where id = ${input.id} and tenant_id = ${tenant.id}`;
	else await sql`insert into card_templates (
      id, tenant_id, name, accent, show_user, show_pass, show_price, show_validity, show_profile, show_qr, footer, origin
    ) values (
      ${rowId}, ${tenant.id}, ${input.name}, ${input.accent}, ${input.showUser}, ${input.showPass}, ${input.showPrice},
      ${input.showValidity}, ${input.showProfile}, ${input.showQr}, ${input.footer}, 'live'
    )`;
	await audit(sql, tenant.id, userId, "حفظ قالب", rowId, input.name);
	return { id: rowId };
}
async function listDevices(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select * from devices where tenant_id = ${tenant.id} order by name`).map((d) => ({
		id: text(d.id),
		name: text(d.name),
		vendor: text(d.vendor),
		model: text(d.model),
		kind: text(d.kind),
		ip: text(d.ip),
		mac: text(d.mac),
		status: text(d.status),
		lastSeen: str(d.last_seen),
		signal: num(d.signal),
		noise: num(d.noise),
		ccq: num(d.ccq),
		tower: text(d.tower),
		source: text(d.source),
		origin: text(d.origin)
	}));
}
async function listTopology(userId) {
	const { sql, tenant } = await ensure(userId);
	const towers = await sql`select * from towers where tenant_id = ${tenant.id} order by name`;
	const antennas = await sql`select * from antennas where tenant_id = ${tenant.id} order by name`;
	const sources = await sql`select * from sources where tenant_id = ${tenant.id} order by name`;
	const links = await sql`select * from links where tenant_id = ${tenant.id}`;
	const routers = await sql`select id, name, mode, status from routers where tenant_id = ${tenant.id}`;
	return {
		towers: towers.map((t) => ({
			id: text(t.id),
			name: text(t.name),
			site: text(t.site),
			lat: str(t.lat),
			lng: str(t.lng),
			routerId: str(t.router_id),
			power: text(t.power_note),
			notes: text(t.notes),
			status: text(t.status),
			origin: text(t.origin)
		})),
		antennas: antennas.map((a) => ({
			id: text(a.id),
			towerId: text(a.tower_id),
			name: text(a.name),
			kind: text(a.kind),
			model: text(a.model),
			ip: text(a.ip),
			frequency: text(a.frequency),
			channel: text(a.channel),
			width: text(a.width),
			signal: num(a.signal),
			ccq: num(a.ccq),
			clients: num(a.clients),
			status: text(a.status)
		})),
		sources: sources.map((s) => ({
			id: text(s.id),
			name: text(s.name),
			kind: text(s.kind),
			iface: text(s.iface),
			contracted: text(s.contracted),
			cost: num(s.cost),
			status: text(s.status),
			latencyMs: num(s.latency_ms),
			loss: str(s.loss),
			downloadMbps: num(s.download_mbps),
			uploadMbps: num(s.upload_mbps),
			note: text(s.note),
			origin: text(s.origin)
		})),
		links: links.map((l) => ({
			fromKind: text(l.from_kind),
			fromId: text(l.from_id),
			toKind: text(l.to_kind),
			toId: text(l.to_id)
		})),
		routers: routers.map((r) => ({
			id: text(r.id),
			name: text(r.name),
			mode: text(r.mode),
			status: text(r.status)
		}))
	};
}
async function listAlerts(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select * from alerts where tenant_id = ${tenant.id} order by created_at desc limit 100`).map((a) => ({
		id: text(a.id),
		severity: text(a.severity),
		title: text(a.title),
		detail: text(a.detail),
		acked: flag(a.acked),
		origin: text(a.origin),
		createdAt: text(a.created_at)
	}));
}
async function ackAlert(userId, alertId) {
	const { sql, tenant } = await ensure(userId);
	await sql`update alerts set acked = true where id = ${alertId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "إغلاق تنبيه", alertId, "");
	return { ok: true };
}
async function listBackups(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select b.id, b.kind, b.name, b.status, b.detail, b.origin, b.created_at, r.name as router
    from backups b join routers r on r.id = b.router_id
    where b.tenant_id = ${tenant.id} order by b.created_at desc limit 40`).map((b) => ({
		id: text(b.id),
		kind: text(b.kind),
		name: text(b.name),
		status: text(b.status),
		detail: text(b.detail),
		origin: text(b.origin),
		router: text(b.router),
		createdAt: text(b.created_at),
		downloadable: text(b.kind) === "lab-export"
	}));
}
async function createBackup(userId, routerId) {
	const { sql, tenant } = await ensure(userId);
	const router = await routerFor(sql, tenant.id, routerId);
	if (text(router.mode) === "lab") {
		const profiles = await sql`select name, kind, rate_down, rate_up from profiles where router_id = ${routerId}`;
		const cipher = await seal(sql, JSON.stringify({
			kind: "lab-export",
			router: mapRouter(router),
			profiles: profiles.map((p) => ({
				name: text(p.name),
				kind: text(p.kind),
				down: text(p.rate_down),
				up: text(p.rate_up)
			})),
			note: "هذا تصدير مختبر وليس ملف .backup الخاص بـ RouterOS، ولا يصلح للاستعادة على جهاز."
		}, null, 2));
		const backupId = id();
		await sql`insert into backups (id, tenant_id, router_id, kind, name, status, detail, body_cipher, origin)
      values (${backupId}, ${tenant.id}, ${routerId}, 'lab-export', ${`lab-${text(router.name)}`}, 'ready', 'تصدير مشفّر للمختبر', ${cipher}, 'lab')`;
		await audit(sql, tenant.id, userId, "نسخة مختبر", backupId, text(router.name));
		return {
			id: backupId,
			message: "حُفظ تصدير مشفّر للمختبر. ليس ملف راوتر."
		};
	}
	const password = await open(sql, str(router.secret_cipher));
	if (!password || !str(router.fingerprint) && text(router.conn_type) !== "api") throw new Error("اربط الراوتر وثبّت البصمة قبل طلب نسخة من الجهاز");
	const name = `alzher-${Date.now()}`;
	await withApi({
		host: text(router.host),
		port: num(router.port) ?? 8729,
		tls: text(router.conn_type) !== "api",
		fingerprint: str(router.fingerprint),
		user: text(router.api_user),
		password
	}, async (call) => {
		await call([
			"/system/backup/save",
			`=name=${name}`,
			"=dont-encrypt=yes"
		]);
	});
	const backupId = id();
	await sql`insert into backups (id, tenant_id, router_id, kind, name, status, detail, origin)
    values (${backupId}, ${tenant.id}, ${routerId}, 'ros-command', ${name}, 'on-router', 'أُنشئ الملف على الراوتر. تنزيله الثنائي غير مفعّل حتى يُختبر المسار.', 'live')`;
	await audit(sql, tenant.id, userId, "نسخ احتياطي", backupId, name);
	return {
		id: backupId,
		message: "أُمر الراوتر بإنشاء النسخة. الملف على الجهاز وليس هنا."
	};
}
async function downloadBackup(userId, backupId) {
	const { sql, tenant } = await ensure(userId);
	const row = (await sql`select kind, name, body_cipher from backups where id = ${backupId} and tenant_id = ${tenant.id}`)[0];
	if (!row) throw new Error("النسخة غير موجودة");
	if (text(row.kind) !== "lab-export" || !str(row.body_cipher)) throw new Error("هذه النسخة موجودة على الراوتر ولا يُتاح تنزيلها من المنصة.");
	const body = await open(sql, str(row.body_cipher));
	await audit(sql, tenant.id, userId, "تنزيل نسخة", backupId, text(row.name));
	return {
		filename: `${text(row.name)}.json`,
		body
	};
}
async function explainRestore(userId, backupId) {
	const { sql, tenant } = await ensure(userId);
	const rows = await sql`select kind, name from backups where id = ${backupId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("النسخة غير موجودة");
	await audit(sql, tenant.id, userId, "رفض استعادة", backupId, "الاستعادة العشوائية موقوفة");
	return {
		ok: false,
		message: text(rows[0].kind) === "lab-export" ? "الاستعادة موقوفة: الملف تصدير مختبر وليس نسخة RouterOS، ولن يُرسل إلى أي جهاز." : "الاستعادة موقوفة: لا تُستعاد نسخة على راوتر قبل مطابقة الموديل والإصدار وتأكيد صريح على جهاز حقيقي."
	};
}
async function getReports(userId) {
	const { sql, tenant } = await ensure(userId);
	const days = await sql`select day, sum(amount)::int as amount, sum(qty)::int as qty
    from sales where tenant_id = ${tenant.id} group by day order by day desc limit 31`;
	const byOrigin = await sql`select origin, sum(amount)::int as amount from sales where tenant_id = ${tenant.id} group by origin`;
	const tech = await sql`select
    (select count(*) from sessions where tenant_id = ${tenant.id})::int as sessions,
    (select count(*) from routers where tenant_id = ${tenant.id} and status = 'online')::int as online,
    (select count(*) from alerts where tenant_id = ${tenant.id} and acked = false)::int as alerts`;
	return {
		days: days.map((d) => ({
			day: text(d.day),
			amount: num(d.amount) ?? 0,
			qty: num(d.qty) ?? 0
		})),
		origins: byOrigin.map((o) => ({
			origin: text(o.origin),
			amount: num(o.amount) ?? 0
		})),
		tech: {
			sessions: num(tech[0]?.sessions) ?? 0,
			online: num(tech[0]?.online) ?? 0,
			alerts: num(tech[0]?.alerts) ?? 0
		}
	};
}
async function listAudit(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select action, target, detail, created_at from audit_logs
    where tenant_id = ${tenant.id} order by created_at desc limit 200`).map((a) => ({
		action: text(a.action),
		target: text(a.target),
		detail: text(a.detail),
		createdAt: text(a.created_at)
	}));
}
async function listScripts(userId) {
	const { sql, tenant } = await ensure(userId);
	const drafts = await sql`select id, name, body, danger, status from scripts where tenant_id = ${tenant.id} order by created_at desc`;
	const runs = await sql`select script_name, status, detail, created_at from script_runs where tenant_id = ${tenant.id} order by created_at desc limit 30`;
	return {
		builtin: BUILTIN.map((s) => ({ ...s })),
		drafts: drafts.map((d) => ({
			id: text(d.id),
			name: text(d.name),
			body: text(d.body),
			danger: text(d.danger),
			status: text(d.status)
		})),
		runs: runs.map((r) => ({
			name: text(r.script_name),
			status: text(r.status),
			detail: text(r.detail),
			createdAt: text(r.created_at)
		}))
	};
}
async function saveScript(userId, name, body) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	if (body.length > 4e3) throw new Error("السكربت طويل");
	const rowId = id();
	await sql`insert into scripts (id, tenant_id, name, body, danger, status)
    values (${rowId}, ${tenant.id}, ${name}, ${body}, 'غير معروف', 'review')`;
	await audit(sql, tenant.id, userId, "حفظ سكربت للمراجعة", rowId, name);
	return {
		id: rowId,
		message: "حُفظ للمراجعة ولن يعمل حتى يُعتمد. التشغيل من هذه الشاشة يرفضه."
	};
}
async function runScript(userId, scriptId, routerId) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	const router = await routerFor(sql, tenant.id, routerId);
	if (!BUILTIN.some((s) => s.id === scriptId)) {
		await sql`insert into script_runs (id, tenant_id, script_name, router_id, status, detail)
      values (${id()}, ${tenant.id}, ${scriptId}, ${routerId}, 'refused', 'سكربت غير معتمد')`;
		await audit(sql, tenant.id, userId, "رفض سكربت", scriptId, "غير موجود في القائمة المعتمدة");
		throw new Error("لن يُنفَّذ سكربت خارج القائمة المعتمدة.");
	}
	if (scriptId === "builtin:read") {
		if (text(router.mode) === "lab") {
			const detail = `مختبر: ${text(router.model) ?? "غير معروف"} / ${text(router.ros_version) ?? "لم يُقرأ"} / معالج ${text(router.cpu) ?? "—"}٪`;
			await sql`insert into script_runs (id, tenant_id, script_name, router_id, status, detail)
        values (${id()}, ${tenant.id}, 'قراءة موارد', ${routerId}, 'lab', ${detail})`;
			return {
				ok: true,
				message: detail
			};
		}
		const result = await connectRouter(userId, routerId);
		await sql`insert into script_runs (id, tenant_id, script_name, router_id, status, detail)
      values (${id()}, ${tenant.id}, 'قراءة موارد', ${routerId}, ${result.ok ? "ok" : "failed"}, ${result.message})`;
		return {
			ok: result.ok,
			message: result.message
		};
	}
	const today = adenDay();
	const expired = await sql`select id, username from hotspot_users
    where tenant_id = ${tenant.id} and router_id = ${routerId} and disabled = false and expires_on is not null and expires_on < ${today}`;
	if (text(router.mode) === "live") {
		await sql`insert into script_runs (id, tenant_id, script_name, router_id, status, detail)
      values (${id()}, ${tenant.id}, 'تعطيل المنتهي', ${routerId}, 'refused', 'التنفيذ الحي لهذه المهمة موقوف حتى اختبارها على جهاز')`;
		await audit(sql, tenant.id, userId, "رفض تنفيذ", routerId, "تعطيل المنتهي على جهاز حقيقي موقوف");
		return {
			ok: false,
			message: `وُجد ${expired.length} حساب منتهٍ، ولم يُرسل تعطيل إلى الراوتر. التنفيذ الحي موقوف حتى الاختبار على جهاز.`
		};
	}
	for (const row of expired) await sql`update hotspot_users set disabled = true where id = ${text(row.id)} and tenant_id = ${tenant.id}`;
	const detail = `عُطّل ${expired.length} في المختبر`;
	await sql`insert into script_runs (id, tenant_id, script_name, router_id, status, detail)
    values (${id()}, ${tenant.id}, 'تعطيل المنتهي', ${routerId}, 'lab', ${detail})`;
	await audit(sql, tenant.id, userId, "سكربت مختبر", routerId, detail);
	return {
		ok: true,
		message: detail
	};
}
async function listSubscribers(userId) {
	const { sql, tenant } = await ensure(userId);
	return (await sql`select * from subscribers where tenant_id = ${tenant.id} order by ends_on`).map((s) => ({
		id: text(s.id),
		name: text(s.name),
		phone: text(s.phone),
		address: text(s.address),
		code: text(s.code),
		tower: text(s.tower),
		antenna: text(s.antenna),
		service: text(s.service),
		account: text(s.account),
		plan: text(s.plan_name),
		startedOn: text(s.started_on),
		endsOn: text(s.ends_on),
		status: text(s.status),
		origin: text(s.origin)
	}));
}
async function renewSubscriber(userId, subscriberId, days) {
	const { sql, tenant } = await ensure(userId);
	assertWritable((await licenseOf(sql, tenant.id)).status);
	if (![
		1,
		7,
		30,
		365
	].includes(days)) throw new Error("مدة التجديد غير مدعومة");
	const rows = await sql`select name, ends_on from subscribers where id = ${subscriberId} and tenant_id = ${tenant.id}`;
	if (!rows[0]) throw new Error("العميل غير موجود");
	const base = text(rows[0].ends_on) < adenDay() ? adenDay() : text(rows[0].ends_on);
	const next = addDays(base, days);
	await sql`update subscribers set ends_on = ${next}, status = 'active' where id = ${subscriberId} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "تجديد عميل", subscriberId, `${text(rows[0].name)} حتى ${next}`);
	return {
		ok: true,
		endsOn: next,
		message: `مُدّد الاشتراك حتى ${next}`
	};
}
async function listStaff(userId) {
	const { sql, tenant } = await ensure(userId);
	const rows = await sql`select * from staff where tenant_id = ${tenant.id} order by name`;
	return {
		license: await licenseOf(sql, tenant.id),
		staff: rows.map((s) => ({
			id: text(s.id),
			name: text(s.name),
			role: text(s.role),
			phone: text(s.phone),
			active: flag(s.active)
		}))
	};
}
async function saveStaff(userId, input) {
	const { sql, tenant } = await ensure(userId);
	const license = await licenseOf(sql, tenant.id);
	assertWritable(license.status);
	if (!(/* @__PURE__ */ new Set([
		"manager",
		"supervisor",
		"seller",
		"tech",
		"accountant"
	])).has(input.role)) throw new Error("الدور غير معروف");
	if (!input.id) {
		if ((num((await sql`select count(*)::int as n from staff where tenant_id = ${tenant.id}`)[0]?.n) ?? 0) >= license.staffLimit) throw new Error("بلغت حد المستخدمين الإداريين في الباقة");
		const rowId = id();
		await sql`insert into staff (id, tenant_id, name, role, phone, active)
      values (${rowId}, ${tenant.id}, ${input.name}, ${input.role}, ${input.phone}, ${input.active})`;
		await audit(sql, tenant.id, userId, "إضافة موظف", rowId, input.name);
		return { id: rowId };
	}
	await sql`update staff set name = ${input.name}, role = ${input.role}, phone = ${input.phone}, active = ${input.active}
    where id = ${input.id} and tenant_id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "تعديل موظف", input.id, input.name);
	return { id: input.id };
}
async function updateWorkspace(userId, input) {
	const { sql, tenant } = await ensure(userId);
	if (input.logo && !/^data:image\/(png|jpeg);base64,/.test(input.logo)) throw new Error("الشعار يجب أن يكون PNG أو JPEG");
	if (input.logo && input.logo.length > 18e4) throw new Error("الشعار أكبر من الحد");
	await sql`update tenants set name = ${input.name}, area = ${input.area}, logo_data = ${input.logo ?? null}
    where id = ${tenant.id}`;
	await audit(sql, tenant.id, userId, "تحديث الشبكة", tenant.id, input.name);
	return { ok: true };
}
async function setLab(userId, action) {
	const { sql, tenant } = await ensure(userId);
	if (action === "clear") {
		await clearLab(sql, tenant.id);
		await audit(sql, tenant.id, userId, "إزالة المختبر", tenant.id, "");
		return {
			ok: true,
			message: "أُزيلت بيانات المختبر. الأرقام المتبقية صفرية حتى تربط راوتراً."
		};
	}
	await clearLab(sql, tenant.id);
	await seedLab(sql, tenant.id);
	await audit(sql, tenant.id, userId, "استعادة المختبر", tenant.id, "");
	return {
		ok: true,
		message: "عاد مختبر الزهر نت. كل بطاقاته معلّمة بأنها ليست قراءة حية."
	};
}

export { ackAlert, connectRouter, createBackup, deleteRouter, disconnectSession, downloadBackup, explainRestore, generateVouchers, getDashboard, getReports, getRouter, getWorkspace, listAlerts, listAudit, listBackups, listDevices, listHotspot, listPppoe, listProfiles, listRouters, listScripts, listSessions, listStaff, listSubscribers, listTemplates, listTopology, listVouchers, rebootRouter, renewSubscriber, runScript, saveHotspot, savePppoe, saveProfile, saveRouter, saveScript, saveStaff, saveTemplate, sellVouchers, setLab, setUserDisabled, setVoucherStatus, updateWorkspace, voucherCodes };
