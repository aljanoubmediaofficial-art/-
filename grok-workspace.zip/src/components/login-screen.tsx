import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { messageOf } from "@/components/kit";

export function LoginScreen() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      if (mode === "up") {
        const created = await authClient.signUp.email({ email, password, name });
        if (created.error) throw new Error(created.error.message || "تعذر إنشاء الحساب");
      } else {
        const signed = await authClient.signIn.email({ email, password });
        if (signed.error) throw new Error(signed.error.message || "تعذر الدخول");
      }
      await navigate({ to: "/" });
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-screen max-w-6xl items-center gap-8 px-4 py-10 md:grid-cols-2">
      <section>
        <p className="text-sm text-cyan-text">ALZHER MikroTik</p>
        <h1 className="mt-2 text-4xl font-semibold">الزهر MikroTik</h1>
        <p className="mt-4 max-w-md text-pretty text-muted">
          منصة تشغيل الشبكة: الراوترات، الجلسات، الهوتسبوت، والـ PPPoE والكروت. القراءة الحية لا تُعرض إلا من الجهاز نفسه.
        </p>
        <ul className="mt-6 space-y-2 text-sm text-muted">
          <li>حساب مستقل لكل شبكة، والبيانات لا تختلط.</li>
          <li>مختبر معلّم يمكن إزالته قبل ربط راوتر حقيقي.</li>
          <li>شهادة الراوتر تُثبَّت بالبصمة، ولا تُرسل كلمة المرور قبل ذلك.</li>
        </ul>
      </section>
      <form className="panel space-y-4 p-5" onSubmit={(e) => void submit(e)}>
        <h2 className="text-xl font-semibold">{mode === "in" ? "دخول" : "حساب جديد"}</h2>
        {mode === "up" ? (
          <label className="block">
            <span className="lbl">الاسم</span>
            <input className="field" value={name} onChange={(e) => setName(e.target.value)} required />
          </label>
        ) : null}
        <label className="block">
          <span className="lbl">البريد</span>
          <input className="field ltr" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label className="block">
          <span className="lbl">كلمة المرور</span>
          <input className="field ltr" type="password" autoComplete={mode === "up" ? "new-password" : "current-password"} minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <button className="btn btn-primary w-full" type="submit" disabled={pending}>
          {pending ? "جارٍ التنفيذ…" : mode === "in" ? "دخول" : "إنشاء الحساب"}
        </button>
        <button type="button" className="btn btn-ghost w-full" onClick={() => setMode(mode === "in" ? "up" : "in")}>
          {mode === "in" ? "إنشاء حساب شبكة" : "لدي حساب"}
        </button>
        <div className="grid gap-2">
          {GROK_PROVIDERS.map((provider) => (
            <button
              key={provider.providerId}
              type="button"
              className="btn btn-ghost w-full"
              onClick={() => void signIn(provider.providerId, { callbackURL: "/" })}
            >
              المتابعة عبر {provider.label === "Google" ? "جوجل" : "إكس"}
            </button>
          ))}
        </div>
      </form>
    </main>
  );
}

export function Splash() {
  return (
    <main className="grid min-h-screen place-items-center px-6">
      <div className="text-center">
        <p className="text-sm text-cyan-text">ALZHER MikroTik</p>
        <h1 className="mt-2 text-3xl font-semibold">الزهر MikroTik</h1>
        <p className="mt-2 text-sm text-muted">جاري فتح الجلسة</p>
      </div>
    </main>
  );
}
