import { useCallback, useEffect, useState, type ReactNode } from "react";

export function messageOf(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "object" && error && "message" in error) {
    const msg = (error as { message?: unknown }).message;
    if (typeof msg === "string" && msg) return msg;
  }
  return "تعذر التنفيذ";
}

export function useLoad<T>(loader: () => Promise<T>) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(() => {
    setLoading(true);
    return loader()
      .then((next) => {
        setData(next);
        setError(null);
        setLoading(false);
        return next;
      })
      .catch((error: unknown) => {
        setError(messageOf(error));
        setLoading(false);
        throw error;
      });
  }, [loader]);
  useEffect(() => {
    let dead = false;
    setLoading(true);
    loader()
      .then((next) => {
        if (!dead) {
          setData(next);
          setError(null);
        }
      })
      .catch((error: unknown) => {
        if (!dead) setError(messageOf(error));
      })
      .finally(() => {
        if (!dead) setLoading(false);
      });
    return () => {
      dead = true;
    };
  }, [loader]);
  return { data, error, loading, reload };
}

export function PageHead({
  kicker,
  title,
  children,
}: {
  kicker?: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {kicker ? <p className="mb-1 text-sm text-cyan-text">{kicker}</p> : null}
        <h1 className="text-2xl font-semibold">{title}</h1>
      </div>
      {children}
    </header>
  );
}

export function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <article className="panel p-4">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 text-2xl font-semibold tabular-nums">{value}</p>
      {hint ? <p className="mt-1 text-xs text-muted">{hint}</p> : null}
    </article>
  );
}

export function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="panel px-5 py-10 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mx-auto mt-2 max-w-md text-sm text-pretty text-muted">{body}</p>
    </div>
  );
}

export function Modal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="scrim fixed inset-0 z-40 grid place-items-end p-3 sm:place-items-center" role="presentation">
      <div className="panel max-h-[90vh] w-full max-w-lg overflow-y-auto p-5" role="dialog" aria-modal="true">
        <div className="mb-4 flex items-start justify-between gap-3">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button type="button" className="btn btn-ghost min-h-10 px-3" onClick={onClose}>
            إغلاق
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="lbl">{label}</span>
      {children}
    </label>
  );
}

export const ROLE_LABEL: Record<string, string> = {
  manager: "مدير",
  supervisor: "مشرف",
  seller: "بائع",
  tech: "فني",
  accountant: "محاسب",
};

export function statusBadge(status: string) {
  if (["online", "active", "sold", "done", "closed", "sent", "stock", "installed", "spare", "ok"].includes(status)) return "badge-ok";
  if (["offline", "disabled", "danger", "faulty", "failed"].includes(status)) return "badge-danger";
  if (["unknown", "due", "warn", "new", "open", "assigned", "held"].includes(status)) return "badge-warn";
  return "";
}

export function statusText(status: string) {
  const map: Record<string, string> = {
    online: "متصل",
    offline: "منقطع",
    unknown: "لم يُفحص",
    active: "ساري",
    due: "متأخر",
    new: "جديد",
    sold: "مباع",
    disabled: "معطّل",
    lab: "مختبر",
    live: "حقيقي",
    authenticated: "جلسة دخول",
    hotspot: "هوتسبوت",
    pppoe: "PPPoE",
    open: "مفتوح",
    assigned: "معيّن",
    done: "منجز",
    closed: "مغلق",
    stock: "مخزن",
    installed: "مركّب",
    spare: "احتياط",
    faulty: "عطل",
    held: "لم يُرسل",
    sent: "أُرسل",
    failed: "فشل",
  };
  return map[status] ?? status;
}
