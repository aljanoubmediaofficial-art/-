import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BadgeCheck,
  Bell,
  Bot,
  Cable,
  CreditCard,
  FileBarChart,
  Gauge,
  Globe,
  HardDrive,
  LifeBuoy,
  Lightbulb,
  Menu,
  Network,
  Package,
  Radio,
  RadioTower,
  Router,
  ScrollText,
  Settings,
  Stethoscope,
  Store,
  Terminal,
  Users,
  Wrench,
  Wifi,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Toaster } from "sonner";
import { UserButton } from "@/lib/auth/gates";
import { setLab } from "@/lib/noc/api";
import { messageOf } from "@/components/kit";

const NAV: { label: string; items: { to: string; label: string; icon: LucideIcon }[] }[] = [
  {
    label: "المراقبة",
    items: [
      { to: "/", label: "مركز القيادة", icon: Gauge },
      { to: "/active", label: "المتصلون", icon: Activity },
      { to: "/routers", label: "الراوترات", icon: Router },
      { to: "/devices", label: "الأجهزة", icon: Radio },
      { to: "/towers", label: "الأبراج", icon: RadioTower },
      { to: "/sources", label: "مصادر الإنترنت", icon: Globe },
    ],
  },
  {
    label: "المشتركون",
    items: [
      { to: "/hotspot", label: "هوتسبوت", icon: Wifi },
      { to: "/pppoe", label: "PPPoE", icon: Cable },
      { to: "/userman", label: "يوزر منجر", icon: Users },
      { to: "/profiles", label: "البروفايلات", icon: Gauge },
      { to: "/subscribers", label: "العملاء", icon: Users },
    ],
  },
  {
    label: "المبيعات",
    items: [
      { to: "/vouchers", label: "الكروت", icon: CreditCard },
      { to: "/templates", label: "قوالب الطباعة", icon: FileBarChart },
      { to: "/resellers", label: "البائعون", icon: Store },
    ],
  },
  {
    label: "التشغيل",
    items: [
      { to: "/alerts", label: "التنبيهات", icon: Bell },
      { to: "/diagnose", label: "البحث عن المشاكل", icon: Stethoscope },
      { to: "/assist", label: "مساعد الزهر", icon: Lightbulb },
      { to: "/network", label: "أدوات الشبكة", icon: Network },
      { to: "/maintenance", label: "الصيانة", icon: Wrench },
      { to: "/inventory", label: "المخزون", icon: Package },
      { to: "/backups", label: "النسخ الاحتياطي", icon: HardDrive },
      { to: "/reports", label: "التقارير", icon: FileBarChart },
      { to: "/scripts", label: "السكربتات", icon: Terminal },
      { to: "/channels", label: "تيليجرام وواتساب", icon: Bot },
      { to: "/audit", label: "سجل العمليات", icon: ScrollText },
    ],
  },
  {
    label: "الحساب",
    items: [
      { to: "/subscription", label: "الاشتراك", icon: BadgeCheck },
      { to: "/support", label: "الدعم", icon: LifeBuoy },
      { to: "/settings", label: "الإعدادات", icon: Settings },
    ],
  },
];

export function Shell({
  name,
  hasLab,
  onLabChange,
  children,
}: {
  name: string;
  hasLab: boolean;
  onLabChange: () => void;
  children: ReactNode;
}) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);

  async function lab(action: "clear" | "restore") {
    try {
      await setLab({ data: { action } });
      onLabChange();
    } catch (error) {
      window.alert(messageOf(error));
    }
  }

  const nav = (
    <nav className="flex flex-col gap-5">
      {NAV.map((group) => (
        <div key={group.label}>
          <p className="mb-2 px-3 text-xs text-muted">{group.label}</p>
          <div className="flex flex-col gap-1">
            {group.items.map((item) => {
              const active = path === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm ${
                    active ? "bg-cyan-dim font-semibold text-cyan-text" : "text-fg"
                  }`}
                >
                  <Icon className="size-4 shrink-0" aria-hidden="true" />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );

  return (
    <div className="min-h-screen">
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--surface)",
            color: "var(--fg)",
            border: "1px solid var(--line)",
          },
        }}
      />
      <div className="no-print mx-auto grid max-w-7xl md:grid-cols-[17rem_1fr]">
        <aside className="hidden border-e border-line bg-raised px-3 py-5 md:block">
          <Brand name={name} />
          <div className="mt-6">{nav}</div>
        </aside>
        <div className="min-w-0">
          <header className="no-print sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-bg/95 px-3 py-3 backdrop-blur">
            <button type="button" className="btn btn-ghost min-h-11 px-3 md:hidden" onClick={() => setOpen(true)} aria-label="القائمة">
              <Menu className="size-5" />
            </button>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm text-muted">الزهر MikroTik</p>
              <p className="truncate font-semibold">{name}</p>
            </div>
            <UserButton />
          </header>
          {hasLab ? (
            <div className="no-print mx-3 mt-3 flex flex-wrap items-center justify-between gap-3 rounded-card border border-warn bg-warn-dim px-4 py-3 text-sm">
              <p>مختبر الزهر نت ظاهر الآن. الأرقام المخزّنة ليست قراءة حية من راوتر.</p>
              <button type="button" className="btn btn-ghost min-h-10" onClick={() => void lab("clear")}>
                إزالة المختبر
              </button>
            </div>
          ) : (
            <div className="no-print mx-3 mt-3 flex flex-wrap items-center justify-between gap-3 rounded-card border border-line px-4 py-3 text-sm">
              <p className="text-muted">لا يوجد مختبر. اربط راوتراً أو افتح شبكة تجريبية معلّمة.</p>
              <button type="button" className="btn btn-ghost min-h-10" onClick={() => void lab("restore")}>
                فتح المختبر
              </button>
            </div>
          )}
          <main className="px-3 py-4 pb-24">{children}</main>
        </div>
      </div>
      {open ? (
        <div className="no-print fixed inset-0 z-30 md:hidden">
          <button type="button" className="scrim absolute inset-0" aria-label="إغلاق" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 start-0 w-[min(20rem,88vw)] overflow-y-auto bg-raised p-4">
            <div className="mb-4 flex items-center justify-between">
              <Brand name={name} />
              <button type="button" className="btn btn-ghost min-h-10 px-3" onClick={() => setOpen(false)} aria-label="إغلاق">
                <X className="size-4" />
              </button>
            </div>
            {nav}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Brand({ name }: { name: string }) {
  return (
    <div className="px-2">
      <p className="text-lg font-semibold text-cyan-text">الزهر</p>
      <p className="text-xs tracking-wide text-muted">MikroTik · {name}</p>
    </div>
  );
}
