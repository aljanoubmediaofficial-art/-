import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import { Field, Modal, PageHead, messageOf, useLoad } from "@/components/kit";
import { listRouters, saveHotspot, savePppoe, setUserDisabled } from "@/lib/noc/api";
import { formatBytes } from "@/lib/format";

type Account = {
  id: string;
  routerId: string;
  router: string;
  mode: string;
  username: string;
  password: string;
  profile: string;
  mac: string;
  remoteAddress: string;
  comment: string;
  disabled: boolean;
  expiresOn: string | null;
  bytesIn: number;
  bytesOut: number;
  origin: string;
};

export function AccountsPage({
  title,
  kind,
  loader,
}: {
  title: string;
  kind: "hotspot" | "pppoe";
  loader: () => Promise<Account[]>;
}) {
  const load = useCallback(loader, [loader]);
  const { data, error, loading, reload } = useLoad(load);
  const routersLoad = useCallback(() => listRouters(), []);
  const routers = useLoad(routersLoad);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState<string | null>(null);
  const [form, setForm] = useState({
    routerId: "",
    username: "",
    password: "",
    profile: "",
    mac: "",
    remoteAddress: "",
    comment: "",
    disabled: false,
    expiresOn: "",
  });

  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    return (data ?? []).filter((row) => !query || `${row.username} ${row.mac} ${row.profile}`.toLowerCase().includes(query));
  }, [data, q]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    const payload = { ...form, routerId: form.routerId || routers.data?.routers[0]?.id || "" };
    try {
      const result = kind === "hotspot" ? await saveHotspot({ data: payload }) : await savePppoe({ data: payload });
      toast.success(result.message);
      setOpen(false);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  async function toggle(row: Account) {
    try {
      const result = await setUserDisabled({ data: { kind, id: row.id, disabled: !row.disabled } });
      toast.success(result.message);
      await reload();
    } catch (err) {
      toast.error(messageOf(err));
    }
  }

  return (
    <div>
      <PageHead kicker={kind === "hotspot" ? "مستخدمو الهوتسبوت" : "حسابات PPPoE"} title={title}>
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>إضافة</button>
      </PageHead>
      <input className="field mb-4" placeholder="بحث" value={q} onChange={(e) => setQ(e.target.value)} />
      {loading && !data ? <p className="text-muted">جاري التحميل…</p> : null}
      {error ? <p className="text-danger">{error}</p> : null}
      <div className="space-y-3">
        {rows.map((row) => (
          <article key={row.id} className="panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-semibold">{row.username}</p>
                <p className="text-sm text-muted">{row.profile || "بدون بروفايل"} · {row.router} · {row.mode === "lab" ? "مختبر" : "حقيقي"}</p>
              </div>
              <button type="button" className="btn btn-ghost" onClick={() => void toggle(row)}>
                {row.disabled ? "تفعيل" : "تعطيل"}
              </button>
            </div>
            <p className="mt-2 text-sm">
              كلمة المرور: {show === row.id ? <span className="ltr">{row.password || "غير متاحة"}</span> : "••••"}
              <button type="button" className="ms-2 text-cyan-text" onClick={() => setShow(show === row.id ? null : row.id)}>
                {show === row.id ? "إخفاء" : "إظهار"}
              </button>
            </p>
            <p className="mt-1 text-xs text-muted">
              {kind === "hotspot" ? row.mac || "بدون MAC" : row.remoteAddress || "بدون IP ثابت"} · ينتهي {row.expiresOn || "غير محدد"} · {formatBytes(row.bytesIn + row.bytesOut)} · {row.disabled ? "معطّل" : "فعّال"}
            </p>
          </article>
        ))}
      </div>
      <Modal open={open} title={`إضافة ${title}`} onClose={() => setOpen(false)}>
        <form className="grid gap-3" onSubmit={(e) => void submit(e)}>
          <Field label="الراوتر">
            <select className="field" value={form.routerId} onChange={(e) => setForm({ ...form, routerId: e.target.value })} required>
              <option value="">اختر</option>
              {(routers.data?.routers ?? []).map((router) => (
                <option key={router.id} value={router.id}>{router.name} · {router.mode === "lab" ? "مختبر" : "حقيقي"}</option>
              ))}
            </select>
          </Field>
          <Field label="اسم المستخدم"><input className="field ltr" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></Field>
          <Field label="كلمة المرور"><input className="field ltr" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
          <Field label="البروفايل"><input className="field" value={form.profile} onChange={(e) => setForm({ ...form, profile: e.target.value })} /></Field>
          {kind === "hotspot" ? (
            <Field label="MAC"><input className="field ltr" value={form.mac} onChange={(e) => setForm({ ...form, mac: e.target.value })} /></Field>
          ) : (
            <Field label="IP ثابت"><input className="field ltr" value={form.remoteAddress} onChange={(e) => setForm({ ...form, remoteAddress: e.target.value })} /></Field>
          )}
          <Field label="ينتهي"><input className="field ltr" type="date" value={form.expiresOn} onChange={(e) => setForm({ ...form, expiresOn: e.target.value })} /></Field>
          <Field label="ملاحظة"><input className="field" value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} /></Field>
          <button className="btn btn-primary" type="submit">حفظ</button>
        </form>
      </Modal>
    </div>
  );
}
