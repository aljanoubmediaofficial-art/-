import { Outlet } from "@tanstack/react-router";
import { useCallback } from "react";
import { Shell } from "@/components/shell";
import { Splash } from "@/components/login-screen";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getWorkspace } from "@/lib/noc/api";
import { useLoad } from "@/components/kit";

export function AppFrame() {
  const { user, isPending } = useCurrentUserState();
  const load = useCallback(() => getWorkspace(), []);
  const ws = useLoad(load);
  if (isPending) return <Splash />;
  if (!user) return <RedirectToSignIn />;
  if (!ws.data) {
    return ws.error ? (
      <main className="grid min-h-screen place-items-center px-6 text-center">
        <p className="max-w-md text-danger">{ws.error}</p>
      </main>
    ) : (
      <Splash />
    );
  }
  return (
    <Shell
      name={ws.data.tenant.name}
      hasLab={ws.data.hasLab}
      onLabChange={() => window.location.reload()}
    >
      <Outlet />
    </Shell>
  );
}
