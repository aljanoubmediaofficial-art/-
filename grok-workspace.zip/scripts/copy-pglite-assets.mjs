import { copyFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const dest = ".vercel/output/functions/__server.func/_libs";
if (!existsSync(dest)) process.exit(0);
const src = "node_modules/@electric-sql/pglite/dist";
for (const name of ["pglite.data", "pglite.wasm", "initdb.wasm"]) {
  copyFileSync(join(src, name), join(dest, name));
}
