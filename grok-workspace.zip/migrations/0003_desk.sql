-- Operational ledgers for ALZHER MikroTik. Unowned by lab seed; rows are written by the tenant.

create table if not exists resellers (
  id text primary key,
  tenant_id text not null,
  name text not null,
  phone text not null default '',
  commission_pct integer not null default 0,
  active boolean not null default true,
  notes text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists resellers_tenant_idx on resellers (tenant_id);

create table if not exists wallet_entries (
  id text primary key,
  tenant_id text not null,
  reseller_id text not null,
  kind text not null,
  amount integer not null,
  note text not null default '',
  reverses_id text,
  created_at timestamptz not null default now()
);
create index if not exists wallet_tenant_idx on wallet_entries (tenant_id, reseller_id);

create table if not exists um_users (
  id text primary key,
  tenant_id text not null,
  username text not null,
  profile_name text not null default '',
  credit integer not null default 0,
  limitation text not null default '',
  disabled boolean not null default false,
  note text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists um_tenant_idx on um_users (tenant_id);

create table if not exists jobs (
  id text primary key,
  tenant_id text not null,
  title text not null,
  site text not null default '',
  tower text not null default '',
  assignee text not null default '',
  status text not null default 'open',
  notes text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists jobs_tenant_idx on jobs (tenant_id);

create table if not exists inventory (
  id text primary key,
  tenant_id text not null,
  name text not null,
  kind text not null,
  serial text not null default '',
  model text not null default '',
  qty integer not null default 1,
  buy_price integer not null default 0,
  location text not null default '',
  state text not null default 'stock',
  warranty text not null default '',
  bought_on text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists inventory_tenant_idx on inventory (tenant_id);

create table if not exists channels (
  tenant_id text primary key,
  tg_token_cipher text,
  tg_chat text not null default '',
  tg_bot_name text not null default '',
  wa_phone text not null default '',
  wa_note text not null default ''
);

create table if not exists outbox (
  id text primary key,
  tenant_id text not null,
  channel text not null,
  to_addr text not null default '',
  body text not null,
  status text not null,
  detail text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists outbox_tenant_idx on outbox (tenant_id);

create table if not exists tickets (
  id text primary key,
  tenant_id text not null,
  subject text not null,
  body text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create index if not exists tickets_tenant_idx on tickets (tenant_id);

create table if not exists net_notes (
  id text primary key,
  tenant_id text not null,
  area text not null,
  name text not null,
  detail text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists net_notes_tenant_idx on net_notes (tenant_id);

create table if not exists payments (
  id text primary key,
  tenant_id text not null,
  subscriber_id text not null,
  amount integer not null,
  note text not null default '',
  day text not null,
  created_at timestamptz not null default now()
);
create index if not exists payments_tenant_idx on payments (tenant_id);
