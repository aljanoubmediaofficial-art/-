-- ALZHER MikroTik V1 schema. Tenant-scoped. Passwords stay encrypted in app code.

create table if not exists platform_keys (
  id text primary key,
  key_b64 text not null
);

create table if not exists tenants (
  id text primary key,
  owner_user_id text not null unique,
  name text not null,
  area text not null default '',
  logo_data text,
  created_at timestamptz not null default now()
);

create table if not exists licenses (
  tenant_id text primary key,
  plan text not null default 'trial',
  status text not null default 'active',
  router_limit integer not null default 3,
  staff_limit integer not null default 5,
  backup_mb integer not null default 200,
  started_on text not null,
  renews_on text not null
);

create table if not exists staff (
  id text primary key,
  tenant_id text not null,
  name text not null,
  role text not null,
  phone text not null default '',
  active boolean not null default true
);
create index if not exists staff_tenant_idx on staff (tenant_id);

create table if not exists routers (
  id text primary key,
  tenant_id text not null,
  name text not null,
  host text not null default '',
  port integer not null default 8729,
  conn_type text not null default 'api-ssl',
  api_user text not null default '',
  secret_cipher text,
  fingerprint text,
  ros_hint text not null default '',
  ros_version text,
  model text,
  board text,
  identity text,
  site text not null default '',
  tower text not null default '',
  notes text not null default '',
  wan_interface text not null default '',
  mode text not null default 'live',
  status text not null default 'unknown',
  cpu integer,
  ram integer,
  storage integer,
  temperature text,
  voltage text,
  uptime text,
  download_mbps integer,
  upload_mbps integer,
  last_seen text,
  last_error text,
  created_at timestamptz not null default now()
);
create index if not exists routers_tenant_idx on routers (tenant_id);

create table if not exists interfaces (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  name text not null,
  kind text not null default '',
  running boolean not null default false,
  comment text not null default '',
  origin text not null default 'lab'
);
create index if not exists interfaces_router_idx on interfaces (router_id);

create table if not exists profiles (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  name text not null,
  kind text not null,
  price integer not null default 0,
  rate_down text not null default '',
  rate_up text not null default '',
  validity text not null default '',
  shared_users integer not null default 1,
  data_limit text not null default '',
  ros_id text,
  origin text not null default 'lab'
);
create index if not exists profiles_tenant_idx on profiles (tenant_id);

create table if not exists hotspot_users (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  username text not null,
  secret_cipher text,
  profile_name text not null default '',
  mac text not null default '',
  comment text not null default '',
  disabled boolean not null default false,
  expires_on text,
  bytes_in bigint not null default 0,
  bytes_out bigint not null default 0,
  ros_id text,
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists hotspot_tenant_idx on hotspot_users (tenant_id);

create table if not exists pppoe_users (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  username text not null,
  secret_cipher text,
  profile_name text not null default '',
  remote_address text not null default '',
  comment text not null default '',
  disabled boolean not null default false,
  expires_on text,
  bytes_in bigint not null default 0,
  bytes_out bigint not null default 0,
  ros_id text,
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists pppoe_tenant_idx on pppoe_users (tenant_id);

create table if not exists sessions (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  username text not null,
  ip text not null default '',
  mac text not null default '',
  kind text not null,
  source text not null,
  tower text not null default '',
  antenna text not null default '',
  started_at text not null,
  rx_rate text,
  tx_rate text,
  bytes_in bigint not null default 0,
  bytes_out bigint not null default 0,
  profile_name text not null default '',
  ros_id text,
  origin text not null default 'lab'
);
create index if not exists sessions_tenant_idx on sessions (tenant_id);

create table if not exists devices (
  id text primary key,
  tenant_id text not null,
  router_id text,
  name text not null,
  vendor text not null default '',
  model text not null default '',
  kind text not null,
  ip text not null default '',
  mac text not null default '',
  interface_name text not null default '',
  status text not null default 'unknown',
  last_seen text,
  uptime text,
  signal integer,
  noise integer,
  ccq integer,
  tx_rate text,
  rx_rate text,
  bytes_in bigint,
  tower text not null default '',
  source text not null,
  origin text not null default 'lab'
);
create index if not exists devices_tenant_idx on devices (tenant_id);

create table if not exists towers (
  id text primary key,
  tenant_id text not null,
  name text not null,
  site text not null default '',
  lat text,
  lng text,
  router_id text,
  power_note text not null default '',
  notes text not null default '',
  status text not null default 'online',
  origin text not null default 'lab'
);
create index if not exists towers_tenant_idx on towers (tenant_id);

create table if not exists antennas (
  id text primary key,
  tenant_id text not null,
  tower_id text not null,
  name text not null,
  kind text not null default '',
  model text not null default '',
  ip text not null default '',
  mac text not null default '',
  frequency text not null default '',
  channel text not null default '',
  width text not null default '',
  signal integer,
  ccq integer,
  clients integer,
  status text not null default 'online',
  origin text not null default 'lab'
);
create index if not exists antennas_tenant_idx on antennas (tenant_id);

create table if not exists links (
  id text primary key,
  tenant_id text not null,
  from_kind text not null,
  from_id text not null,
  to_kind text not null,
  to_id text not null,
  origin text not null default 'lab'
);

create table if not exists sources (
  id text primary key,
  tenant_id text not null,
  name text not null,
  kind text not null,
  iface text not null default '',
  contracted text not null default '',
  cost integer,
  status text not null default 'unknown',
  latency_ms integer,
  loss text,
  download_mbps integer,
  upload_mbps integer,
  note text not null default '',
  origin text not null default 'lab'
);
create index if not exists sources_tenant_idx on sources (tenant_id);

create table if not exists subscribers (
  id text primary key,
  tenant_id text not null,
  name text not null,
  phone text not null default '',
  address text not null default '',
  code text not null default '',
  tower text not null default '',
  antenna text not null default '',
  service text not null default 'PPPoE',
  ip text not null default '',
  mac text not null default '',
  account text not null default '',
  plan_name text not null default '',
  started_on text not null,
  ends_on text not null,
  status text not null default 'active',
  origin text not null default 'lab'
);
create index if not exists subscribers_tenant_idx on subscribers (tenant_id);

create table if not exists voucher_batches (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  profile_name text not null,
  price integer not null default 0,
  card_type text not null,
  qty integer not null,
  prefix text not null default '',
  note text not null default '',
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);

create table if not exists vouchers (
  id text primary key,
  tenant_id text not null,
  batch_id text not null,
  router_id text not null,
  username text not null,
  secret_cipher text,
  card_type text not null,
  profile_name text not null default '',
  price integer not null default 0,
  validity text not null default '',
  status text not null default 'new',
  ros_id text,
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists vouchers_tenant_idx on vouchers (tenant_id);

create table if not exists card_templates (
  id text primary key,
  tenant_id text not null,
  name text not null,
  accent text not null default 'cyan',
  show_user boolean not null default true,
  show_pass boolean not null default true,
  show_price boolean not null default true,
  show_validity boolean not null default true,
  show_profile boolean not null default true,
  show_qr boolean not null default true,
  footer text not null default '',
  origin text not null default 'lab'
);

create table if not exists sales (
  id text primary key,
  tenant_id text not null,
  day text not null,
  amount integer not null,
  qty integer not null default 1,
  note text not null default '',
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists sales_tenant_idx on sales (tenant_id, day);

create table if not exists alerts (
  id text primary key,
  tenant_id text not null,
  severity text not null,
  title text not null,
  detail text not null default '',
  router_id text,
  acked boolean not null default false,
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists alerts_tenant_idx on alerts (tenant_id);

create table if not exists backups (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  kind text not null,
  name text not null,
  status text not null,
  detail text not null default '',
  body_cipher text,
  origin text not null default 'lab',
  created_at timestamptz not null default now()
);
create index if not exists backups_tenant_idx on backups (tenant_id);

create table if not exists traffic_samples (
  id text primary key,
  tenant_id text not null,
  router_id text not null,
  hour text not null,
  down_mbps integer not null,
  up_mbps integer not null,
  origin text not null default 'lab'
);
create index if not exists traffic_router_idx on traffic_samples (router_id);

create table if not exists scripts (
  id text primary key,
  tenant_id text not null,
  name text not null,
  body text not null,
  danger text not null default 'غير معروف',
  status text not null default 'review',
  created_at timestamptz not null default now()
);

create table if not exists script_runs (
  id text primary key,
  tenant_id text not null,
  script_name text not null,
  router_id text,
  status text not null,
  detail text not null default '',
  actor text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id text primary key,
  tenant_id text not null,
  user_id text not null,
  action text not null,
  target text not null default '',
  detail text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists audit_tenant_idx on audit_logs (tenant_id);
